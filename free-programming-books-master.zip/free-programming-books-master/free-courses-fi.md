### Index

* [C#](#C#)
* [Other](#other)
* [Python](#python)


### C#

* [Jyväskylän yliopiston C#-kieli ohjelmointikurssi](https://tim.jyu.fi/view/kurssit/tie/ohj1/moniste/Ohjelmointi-1) - Ilmainen verkkokurssi


### Other

* [Elements of AI](https://www.elementsofai.com/fi/) - Tekoälykurssi
* [Koodaustunti](http://koodaustunti.fi/miten-aloitan-koodaamaan/) - Opi koodaamaan verkossa
* [Mooc](https://mooc.fi) - Laadukkaita, avoimia ja ilmaisia verkkokursseja kaikille


### Python

* [Helsingin yliopiston Python-ohjelmointikurssi](https://linkki.github.io/python2017/) - Ilmainen verkkokurssi
