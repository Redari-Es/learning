### Index

* [ABAP](#abap)
* [Ada](#ada)
* [Agda](#agda)
* [Alef](#alef)
* [Android](#android)
* [APL](#apl)
* [Arduino](#arduino)
* [ASP.NET](#aspnet)
* [Assembly Language](#assembly-language)
  * [Non-X86](#non-x86)
* [AutoHotkey](#autohotkey)
* [Autotools](#autotools)
* [Awk](#awk)
* [Bash](#bash)
* [Basic](#basic)
* [BETA](#beta)
* [C](#c)
* [C#](#c-sharp)
* [C++](#c-1)
* [Chapel](#chapel)
* [Cilk](#cilk)
* [Clojure](#clojure)
* [COBOL](#cobol)
* [CoffeeScript](#coffeescript)
* [ColdFusion](#coldfusion)
* [Component Pascal](#component-pascal)
* [Cool](#cool)
* [Coq](#coq)
* [Crystal](#crystal)
* [CUDA](#cuda)
* [D](#d)
* [Dart](#dart)
* [DB2](#db2)
* [Delphi / Pascal](#delphi--pascal)
* [DTrace](#dtrace)
* [Eiffel](#eiffel)
* [Elasticsearch](#elasticsearch)
* [Elixir](#elixir)
  * [Ecto](#ecto)
  * [Phoenix](#phoenix)
* [Elm](#elm)
* [Emacs](#emacs)
* [Embedded Systems](#embedded-systems)
* [Erlang](#erlang)
* [ESP8266](#esp8266)
* [F#](#f-sharp)
* [Firefox OS](#firefox-os)
* [Flutter](#flutter)
* [Force.com](#forcecom)
* [Forth](#forth)
* [Fortran](#fortran)
* [FreeBSD](#freebsd)
* [Git](#git)
* [Go](#go)
* [Graphical user interfaces](#graphical-user-interfaces)
* [Graphics Programming](#graphics-programming)
* [GraphQL](#graphql)
* [Groovy](#groovy)
  * [Gradle](#gradle)
  * [Grails](#grails)
  * [Spock Framework](#spock-framework)
* [Hack](#hack)
* [Hadoop](#hadoop)
* [Haskell](#haskell)
* [Haxe](#haxe)
* [HTML / CSS](#html--css)
  * [Bootstrap](#bootstrap)
* [HTTP](#http)
* [Icon](#icon)
* [Idris](#idris)
* [iOS](#ios)
* [IoT](#iot)
* [Isabelle/HOL](#isabellehol)
* [J](#j)
* [Java](#java)
  * [Codename One](#codename-one)
  * [JasperReports](#jasperreports)
  * [Spring](#spring)
  * [Spring Boot](#spring-boot)
  * [Spring Data](#spring-data)
  * [Spring Security](#spring-security)
  * [Wicket](#wicket)
* [JavaScript](#javascript)
  * [Angular.js](#angularjs)
  * [Aurelia](#aurelia)
  * [Backbone.js](#backbonejs)
  * [Booty5.js](#booty5js)
  * [D3.js](#d3js)
  * [Dojo](#dojo)
  * [Elm](#elm)
  * [Ember.js](#emberjs)
  * [Express.js](#expressjs)
  * [Ionic](#ionic)
  * [jQuery](#jquery)
  * [meteor](#meteor)
  * [Node.js](#nodejs)
  * [Om](#om)
  * [React](#react)
  * [React Native](#react-native)
  * [Redux](#redux)
  * [Vue.js](#vuejs)
* [Jenkins](#jenkins)
* [Julia](#julia)
* [Kotlin](#kotlin)
* [Language Agnostic](#language-agnostic)
  * [Algorithms & Data Structures](#algorithms--data-structures)
  * [Artificial Intelligence](#artificial-intelligence)
  * [Cellular Automata](#cellular-automata)
  * [Cloud Computing](#cloud-computing)
  * [Competitive Programming](#competitive-programming)
  * [Compiler Design](#compiler-design)
  * [Computer Science](#computer-science)
  * [Computer Vision](#computer-vision)
  * [Containers](#containers)
  * [Database](#database)
  * [Datamining](#datamining)
  * [Information Retrieval](#information-retrieval)
  * [Licensing](#licensing)
  * [Machine Learning](#machine-learning)
  * [Mathematics](#mathematics)
  * [Mathematics For Computer Science](#mathematics-for-computer-science)
  * [Misc](#misc)
  * [MOOC](#mooc)
  * [Networking](#networking)
  * [Open Source Ecosystem](#open-source-ecosystem)
  * [Operating Systems](#operating-systems)
  * [Parallel Programming](#parallel-programming)
  * [Partial Evaluation](#partial-evaluation)
  * [Professional Development](#professional-development)
  * [Programming Paradigms](#programming-paradigms)
  * [Regular Expressions](#regular-expressions)
  * [Reverse Engineering](#reverse-engineering)
  * [Security](#security)
  * [Software Architecture](#software-architecture)
  * [Standards](#standards)
  * [Theoretical Computer Science](#theoretical-computer-science)
  * [Web Performance](#web-performance)
* [LaTeX / TeX](#latex--tex)
  * [LaTeX](#latex)
  * [TeX](#tex)
* [Limbo](#limbo)
* [Linux](#linux)
* [Lisp](#lisp)
* [Livecode](#livecode)
* [Lua](#lua)
* [Make](#make)
* [Markdown](#markdown)
* [Mathematica](#mathematica)
* [MATLAB](#matlab)
* [Maven](#maven)
* [Mercurial](#mercurial)
* [Mercury](#mercury)
* [Meta-Lists](#meta-lists)
* [Modelica](#modelica)
* [MySQL](#mysql)
* [Neo4J](#neo4j)
* [.NET Framework](#net-framework)
* [Nim](#nim)
* [NoSQL](#nosql)
* [Oberon](#oberon)
* [Objective-C](#objective-c)
* [OCaml](#ocaml)
* [Octave](#octave)
* [OpenMP](#openmp)
* [OpenResty](#openresty)
* [OpenSCAD](#openscad)
* [Perl](#perl)
* [Perl 6 / Raku](#perl-6--raku)
* [PHP](#php)
  * [CakePHP](#cakephp)
  * [CodeIgniter](#codeigniter)
  * [Drupal](#drupal)
  * [Laravel](#laravel)
  * [Symfony](#symfony)
  * [Zend](#zend)
* [PicoLisp](#picolisp)
* [PostgreSQL](#postgresql)
* [PowerShell](#powershell)
* [Processing](#processing)
* [Prolog](#prolog)
  * [Constraint Logic Programming](#constraint-logic-programming-extended-prolog)
* [PureScript](#purescript)
* [Python](#python)
  * [Django](#django)
  * [Flask](#flask)
  * [Kivy](#kivy)
  * [Pandas](#pandas)
  * [Pyramid](#pyramid)
  * [Tornado](#tornado)
* [QML](#qml)
* [R](#r)
* [Racket](#racket)
* [Raspberry Pi](#raspberry-pi)
* [REBOL](#rebol)
* [Ruby](#ruby)
  * [RSpec](#rspec)
  * [Ruby on Rails](#ruby-on-rails)
  * [Sinatra](#sinatra)
* [Rust](#rust)
* [Sage](#sage)
* [Scala](#scala)
  * [Lift](#lift)
  * [Play Scala](#play-scala)
* [Scheme](#scheme)
* [Scilab](#scilab)
* [Scratch](#scratch)
* [Sed](#sed)
* [Self](#self)
* [Smalltalk](#smalltalk)
* [Snap](#snap)
* [Spark](#spark)
* [Splunk](#splunk)
* [SQL (implementation agnostic)](#sql-implementation-agnostic)
* [SQL Server](#sql-server)
* [Standard ML](#standard-ml)
* [Subversion](#subversion)
* [Swift](#swift)
  * [Vapor](#vapor)
* [Tcl](#tcl)
* [TEI](#tei)
* [Teradata](#teradata)
* [Tizen](#tizen)
* [TLA](#tla)
* [TypeScript](#typescript)
* [Unix](#unix)
* [Verilog](#verilog)
* [VHDL](#vhdl)
* [Vim](#vim)
* [Visual Basic](#visual-basic)
* [Visual Prolog](#visual-prolog)
* [Web Services](#web-services)
* [Windows 8](#windows-8)
* [Windows Phone](#windows-phone)
* [Workflow](#workflow)
* [xBase (dBase / Clipper / Harbour)](#xbase-dbase--clipper--harbour)


### Meta-Lists

* [atariarchives.org](http://www.atariarchives.org) atariarchives.org makes books, information, and software for Atari and other classic computers available on the Web.
* [Bento](https://www.bento.io)
* [Bitsavers.org](http://bitsavers.trailing-edge.com)
* [Bookboon: IT & Programming](http://bookboon.com/en/it-programming-ebooks) Cookie required. (email address *requested*, not required)
* [Cheat Sheets (Free)](https://dzone.com/refcardz)
* [conceptf1.blogspot.com](http://conceptf1.blogspot.com/2013/11/list-of-freely-available-programming.html)
* [Free Smalltalk Books, collected by Stéphane Ducasse](http://stephane.ducasse.free.fr/FreeBooks.html)
* [Free Tech Books](http://www.freetechbooks.com)
* [Goalkicker](https://goalkicker.com) - Programming Notes for Professionals books
* [IBM Redbooks](http://www.redbooks.ibm.com)
* [InfoQ Minibooks](http://www.infoq.com/minibooks/)
* [InTech: Computer and Information Science](http://www.intechopen.com/subjects/computer-and-information-science)
* [JSBooks - directory of free javascript ebooks](https://github.com/revolunet/JSbooks)
* [Learn X in Y minutes](https://learnxinyminutes.com)
* [Learneroo Resources to Learn Programming](https://www.learneroo.com/modules/12/nodes/96)
* [Microsoft Guides to Software](https://blogs.msdn.microsoft.com/mssmallbiz/2014/07/07/largest-collection-of-free-microsoft-ebooks-ever-including-windows-8-1-windows-8-windows-7-office-2013-office-365-office-2010-sharepoint-2013-dynamics-crm-powershell-exchange-server-lync-2/)
* [Microsoft Press: Free E-Books](https://mva.microsoft.com/ebooks)
* [Microsoft Technologies 1, including books on Windows Azure, SharePoint, Visual Studio Guide, Windows phone development, ASP.net, Office365, etc. collection by Eric Ligman](https://blogs.msdn.microsoft.com/mssmallbiz/2012/07/27/large-collection-of-free-microsoft-ebooks-for-you-including-sharepoint-visual-studio-windows-phone-windows-8-office-365-office-2010-sql-server-2012-azure-and-more/)
* [Microsoft Technologies 2, including books on Windows Azure, SharePoint, Visual Studio Guide, Windows phone development, ASP.net, etc. collection by Eric Ligman](https://blogs.msdn.microsoft.com/mssmallbiz/2012/07/30/another-large-collection-of-free-microsoft-ebooks-and-resource-kits-for-you-including-sharepoint-2013-office-2013-office-365-duet-2-0-azure-cloud-windows-phone-lync-dynamics-crm-and-more/)
* [Microsoft Technologies 3, including books on Windows Azure, SharePoint, Visual Studio Guide, Windows phone development, ASP.net, etc. collection by Eric Ligman](https://blogs.msdn.microsoft.com/mssmallbiz/2017/07/11/largest-free-microsoft-ebook-giveaway-im-giving-away-millions-of-free-microsoft-ebooks-again-including-windows-10-office-365-office-2016-power-bi-azure-windows-8-1-office-2013-sharepo/)
* [O'Reilly's Open Books Project](http://www.oreilly.com/openbook/)
* [Papers we love](https://github.com/papers-we-love/papers-we-love)
* [Programming](https://en.wikibooks.org/wiki/Category%3aComputer_programming) - Wikibooks
* [Red Gate Books](http://www.red-gate.com/community/books/index)
* [Stef's Free Online Smalltalk Books](http://stephane.ducasse.free.fr/FreeBooks/)
* [TechBeamers.com](http://www.techbeamers.com)
* [TechBooksForFree.com](http://www.techbooksforfree.com)
* [The Definitive C++ Book Guide and List](http://stackoverflow.com/questions/388242/the-definitive-c-book-guide-and-list)
* [Theassayer.org](http://theassayer.org)
* [tutorialspoint](http://www.tutorialspoint.com)


### Graphics Programming

* [3D Game Shaders For Beginners](https://github.com/lettier/3d-game-shaders-for-beginners) - David Lettier (Git) [(HTML)](https://lettier.github.io/3d-game-shaders-for-beginners)
* [Blender 3D: Noob to Pro](https://en.wikibooks.org/wiki/Blender_3D%3A_Noob_to_Pro) - Wikibooks
* [Computer Graphics from scratch](http://gabrielgambetta.com/computer-graphics-from-scratch) - Gabriel Gambetta (:construction: *in process*)
* [DirectX manual](http://user.xmission.com/~legalize/book/download/index.html) (draft)
* [GPU Gems](https://developer.nvidia.com/gpugems/GPUGems/gpugems_pref01.html)
* [Graphics Programming Black Book](http://www.gamedev.net/page/resources/_/technical/graphics-programming-and-theory/graphics-programming-black-book-r1698) - Michael Abrash
* [Introduction to Modern OpenGL](https://open.gl)
* [Introduction to TouchDesigner 099](https://leanpub.com/introductiontotouchdesigner/) *(Leanpub account or valid email requested)*
* [Learn OpenGL](http://learnopengl.com) - Joey de Vries
* [Learning Modern 3D Graphics Programming](https://web.archive.org/web/20150225192611/http://www.arcsynthesis.org/gltut/index.html) - Jason L. McKesson (draft)
* [OpenGL](http://www.songho.ca/opengl/index.html) - Concepts and illustrations.
* [ShaderX series](http://www.realtimerendering.com/resources/shaderx/) - Wolfgang Engel
* [Tutorials for modern OpenGL](http://www.opengl-tutorial.org)
* [WebGL Insights](http://webglinsights.com) - Patrick Cozzi and Contributors


### Graphical User Interfaces

* [Programming with gtkmm 3](https://developer.gnome.org/gtkmm-tutorial/stable/)
* [Search User Interfaces](http://searchuserinterfaces.com/book/) - Marti A. Hearst
* [The GLib/GTK+ Development Platform](https://people.gnome.org/~swilmet/glib-gtk-dev-platform.pdf) - Sébastien Wilmet (PDF)


### GraphQL

* [Fullstack GraphQL](https://github.com/GraphQLCollege/fullstack-graphql)


### Language Agnostic

#### Algorithms & Data Structures

* [A Field Guide To Genetic Programming](http://dces.essex.ac.uk/staff/rpoli/gp-field-guide/toc.html) - Riccardo Poli et al.
* [Algorithmic Graph Theory](http://code.google.com/p/graphbook/)
* [Algorithms](https://en.wikibooks.org/wiki/Algorithms) - Wikibooks
* [Algorithms, 4th Edition](http://algs4.cs.princeton.edu/home/) - Robert Sedgewick and Kevin Wayne
* [Algorithms and Automatic Computing Machines (1963)](https://archive.org/details/Algorithms_And_Automatic_Computing_Machines) - B. A. Trakhtenbrot
* [Algorithms and Complexity](https://www.math.upenn.edu/~wilf/AlgoComp.pdf) - Herbert S. Wilf (PDF)
* [Algorithms Course Materials](http://jeffe.cs.illinois.edu/teaching/algorithms/) - Jeff Erickson
* [Analysis and Design of Algorithms](http://www.cse.iitd.ernet.in/~ssen/csl356/admin356.html) - Sandeep Sen, IIT Delhi
* [Animated Algorithm and Data Structure Visualization](http://visualgo.net) (Resource)
* [Annotated Algorithms in Python: Applications in Physics, Biology, and Finance](https://github.com/mdipierro/nlib) - Massimo di Pierro
* [Binary Trees](http://cslibrary.stanford.edu/110/BinaryTrees.pdf) (PDF)
* [Clever Algorithms](http://www.cleveralgorithms.com/nature-inspired/) - Jason Brownlee
* [CS Unplugged: Computer Science without a computer](http://csunplugged.org/books/)
* [Data Structures](http://www.cse.iitd.ernet.in/~suban/cs130/index.html) - Prof. Subhashis Banerjee, IIT Delhi
* [Data Structures (Into Java) - Paul N. Hilfinger](http://www-inst.eecs.berkeley.edu/~cs61b/fa14/book2/data-structures.pdf) (PDF)
* [Data Structures and Algorithms: Annotated Reference with Examples](https://web.archive.org/web/20170715160229/http://dotnetslackers.com/Community/files/folders/data-structures-and-algorithms/entry30283.aspx) - G. Barnett and L. Del Tongo
* [Data Structures Succinctly Part 1, Syncfusion](https://www.syncfusion.com/resources/techportal/ebooks/datastructurespart1) (PDF, Kindle) (email address *requested*, not required)
* [Data Structures Succinctly Part 2, Syncfusion](https://www.syncfusion.com/resources/techportal/ebooks/datastructurespart2) (PDF, Kindle) (email address *requested*, not required)
* [Elementary Algorithms](https://github.com/liuxinyu95/AlgoXY) - Larry LIU Xinyu
* [Foundations of Computer Science](http://infolab.stanford.edu/~ullman/focs.html) - Al Aho and Jeff Ullman
* [Geometry Algorithms](http://geomalgorithms.com) - Dan Sunday
* [Lectures Notes on Algorithm Analysis and Computational Complexity (Fourth Edition)](http://ianparberry.com/books/free/license.html) - Ian Parberry (use form at bottom of license)
* [LEDA: A Platform for Combinatorial and Geometric Computing](http://people.mpi-inf.mpg.de/~mehlhorn/LEDAbook.html) - K. Mehlhorn et al.
* [Linked List Basics](http://cslibrary.stanford.edu/103/LinkedListBasics.pdf) (PDF)
* [Linked List Problems](http://cslibrary.stanford.edu/105/LinkedListProblems.pdf) (PDF)
* [Matters Computational: Ideas, Algorithms, Source Code](http://www.jjj.de/fxt/fxtbook.pdf) (PDF)
* [Open Data Structures: An Introduction](http://opendatastructures.org) - Pat Morin
* [Planning Algorithms](http://planning.cs.uiuc.edu)
* [Problems on Algorithms (Second Edition)](http://ianparberry.com/books/free/license.html) - Ian Parberry (use form at bottom of license)
* [Purely Functional Data Structures (1996)](http://www.cs.cmu.edu/~rwh/theses/okasaki.pdf) - Chris Okasaki (PDF)
* [Sequential and parallel sorting algorithms](http://www.inf.fh-flensburg.de/lang/algorithmen/sortieren/algoen.htm)
* [Text Algorithms](http://igm.univ-mlv.fr/~mac/REC/text-algorithms.pdf) (PDF)
* [The Algorithm Design Manual](http://www8.cs.umu.se/kurser/TDBAfl/VT06/algorithms/BOOK/BOOK/BOOK.HTM)
* [The Art of Computer Programming](http://www.cs.utsa.edu/~wagner/knuth/) - Donald Knuth (fascicles, mostly volume 4)
* [The Design of Approximation Algorithms](http://www.designofapproxalgs.com/book.pdf) (PDF)
* [The Great Tree List Recursion Problem](http://cslibrary.stanford.edu/109/TreeListRecursion.pdf) (PDF)
* [The Kademlia Protocol Succinctly](https://www.syncfusion.com/ebooks/kademlia_protocol_succinctly) - Marc Clifton
* [Think Complexity](http://greenteapress.com/complexity/) (PDF)


#### Artificial Intelligence

* [Artificial Intelligence for Big Data](https://www.packtpub.com/free-ebooks/artificial-intelligence-big-data) - Anand Deshpande, Manish Kumar (Packt account *required*)
* [The Quest for Artificial Intelligence: A History of Ideas and Achievements](http://ai.stanford.edu/~nilsson/QAI/qai.pdf) - Nils J. Nilsson (PDF)


#### Cellular Automata

* [A New Kind of Science](https://www.wolframscience.com/nksonline/toc.html) - Stephen Wolfram
* [Cellular Automata Books](http://www.comunidad.escom.ipn.mx/genaro/Cellular_Automata_Repository/Books.html)


#### Cloud Computing

* [Azure Functions Succinctly, Syncfusion](https://www.syncfusion.com/ebooks/azure-functions-succinctly) (PDF, Kindle) (email address requested, not required)
* [Cloud Computing for Science and Engineering](https://cloud4scieng.org/chapters/) - Ian Foster, Dennis B. Gannon (:construction: *in process*)
* [Cloud Design Patterns](https://www.microsoft.com/en-us/download/details.aspx?id=42026)
* [Designing Distributed Systems](https://azure.microsoft.com/en-us/resources/designing-distributed-systems/) *(account required)*
* [Hands-On Cloud Administration in Azure](https://www.packtpub.com/free-ebooks/hands-cloud-administration-azure) - Mustafa Toroman (Packt account *required*)
* [Learn Azure in a Month of Lunches](https://azure.microsoft.com/mediahandler/files/resourcefiles/learn-azure-in-a-month-of-lunches/Learn_Azure_in_a_Month_of_Lunches.pdf) - Iain Foulds (PDF)
* [Monitoring Modern Infrastructure](https://www.datadoghq.com/ebook/monitoring-modern-infrastructure/) *(account required)*
* [Multi-tenant Applications for the Cloud, 3rd Edition](http://www.microsoft.com/en-us/download/details.aspx?id=29263)
* [OpenStack Operations Guide](https://docs.openstack.org/ops-guide/index.html)
* [Streamline microservice management with Istio Service Mesh](https://developers.redhat.com/books/introducing-istio-service-mesh-microservices/) *(account required)*
* [The Developer’s Guide to Azure](https://azure.microsoft.com/en-us/campaigns/developer-guide/)


#### Competitive Programming

* [Competitive Programmer's Handbook](https://cses.fi/book.html) - Antti Laaksonen (PDF)
* [Competitive Programming, 1st Edition](https://cpbook.net/#CP1details) (PDF)


#### Compiler Design

* [An Introduction to GCC](https://web.archive.org/web/20170326232435/http://www.network-theory.co.uk/docs/gccintro/index.html) - Brian Gough
* [Basics of Compiler Design (Anniversary Edition)](http://www.diku.dk/~torbenm/Basics/) - Torben Mogensen
* [Compiler Construction](http://www.ethoberon.ethz.ch/WirthPubl/CBEAll.pdf) (PDF)
* [Compiler Design in C (1990)](http://www.holub.com/software/compiler.design.in.c.html) - Allen Holub, Prentice Hall
* [Compiler Design: Theory, Tools, and Examples, C/C++ Edition](http://elvis.rowan.edu/~bergmann/books/cd/c_cpp/) - Seth D. Bergmann
* [Compiler Design: Theory, Tools, and Examples, Java Edition](http://elvis.rowan.edu/~bergmann/books/cd/java/) - Seth D. Bergmann
* [Compiling Scala for the Java Virtual Machine](http://lampwww.epfl.ch/~schinz/thesis-final-A4.pdf) - Michel Schinz (PDF)
* [Compiling Techniques (1969)](http://www.chilton-computing.org.uk/acl/literature/books/compilingtechniques/overview.htm) - F.R.A. Hopgood, Macdonald
* [Crafting Interpreters (:construction:)](http://www.craftinginterpreters.com) - Bob Nystrom (HTML)
* [Implementing Functional Languages: A Tutorial](http://research.microsoft.com/en-us/um/people/simonpj/Papers/pj-lester-book/) - Simon Peyton Jones, David Lester
* [Let's Build a Compiler](http://www.stack.nl/~marcov/compiler.pdf) (PDF)
* [Practical and Theoretical Aspects of Compiler Construction](http://web.stanford.edu/class/archive/cs/cs143/cs143.1128/) (class lectures and slides)
* [The ANTLR Mega Tutorial](https://tomassetti.me/antlr-mega-tutorial/)


#### Computer Science

* [Computer Science I - Draft](https://bitbucket.org/chrisbourke/computersciencei/src) - Dr. Chris Bourke (PDF) (:construction: *in process*)
* [Computer Science II - Draft](http://cse.unl.edu/~cbourke/ComputerScienceTwo.pdf) - Dr. Chris Bourke (PDF) (:construction: *in process*)


#### Computer Vision

* [Computer Vision](http://homepages.inf.ed.ac.uk/rbf/BOOKS/BANDB/bandb.htm) - Dana Ballard, Chris Brown
* [Computer Vision: Algorithms and Applications](http://szeliski.org/Book/) - Richard Szeliski
* [Computer Vision: Models, Learning, and Inference](http://www.computervisionmodels.com) - Simon J.D. Prince
* [Mastering OpenCV 4,Third Edition](https://www.packtpub.com/free-ebooks/mastering-opencv-4-third-edition) - Roy Shilkrot, David Millán Escrivá (Packt account *required*)
* [Programming Computer Vision with Python](http://programmingcomputervision.com) - Jan Erik Solem


#### Containers

* [Docker Cookbook, Second Edition](https://www.packtpub.com/free-ebooks/docker-cookbook-second-edition) - Ken Cochrane, Jeeva S. Chelladhurai, Neependra K Khare (Packt account *required*)
* [Docker Jumpstart](http://odewahn.github.io/docker-jumpstart/) - Andrew Odewahn
* [Kubernetes Cookbook, Second Edition](https://www.packtpub.com/free-ebooks/kubernetes-cookbook-second-edition) - Hideto Saito, Hui-Chuan Chloe Lee, Ke-Jou Carol Hsu (Packt account *required*)


#### Database

* [Database Explorations](http://www.dcs.warwick.ac.uk/~hugh/TTM/Database-Explorations-revision-2.pdf) (PDF)
* [Database Fundamentals](http://public.dhe.ibm.com/software/dw/db2/express-c/wiki/Database_fundamentals.pdf) (PDF)
* [Databases, Types, and The Relational Model: The Third Manifesto](http://www.dcs.warwick.ac.uk/~hugh/TTM/DTATRM.pdf) (PDF)
* [Foundations of Databases](http://webdam.inria.fr/Alice/)
* [Readings in Database Systems, 5th Ed.](http://www.redbook.io)
* [Temporal Database Management](http://people.cs.aau.dk/~csj/Thesis/) - Christian S. Jensen
* [The Theory of Relational Databases](http://web.cecs.pdx.edu/~maier/TheoryBook/TRD.html)


#### Datamining

* [A Programmer's Guide to Data Mining](http://guidetodatamining.com) - Ron Zacharski (Draft)
* [Data Jujitsu: The Art of Turning Data into Product](http://www.oreilly.com/data/free/data-jujitsu.csp) (email address *requested*, not required)
* [Data Mining Algorithms In R](https://en.wikibooks.org/wiki/Data_Mining_Algorithms_In_R) - Wikibooks
* [Internet Advertising: An Interplay among Advertisers, Online Publishers, Ad Exchanges and Web Users](http://arxiv.org/pdf/1206.1754v2.pdf) (PDF)
* [Introduction to Data Science](https://docs.google.com/file/d/0B6iefdnF22XQeVZDSkxjZ0Z5VUE/edit?pli=1) - Jeffrey Stanton
* [Introduction to Data Science](https://leanpub.com/datasciencebook) - Rafael A Irizarry *(Leanpub account or valid email requested)*
* [Mining of Massive Datasets](http://www.mmds.org)
* [School of Data Handbook](http://schoolofdata.org/handbook/)
* [Statistical inference for data science](https://leanpub.com/LittleInferenceBook/read) - Brian Caffo
* [Theory and Applications for Advanced Text Mining](http://www.intechopen.com/books/theory-and-applications-for-advanced-text-mining)


#### Information Retrieval

* [Information Retrieval: A Survey](http://www.csee.umbc.edu/csee/research/cadip/readings/IR.report.120600.book.pdf) (PDF)
* [Introduction to Information Retrieval](http://nlp.stanford.edu/IR-book/information-retrieval-book.html)


#### Licensing

* [Creative Commons: a user guide](http://www.aliprandi.org/cc-user-guide/) - Simone Aliprandi
* [Open Source Licensing Software Freedom and Intellectual Property Law](http://rosenlaw.com/oslbook/) - Lawrence Rosen
* [The Public Domain: Enclosing the Commons of the Mind](http://www.thepublicdomain.org/download/) - James Boyle


#### Machine Learning

* [A Brief Introduction to Machine Learning for Engineers](https://arxiv.org/pdf/1709.02840.pdf) - Osvaldo Simeone (PDF)
* [A Brief Introduction to Neural Networks](http://www.dkriesel.com/en/science/neural_networks)
* [A Course in Machine Learning](http://ciml.info/dl/v0_9/ciml-v0_9-all.pdf) (PDF)
* [A First Encounter with Machine Learning](https://www.ics.uci.edu/~welling/teaching/ICS273Afall11/IntroMLBook.pdf) (PDF)
* [An Introduction to Statistical Learning](http://www-bcf.usc.edu/~gareth/ISL/) - Gareth James, Daniela Witten, Trevor Hastie and Robert Tibshirani
* [Bayesian Reasoning and Machine Learning](http://web4.cs.ucl.ac.uk/staff/D.Barber/pmwiki/pmwiki.php?n=Brml.HomePage)
* [Deep Learning](http://www.deeplearningbook.org) - Ian Goodfellow, Yoshua Bengio and Aaron Courville
* [Foundations of Machine Learning, Second Edition](https://mitpress.ublish.com/ereader/7093/?preview=#page/Cover) - Mehryar Mohri, Afshin Rostamizadeh, Ameet Talwalkar
* [Gaussian Processes for Machine Learning](http://www.gaussianprocess.org/gpml/)
* [Information Theory, Inference, and Learning Algorithms](http://www.inference.phy.cam.ac.uk/itila/)
* [Interpretable Machine Learning](https://christophm.github.io/interpretable-ml-book/) - Christoph Molnar
* [Introduction to CNTK Succinctly](https://www.syncfusion.com/ebooks/cntk_succinctly) - James McCaffrey
* [Introduction to Machine Learning](http://arxiv.org/abs/0904.3664v1) - Amnon Shashua
* [Keras Succinctly](https://www.syncfusion.com/ebooks/keras-succinctly) - James McCaffrey
* [Learn Tensorflow](https://bitbucket.org/hrojas/learn-tensorflow) - Jupyter Notebooks
* [Learning Deep Architectures for AI](https://mila.quebec/wp-content/uploads/2019/08/TR1312.pdf) (PDF)
* [Machine Learning](http://www.intechopen.com/books/machine_learning)
* [Machine Learning for Data Streams](https://moa.cms.waikato.ac.nz/book-html/) - Albert Bifet, Ricard Gavaldà, Geoff Holmes, Bernhard Pfahringer
* [Machine Learning, Neural and Statistical Classification](http://www1.maths.leeds.ac.uk/~charles/statlog/)
* [Neural Networks and Deep Learning](http://neuralnetworksanddeeplearning.com)
* [Probabilistic Models in the Study of Language](http://idiom.ucsd.edu/~rlevy/pmsl_textbook/text.html) (Draft, with R code)
* [Reinforcement Learning: An Introduction](http://incompleteideas.net/book/bookdraft2017nov5.pdf) - Richard S. Sutton, Andrew G. Barto (PDF)
* [Speech and Language Processing (3rd Edition Draft)](https://web.stanford.edu/~jurafsky/slp3/ed3book.pdf) - Daniel Jurafsky, James H. Martin (PDF)
* [The Elements of Statistical Learning](https://web.stanford.edu/~hastie/ElemStatLearn/) - Trevor Hastie, Robert Tibshirani, and Jerome Friedman
* [The LION Way: Machine Learning plus Intelligent Optimization](https://intelligent-optimization.org/LIONbook/lionbook_3v0.pdf) - Roberto Battiti, Mauro Brunato (PDF)
* [The Python Game Book](http://thepythongamebook.com/en%3Astart)


#### Mathematics

* [A First Course in Linear Algebra](http://linear.ups.edu) - Robert A. Beezer
* [Advanced Algebra](http://www.math.stonybrook.edu/~aknapp/download/a2-alg-inside.pdf) - Anthony W. Knapp (PDF)
* [An Introduction to the Theory of Numbers](http://www.trillia.com/moser-number.html) - Leo Moser (PDF)
* [Basic Algebra](http://www.math.stonybrook.edu/~aknapp/download/b2-alg-inside.pdf) - Anthony W. Knapp (PDF)
* [Basics of Algebra, Topology, and Differential Calculus](http://www.cis.upenn.edu/~jean/math-basics.pdf) (PDF)
* [Bayesian Methods for Hackers](https://github.com/CamDavidsonPilon/Probabilistic-Programming-and-Bayesian-Methods-for-Hackers) - Cameron Davidson-Pilon
* [Book of Proof](http://www.people.vcu.edu/~rhammack/BookOfProof/) - Richard Hammack (PDF)
* [Calculus](http://ocw.mit.edu/ans7870/resources/Strang/Edited/Calculus/Calculus.pdf) - Gilbert Strang (PDF)
* [Calculus Made Easy](http://www.gutenberg.org/ebooks/33283) - Silvanus P. Thompson (PDF)
* [Category Theory for the Sciences](https://mitpress.ublish.com/ereader/77/?preview#page/Cover) - David I. Spivak
* [CK-12 Probability and Statistics - Advanced](http://www.ck12.org/book/Probability-and-Statistics---Advanced-%2528Second-Edition%2529/)
* [Collaborative Statistics](http://cnx.org/contents/5e0744f9-9e79-4348-9237-ed012213a2d6%4040.9)
* [Computational and Inferential Thinking. The Foundations of Data Science](https://www.inferentialthinking.com)
* [Computational Geometry](http://web.mit.edu/hyperbook/Patrikalakis-Maekawa-Cho/)
* [Concepts & Applications of Inferential Statistics](http://vassarstats.net/textbook/)
* [Differential Equations](http://tutorial.math.lamar.edu/Classes/DE/DE.aspx) - Paul Dawkins (PDF, use download menu to download)
* [Elementary Differential Equations](http://ramanujan.math.trinity.edu/wtrench/texts/TRENCH_DIFF_EQNS_I.PDF) - William F. Trench (PDF)
* [Essentials of Metaheuristics](http://cs.gmu.edu/~sean/book/metaheuristics/) - Sean Luke
* [Graph Theory](http://compalg.inf.elte.hu/~tony/Oktatas/TDK/FINAL/)
* [Introduction to Probability](http://www.dartmouth.edu/~chance/teaching_aids/books_articles/probability_book/book.html) - Charles M. Grinstead and J. Laurie Snell
* [Introduction to Probability and Statistics Spring 2014](http://ocw.mit.edu/courses/mathematics/18-05-introduction-to-probability-and-statistics-spring-2014/)
* [Introduction to Proofs](http://joshua.smcvt.edu/proofs/) - Jim Hefferon
* [Introduction to Statistical Thought](http://people.math.umass.edu/~lavine/Book/book.html) - Michael Lavine
* [Kalman and Bayesian Filters in Python](https://github.com/rlabbe/Kalman-and-Bayesian-Filters-in-Python)
* [Knapsack Problems - Algorithms and Computer Implementations](http://www.or.deis.unibo.it/knapsack.html) - Silvano Martello and Paolo Toth
* [Lecture Notes of Linear Algebra](http://home.iitk.ac.in/~psraj/mth102/lecture_notes.html) - Dr. P. Shunmugaraj, IIT Kanpur (PDF)
* [Linear Algebra](http://home.iitk.ac.in/~arlal/book/la.pdf) - Dr. Arbind K Lal, Sukant Pati (PDF) (:construction: *in process*)
* [Linear Algebra](https://www.math.ucdavis.edu/~linear/linear-guest.pdf) (PDF)
* [Linear Algebra by Jim Hefferon](http://joshua.smcvt.edu/linearalgebra) - Jim Hefferon
* [Mathematical Logic - an Introduction](http://www.ii.uib.no/~michal/und/i227/book/book.pdf) (PDF)
* [Mathematics, MTH101A](http://home.iitk.ac.in/~psraj/mth101/) - P. Shunmugaraj, IIT Kanpur
* [Non-Uniform Random Variate Generation](http://luc.devroye.org/rnbookindex.html) - Luc Devroye (PDF)
* [Number Theory](https://github.com/holdenlee/number-theory) - Holden Lee MIT
* [OpenIntro Statistics](https://www.openintro.org/stat/textbook.php)
* [Ordinary Differential Equations](https://en.wikibooks.org/wiki/Ordinary_Differential_Equations) - Wikibooks
* [Power Programming with Mathematica](http://mathematica.stackexchange.com/questions/16485/are-you-interested-in-purchasing-david-wagners-power-programming-with-mathemat/22724) - David B. Wagner
* [Probability and Statistics Cookbook](http://statistics.zone)
* [Probability and Statistics EBook](http://wiki.stat.ucla.edu/socr/index.php/Probability_and_statistics_EBook)
* [Seven Sketches in Compositionality: An Invitation to Applied Category Theory](https://arxiv.org/pdf/1803.05316.pdf) - Brendan Fong and David I. Spivak (PDF)
* [Statistics Done Wrong](http://www.statisticsdonewrong.com) - Alex Reinhart
* [Think Bayes: Bayesian Statistics Made Simple](http://www.greenteapress.com/thinkbayes/) - Allen B. Downey
* [Think Stats: Probability and Statistics for Programmers](http://greenteapress.com/thinkstats/) - Allen B. Downey (using Python)


#### Mathematics For Computer Science

* [A Mathematical Theory of Communication](https://archive.org/details/bstj27-4-623) - Claude E.Shannon
* [Discrete Structures for Computer Science: Counting, Recursion, and Probability](http://cglab.ca/~michiel/DiscreteStructures/) - Michiel Smid


#### Misc

* [2016 European Software Development Salary Survey](https://www.oreilly.com/radar/2016-european-software-development-salary-survey/)
* [2016 Software Development Salary Survey](https://www.oreilly.com/radar/2016-software-development-salary-survey-report/)
* [2D Game Development: From Zero To Hero](https://github.com/Penaz91/2DGD_F0TH) (:construction: *in process*)
* [97 Things Every Programmer Should Know - Extended](https://leanpub.com/97-Things-Every-Programmer-Should-Know-Extended) *(Leanpub account or valid email requested)*
* [A MACHINE MADE THIS BOOK ten sketches of computer science](http://ocaml-book.com/s/popbook.pdf) - JOHN WHITINGTON (PDF)
* [Ansible Up & Running (first three chapters)](https://www.ansible.com/ebooks) *(account required)*
* [Asterisk™: The Definitive Guide](http://solmu.org/pub/help/Asterisk/3nd_Edition_for_Asterisk_1.8)
* [Barcode Overview](http://www.tec-it.com/download/PDF/Barcode_Reference_EN.pdf) (PDF)
* [Bitcoin and Cryptocurrency Technologies](https://d28rh4a8wq0iu5.cloudfront.net/bitcointech/readings/princeton_bitcoin_book.pdf) -  Arvind Narayanan, Joseph Bonneau, Edward Felten, Andrew Miller, Steven Goldfeder (PDF)
* [Blockchain By Example](https://www.packtpub.com/free-ebooks/blockchain-example) - Bellaj Badr, Richard Horrocks, Xun (Brian) Wu (Packt account *required*)
* [Come, Let's Play: Scenario-Based Programming Using Live Sequence Charts](http://www.wisdom.weizmann.ac.il/~playbook/)
* [Communicating Sequential Processes](http://www.usingcsp.com/cspbook.pdf) - Tony Hoare (PDF)
* [Computer Musings](http://scpd.stanford.edu/knuth/index.jsp) (lectures by Donald Knuth)
* [Confessions of an Unintentional CTO: Lessons in Growing a Web App](http://www.jackkinsella.ie/books/confessions_of_an_unintentional_cto) - Jack Kinsella
* [Culture \& Empire: Digital Revolution](http://hintjens.com/books) (PDF)
* [Design With FontForge](http://designwithfontforge.com/en-US/index.html)
* [Designing Interfaces](http://designinginterfaces.com) - Jennifer Tidwell
* [DevDocs](http://devdocs.io) - Documents for Developers in 1 place
* [DevOps For Dummies (IBM Edition)](http://www.ibm.com/ibm/devops/us/en/resources/dummiesbooks/) (PDF)
* [Digital Signal Processing For Communications](http://www.sp4comm.org)
* [Digital Signal Processing For Engineers and Scientists](http://www.dspguide.com)
* ["DYNAMIC LINKED LIBRARIES": Paradigms of the GPL license in contemporary software](http://www.lulu.com/shop/http://www.lulu.com/shop/luis-enr%C3%ADquez-a/dynamic-linked-libraries-paradigms-of-the-gpl-license-in-contemporary-software/ebook/product-21419788.html) - Luis A. Enríquez
* [Effective DevOps with AWS, Second Edition](https://www.packtpub.com/free-ebooks/effective-devops-aws-second-edition) - Yogesh Raheja, Giuseppe Borgese, Nathaniel Felsen (Packt account *required*)
* [Essential Image Optimization](https://images.guide) - Addy Osmani
* [Foundations of Programming](http://openmymind.net/FoundationsOfProgramming.pdf) (PDF)
* [Game Programming Patterns](http://gameprogrammingpatterns.com) - Bob Nystrom
* [Getting Real](http://gettingreal.37signals.com)
* [Google Maps API Succinctly](https://www.syncfusion.com/ebooks/google_maps_api_succinctly) - Mark Lewin
* [Hacknot: Essays on Software Development](http://www.lulu.com/shop/ed-johnson/hacknot-essays-on-software-development/ebook/product-17544641.html) - Ed Johnson
* [High-Performance Scientific Computing](https://andreask.cs.illinois.edu/Teaching/HPCFall2012) (class lectures and slides)
* [HoloLens Succinctly](https://www.syncfusion.com/ebooks/hololens_succinctly) - Lars Klint
* [How Computers Work](http://www.fastchip.net/howcomputerswork/p1.html) - R. Young
* [How to Become a Programmer](http://softwarebyrob.wpengine.netdna-cdn.com/assets/Software_by_Rob%20_How_to_Become_a%20_Programmer_1.0.pdf) (PDF)
* [How to Think Like a Computer Scientist](http://openbookproject.net/thinkcs/) - Peter Wentworth, Jeffrey Elkner, Allen B. Downey, and Chris Meyers
* [Image Processing in C: Analyzing and Enhancing Digital Images](http://homepages.inf.ed.ac.uk/rbf/BOOKS/PHILLIPS/) - Dwayne Phillips
* [Industrial Cybersecurity](https://www.packtpub.com/free-ebooks/industrial-cybersecurity) - Pascal Ackerman (Packt account *required*)
* [Information Technology and the Networked Economy](http://florida.theorangegrove.org/og/file/49843a6a-9a9d-4bad-b4d4-d053f9cdf73e/1/InfoTechNetworkedEconomy.pdf) (PDF)
* [IRPF90 Fortran code generator](https://www.gitbook.com/book/scemama/irpf90/details) - Anthony Scemama
* [Learn Programming](https://progbook.org) - Antti Salonen
* [Learn to Program](https://pine.fm/LearnToProgram/)
* [Learning 30 Technologies in 30 Days: A Developer Challenge](https://blog.openshift.com/learning-30-technologies-in-30-days-a-developer-challenge/) - Shekhar Gulati
* [Linked Data Patterns: A pattern catalogue for modelling, publishing, and consuming Linked Data](http://patterns.dataincubator.org/book/) - Leigh Dodds, Ian Davis
* [Magic Ink: Information Software and The Graphical Interface](http://worrydream.com/#!/MagicInk) - Bret Victor
* [Mastering Bitcoin - Unlocking digital currencies](https://github.com/bitcoinbook/bitcoinbook) - Andreas M. Antonopoulos
* [Mastering ROS for Robotics Programming, Second Edition](https://www.packtpub.com/free-ebooks/mastering-ros-robotics-programming-second-edition) - Lentin Joseph, Jonathan Cacace (Packt account *required*)
* [Mobile Developer's Guide to the Galaxy](https://leanpub.com/mobiledevelopersguide) *(Leanpub account or valid email requested)*
* [Modeling Reactive Systems with Statecharts](http://www.wisdom.weizmann.ac.il/~harel/reactive_systems.html)
* [MSIX Succinctly](https://www.syncfusion.com/ebooks/msix-succinctly) - Matteo Pagani
* [Networks, Crowds, and Markets: Reasoning About a Highly Connected World](http://www.cs.cornell.edu/home/kleinber/networks-book/)
* [Object-Oriented Reengineering Patterns](http://win.ua.ac.be/~sdemey/) - Serge Demeyer, Stéphane Ducasse and Oscar Nierstrasz
* [Open Government; Collaboration, Transparency, and Participation in Practice](https://github.com/oreillymedia/open_government) - Daniel Lathrop, Laurel Ruma
* [Packt Publishing: A free book every day](https://www.packtpub.com/packt/offers/free-learning) (PDF, ePub, Mobi, Kindle) *(account required)*
* [PDQ: Pretty Darn Quick: An Agile, All-Purpose Methodology](https://leanpub.com/PDQ) - Jeff Franz-Lien  *(Leanpub account or valid email requested)*
* [Philosophy of Computer Science](http://www.cse.buffalo.edu/~rapaport/Papers/phics.pdf) (PDF)
* [PNG: The Definitive Guide](http://www.libpng.org/pub/png/book/)
* [Pointers And Memory](http://cslibrary.stanford.edu/102/PointersAndMemory.pdf) (PDF)
* [Principles of Computer System Design](http://ocw.mit.edu/resources/res-6-004-principles-of-computer-system-design-an-introduction-spring-2009/online-textbook/part_ii_open_5_0.pdf) (PDF)
* [Procedural Content Generation in Games](http://pcgbook.com) - Noor Shaker, Julian Togelius, Mark Nelson
* [Programming with Unicode](http://unicodebook.readthedocs.org)
* [Real-World Maintainable Software](https://www.oreilly.com/ideas/real-world-maintainable-software) - Abraham Marin-Perez
* [Record-Playback Test Automation: Sahi & Selenium IDE: Critical Evaluation of Record-Playback Automation Tools](https://leanpub.com/manualToAutomatedWithSeleniumIDEAndSahi) - Shashikant Jagtap  *(Leanpub account or valid email requested)*
* [Scientific Programming and Computer Architecture](https://divakarvi.github.io/bk-spca/spca.html) - Divakar Viswanath
* [Small Memory Software](http://www.smallmemory.com/book.html)
* [Writing Native Mobile Apps in a Functional Language Succinctly](https://www.syncfusion.com/ebooks/writing_native_mobile_apps_in_a_functional_language_succinctly) - Vassili Kaplan


#### MOOC

* [Coursera](https://www.coursera.org)
* [edX](https://www.edx.org)
* [freeCodeCamp](https://www.freecodecamp.org)
* [FutureLearn](https://www.futurelearn.com)
* [MIT OCW](http://ocw.mit.edu)
* [NPTEL](https://onlinecourses.nptel.ac.in)
* [openHPI](https://open.hpi.de)
* [openSAP](https://open.sap.com)
* [Platzi](https://courses.platzi.com)
* [Udacity](https://www.udacity.com)


#### Networking

* [An Introduction to Computer Networks](http://intronetworks.cs.luc.edu) (HTML, PDF, Kindle)
* [Bits, Signals, and Packets: An Introduction to Digital Communications and Networks](http://ocw.mit.edu/courses/electrical-engineering-and-computer-science/6-02-introduction-to-eecs-ii-digital-communication-systems-fall-2012/readings/)
* [Code Connected vol.1](http://hintjens.wdfiles.com/local--files/main%3Afiles/cc1pe.pdf) (PDF) (book on ZeroMQ)
* [Computer Networking : Principles, Protocols and Practice](http://cnp3book.info.ucl.ac.be/1st/html/index.html) (HTML, ePub, PDF, Kindle)
* [Computer Networks: A Systems Approach](https://book.systemsapproach.org) - Larry Peterson and Bruce Davie (HTML, epub, mobi, PDF)
* [Distributed systems for fun and profit](http://book.mixu.net/distsys/single-page.html)
* [High-Performance Browser Networking](https://hpbn.co) - Ilya Grigorik
* [HTTP Succinctly, Syncfusion](https://www.syncfusion.com/resources/techportal/ebooks/http) (PDF, Kindle) (email address *requested*, not required)
* [HTTP2 Explained](http://daniel.haxx.se/http2/) - Daniel Stenberg
* [IPv6 for IPv4 Experts](https://sites.google.com/site/yartikhiy/home/ipv6book) - Yar Tikhiy (PDF)
* [The TCP/IP Guide](http://www.tcpipguide.com/free/t_toc.htm)
* [Understanding IP Addressing: Everything you ever wanted to know](http://pages.di.unipi.it/ricci/501302.pdf) (PDF)
* [ZeroMQ Guide](http://zguide.zeromq.org/page%3Aall)


#### Open Source Ecosystem

* [Data Journalism Handbook](http://datajournalismhandbook.org)
* [Free as in Freedom: Richard Stallman and the free software revolution](https://archive.org/details/faif-2.0) - Sam Williams (PDF)
* [Free for All](https://unglue.it/work/136445/) - Peter Wayner
* [Free Software, Free Society: Selected Essays of Richard M. Stallman](http://shop.fsf.org/product/free-software-free-society-2/)
* [Getting Started with InnerSource](http://www.oreilly.com/programming/free/getting-started-with-innersource.csp) (email address *requested*, not required)
* [Getting started with Open source development](http://public.dhe.ibm.com/software/dw/db2/express-c/wiki/Getting_started_with_open_source_development_p2.pdf) (PDF)
* [GitLab Handbook](https://about.gitlab.com/handbook/)
* [How to get started with open source](https://opensource.com/resources/ebook/how-get-started-open-source) (ePub & ODT)
* [Innovation Happens Elsewhere](http://dreamsongs.com/IHE/IHE.html) - Ron Goldman, Richard P. Gabriel
* [Open Advice: FOSS: What We Wish We Had Known When We Started](http://open-advice.org)
* [Open source in Brazil](https://www.oreilly.com/ideas/open-source-in-brazil) - Andy Oram
* [Producing Open Source Software](http://producingoss.com) - Karl Fogel
* [The Architecture of Open Source Applications: Vol. 1: Elegance, Evolution, and a Few Fearless Hacks; Vol. 2: Structure, Scale, and a Few More Feerless Hacks](http://www.aosabook.org/en/index.html)
* [The Art of Community](http://artofcommunityonline.org/Art_of_Community_Second_Edition.pdf) - Jono Bacon (PDF)
* [The Cathedral and the Bazaar](http://www.catb.org/esr/writings/cathedral-bazaar/) - Eric S. Raymond
* [The Future of the Internet](http://futureoftheinternet.org) - Jonathan Zittrain
* [The Open Source Way](http://www.theopensourceway.org/book/)
* [The Wealth of Networks: How Social Production Transforms Markets and Freedom](http://cyber.law.harvard.edu/wealth_of_networks/Main_Page) - Yochai Benkler


#### Operating Systems

* [A short introduction to operating systems (2001)](http://markburgess.org/os/os.pdf) - Mark Burgess (PDF)
* [Computer Science from the Bottom Up](http://www.bottomupcs.com)
* [How to Make a Computer Operating System](https://github.com/SamyPesse/How-to-Make-a-Computer-Operating-System) (:construction: *in process*)
* [How to write a simple operating system in assembly language](http://mikeos.sourceforge.net/write-your-own-os.html) - Mike Saunders (HTML)
* [Operating Systems and Middleware](https://gustavus.edu/mcs/max/os-book/) (PDF and LaTeX)
* [Operating Systems: Three Easy Pieces](http://pages.cs.wisc.edu/~remzi/OSTEP/) (PDF)
* [Practical File System Design: The Be File System](http://www.nobius.org/~dbg/practical-file-system-design.pdf) - Dominic Giampaolo (PDF)
* [Project Oberon: The Design of an Operating System, a Compiler, and a Computer](http://people.inf.ethz.ch/wirth/ProjectOberon/index.html) - Niklaus Wirth & Jürg Gutknecht (PDF)
* [The Art of Unix Programming](http://catb.org/esr/writings/taoup/html/) - Eric S. Raymond
* [The Design and Implementation of the Anykernel and Rump Kernels](http://www.fixup.fi/misc/rumpkernel-book/) - Antti Kantee
* [The little book about OS development](https://littleosbook.github.io) - Erik Helin, Adam Renberg
* [The Little Book of Semaphores](http://greenteapress.com/semaphores/) - Allen B. Downey
* [Think OS: A Brief Introduction to Operating Systems](http://www.greenteapress.com/thinkos/index.html) - Allen B. Downey (PDF)
* [UNIX Application and System Programming, lecture notes](http://www.compsci.hunter.cuny.edu/~sweiss/course_materials/unix_lecture_notes.php) - Prof. Stewart Weiss (PDF)
* [Writing a Simple Operating System from Scratch](http://www.cs.bham.ac.uk/~exr/lectures/opsys/10_11/lectures/os-dev.pdf) - Nick Blundell (PDF)
* [Xv6, a simple Unix-like teaching operating system](https://pdos.csail.mit.edu/6.828/2012/xv6.html)


#### Parallel Programming

* [High Performance Computing](http://cnx.org/contents/bb821554-7f76-44b1-89e7-8a2a759d1347%405.2) - Charles Severance & Kevin Dowd (PDF, ePUB)
* [High Performance Computing Training](https://web.archive.org/web/20170702124132/https://hpc.llnl.gov/training/tutorials) (LLNL materials)
* [High-Performance Scientific Computing](https://andreask.cs.illinois.edu/Teaching/HPCFall2012) (class lectures and slides)
* [Introduction to High-Performance Scientific Computing](http://pages.tacc.utexas.edu/~eijkhout/istc/istc.html) - Victor Eijkhout
* [Introduction to Parallel Computing](https://computing.llnl.gov/tutorials/parallel_comp/) - Blaise Barney
* [Is Parallel Programming Hard, And, If So, What Can You Do About It?](https://www.kernel.org/pub/linux/kernel/people/paulmck/perfbook/perfbook.html) - Paul E. McKenney
* [Programming on Parallel Machines; GPU, Multicore, Clusters and More](http://heather.cs.ucdavis.edu/parprocbook) - Norm Matloff
Kerridge (PDF) (email address *requested*, not required)
* [The OpenCL Programming Book](https://us.fixstars.com/products/opencl/book/OpenCLProgrammingBook/contents/)
* [Using Concurrency and Parallelism Effectively – I](http://bookboon.com/en/using-concurrency-and-parallelism-effectively-i-ebook) - Jon Kerridge (PDF) (email address *requested*, not required)
* [Using Concurrency and Parallelism Effectively – II](http://bookboon.com/en/using-concurrency-and-parallelism-effectively-ii-ebook) - Jon


#### Partial Evaluation

* [Partial Evaluation and Automatic Program Generation](http://www.itu.dk/people/sestoft/pebook/) - (PDF) Jones, Gomard and Sestoft


#### Professional Development

* [Clean Code Developer: An initiative for more professionalism in software development](https://www.gitbook.com/book/ccd_school/clean-code-developer-com/details) (:construction: *in process*)
* [Confessions of an IT Manager](https://www.red-gate.com/library/confessions-of-an-it-manager) - Phil Factor (PDF)
* [Don't Just Roll the Dice](https://www.red-gate.com/library/dont-just-roll-the-dice) - Neil Davidson (PDF)
* [How to Do What You Love & Earn What You’re Worth as a Programmer](https://leanpub.com/dowhatyoulove/read) - Reginald Braithwaite
* [Professional Software Development For Students](https://mixmastamyk.bitbucket.io/pro_soft_dev/intro.html) - Mike G. Miller
* [What I've Learned From Failure](https://leanpub.com/shippingsoftware/read) - Reginald Braithwaite


#### Programming Paradigms

* [Flow based Programming](http://jpaulmorrison.com/fbp/) - J Paul Morrison
* [Introduction to Functional Programming](http://www.cl.cam.ac.uk/teaching/Lectures/funprog-jrh-1996/) - J. Harrison
* [Mostly Adequate Guide to Functional Programming](https://www.gitbook.com/book/drboolean/mostly-adequate-guide/details)
* [Type Theory and Functional Programming](https://www.cs.kent.ac.uk/people/staff/sjt/TTFP/)


#### Regular Expressions

* [Regular Expressions for Regular Folk](https://refrf.shreyasminocha.me) - Shreyas Minocha
* [RexEgg](http://www.rexegg.com)
* [The 30 Minute Regex Tutorial](http://www.codeproject.com/Articles/9099/The-Minute-Regex-Tutorial) - Jim Hollenhorst
* [The Bastards Book of Regular Expressions: Finding Patterns in Everyday Text](https://leanpub.com/bastards-regexes) - Dan Nguyen  *(Leanpub account or valid email requested)*


#### Reverse Engineering

* [BIOS Disassembly Ninjutsu Uncovered 1st Edition](http://bioshacking.blogspot.co.uk/2012/02/bios-disassembly-ninjutsu-uncovered-1st.html) - Darmawan Salihun (PDF)
* [Hacking the Xbox: An Introduction to Reverse Engineering](https://www.nostarch.com/xboxfree/) - Andrew "bunnie" Huang
* [iOS App Reverse Engineering](https://github.com/iosre/iOSAppReverseEngineering) (PDF)
* [Reverse Engineering for Beginners](http://beginners.re) - Dennis Yurichev (PDF)


#### Security

* [A Graduate Course in Applied Cryptography](http://toc.cryptobook.us)
* [Crypto 101 - Crypto for everyone](https://www.crypto101.io)
* [CryptoParty Handbook](https://unglue.it/work/141611/)
* [Handbook of Applied Cryptography](http://cacr.uwaterloo.ca/hac/index.html)
* [How to deal with Passwords](https://github.com/MHM5000/pass)
* [Intrusion Detection Systems with Snort](http://ptgmedia.pearsoncmg.com/images/0131407333/downloads/0131407333.pdf) (PDF)
* [OpenSSL Cookbook](https://www.feistyduck.com/library/openssl-cookbook/)
* [OWASP Mobile Security Testing Guide](https://mobile-security.gitbook.io/mobile-security-testing-guide/) - Bernhard Mueller et al.
* [OWASP Testing Guide 4.0](https://www.owasp.org/images/1/19/OTGv4.pdf) (PDF)
* [OWASP Top 10 for .NET Developers](http://www.troyhunt.com/2011/12/free-ebook-owasp-top-10-for-net.html)
* [Security Engineering](http://www.cl.cam.ac.uk/~rja14/book.html)


#### Software Architecture

* [Agile Planning: From Ideas to Story Cards](https://launchschool.com/books/agile_planning) - Launch School
* [Architectural Styles and the Design of Network-based Software Architectures](http://www.ics.uci.edu/~fielding/pubs/dissertation/top.htm) - Roy Thomas Fielding
* [Best Kept Secrets of Peer Code Review](http://smartbear.com/lp/ebook/collaborator/secrets-of-peer-code-review/)
* [Data-Oriented Design](http://www.dataorienteddesign.com/dodmain/dodmain.html)
* [Developing Reactive Microservices](https://info.lightbend.com/COLL-20XX-Developing-Reactive-Microservices_Landing-Page.html) (email address *requested*, not required)
* [Domain Driven Design Quickly](http://www.infoq.com/minibooks/domain-driven-design-quickly)
* [DSL Engineering: Designing, Implementing and Using Domain-Specific Languages](http://dslbook.org) - Markus Voelter
* [Exploring CQRS and Event Sourcing](https://msdn.microsoft.com/en-us/library/jj554200.aspx) - (EPUB, PDF)
* [Guide to the Software Engineering Body of Knowledge](https://www.computer.org/education/bodies-of-knowledge/software-engineering/v3) (email adddress *requested*)
* [How to Design Programs](http://www.htdp.org)
* [How to Write Unmaintainable Code](http://mindprod.com/jgloss/unmain.html)
* [Kanban and Scrum - making the most of both](http://www.infoq.com/minibooks/kanban-scrum-minibook)
* [Kanban for skeptics](https://leanpub.com/kanbanforskeptics) - Nick Oostvogels  *(Leanpub account or valid email requested)*
* [Microservices AntiPatterns and Pitfalls](https://www.oreilly.com/programming/free/files/microservices-antipatterns-and-pitfalls.pdf) (PDF)
* [Microservices vs. Service-Oriented Architecture](https://www.oreilly.com/programming/free/files/microservices-vs-service-oriented-architecture.pdf) (PDF)
* [Migrating to Cloud-Native Application Architectures](https://developers.redhat.com/books/migrating-microservice-databases-relational-monolith-distributed-data/) (email address *requested*) (PDF)
* [Naked objects](http://downloads.nakedobjects.net/resources/Pawson%20thesis.pdf) - Richard Pawson (PDF)
* [OAuth - The Big Picture](https://pages.apigee.com/oauth-big-picture-ebook.html) (email address *requested*)
* [Object-Oriented Reengineering Patterns](http://scg.unibe.ch/download/oorp/) - S. Demeyer, S. Ducasse and O. Nierstrasz
* [Practicing Domain-Driven Design - Part 1](https://leanpub.com/Practicing-DDD) - Scott Millett  *(Leanpub account or valid email requested)*
* [Reactive Microservices Architecture](https://www.lightbend.com/ebooks/reactive-microservices-architecture-design-principles-for-distributed-systems-oreilly) (email address *requested*)
* [Reactive Microsystems: The Evolution of Microservices at Scale](https://www.lightbend.com/ebooks/reactive-microsystems-evolution-of-microservices-scalability-oreilly) (email address *requested*)
* [Scrum and XP from the Trenches](http://www.infoq.com/minibooks/scrum-xp-from-the-trenches-2)
* [Serverless apps: Architecture, patterns, and Azure implementation](https://docs.microsoft.com/en-us/dotnet/standard/serverless-architecture/)
* [Serverless Design Patterns and Best Practices](https://www.packtpub.com/free-ebooks/serverless-design-patterns-and-best-practices) - Brian Zambrano (Packt account *required*)
* [Site Reliability Engineering](https://landing.google.com/sre/book/index.html)
* [Software Architecture Patterns](http://www.oreilly.com/programming/free/software-architecture-patterns.csp) (email address *requested*, not required)
* [Software Engineering for Internet Applications](http://philip.greenspun.com/seia/)
* [Test Driven Development, Extensive Tutorial](https://github.com/grzesiek-galezowski/tdd-ebook) - Grzegorz Gałęzowski
* [Web API Design](https://pages.apigee.com/rs/apigee/images/api-design-ebook-2012-03.pdf) - Brian Mulloy (PDF)
* [Working with Web APIs](https://launchschool.com/books/working_with_apis) - Launch School
* [Your API Is Bad](https://leanpub.com/yourapiisbad/read) - Paddy Foran


#### Standards

* [Linux Standard Base](http://refspecs.linuxfoundation.org/lsb.shtml)
* [UNIX - The POSIX Standard - IEEE Std 1003.1](https://github.com/geoff-codes/posix-standard)


#### Theoretical Computer Science

* [Building Blocks for Theoretical Computer Science](http://mfleck.cs.illinois.edu/building-blocks/index.html) - Margaret M. Fleck
* [Category Theory for Computing Science](http://www.tac.mta.ca/tac/reprints/articles/22/tr22.pdf) (PDF)
* [Category Theory for Programmers](https://github.com/hmemcpy/milewski-ctfp-pdf) - Bartosz Milewski (PDF)
* [Homotopy Type Theory: Univalent Foundations of Mathematics](http://homotopytypetheory.org/book/) (PDF)
* [Introduction to Computer Science](http://www.cse.iitd.ernet.in/~suban/CSL102/) - Prof. Subhashis Banerjee, IIT Delhi
* [Introduction to Computing](http://www.computingbook.org)
* [Introduction to Theory of Computation](http://cglab.ca/~michiel/TheoryOfComputation/) - Anil Maheshwari and Michiel Smid (PDF)
* [Models of Computation](http://cs.brown.edu/people/jes/book/) - John E. Savage
* [Practical Foundations for Programming Languages, Preview](https://www.cs.cmu.edu/~rwh/pfpl/2nded.pdf) - Robert Harper (PDF)
* [Principles of Programming Languages](https://web.archive.org/web/20150418034451/http://www.cs.jhu.edu/~scott/pl/book/dist/) - Scott F. Smith
* [Programming and Programming Languages](https://papl.cs.brown.edu/2019/) - Shriram Krishnamurthi
* [Programming in Martin-Löf's Type Theory](http://www.cse.chalmers.se/research/group/logic/book/) - Bengt Nordstroem
* [Programming Languages: Application and Interpretation (2nd Edition)](http://cs.brown.edu/~sk/Publications/Books/ProgLangs/) - Shriram Krishnamurthi
* [Programming Languages: Theory and Practice](http://people.cs.uchicago.edu/~blume/classes/aut2008/proglang/text/offline.pdf) - Robert Harper (PDF)
* [Semantics with Applications: A Formal Introduction](http://www.cs.ru.nl/~herman/onderwijs/semantics2019/wiley.pdf) - Hanne Riis Nielson, Flemming Nielson (PDF)
* [Structure and Interpretation of Computer Programs](https://mitpress.mit.edu/sicp/)
* [Structure and Interpretation of Computer Programs](http://sarabander.github.io/sicp/html/index.xhtml)
* [The Black Art of Programming](http://self.gutenberg.org/wplbn0002828847-the-black-art-of-programming-by-mcilroy-mark.aspx?) - Mark McIlroy
* [The Craft of Programming](https://kilthub.cmu.edu/articles/The_Craft_of_Programming/6610514) - John C. Reynolds
* [Think Complexity](http://www.greenteapress.com/compmod/) - Allen B. Downey


#### Web Performance

* [Book of Speed](http://www.bookofspeed.com) - Stoyan Stefanov
* [Designing for Performance](http://designingforperformance.com) - Lara Hogan
* [High Performance Accelerated Websites](https://thisisyuu.github.io/ebook) - Anshul (HTML) (:construction: *in process*)
* [High Performance Browser Networking](https://hpbn.co) - Ilya Grigorik
* [Mature Optimization](http://carlos.bueno.org/optimization/mature-optimization.pdf) - Carlos Bueno (PDF)


### ABAP

* [SAP Code Style Guides - Clean ABAP](https://github.com/SAP/styleguides/blob/master/clean-abap/CleanABAP.md)


### Ada

* [A Guide to Ada for C and C++ Programmers](http://www.cs.uni.edu/~mccormic/4740/guide-c2ada.pdf) (PDF)
* [Ada Distilled](http://www.adapower.com/pdfs/AdaDistilled07-27-2003.pdf) (PDF)
* [Ada for the C++ or Java Developer](https://www.adacore.com/uploads/books/pdf/Ada_for_the_C_or_Java_Developer-cc.pdf) - Quentin Ochem (PDF)
* [Ada Programming](https://en.wikibooks.org/wiki/Ada_Programming) - Wikibooks
* [Ada Reference Manual - ISO/IEC 8652:2012(E) Language and Standard Libraries](http://www.ada-auth.org/standards/12rm/RM-Final.pdf) (PDF)
* [Introduction To Ada](https://learn.adacore.com/courses/intro-to-ada/index.html)
* [Introduction To SPARK](https://learn.adacore.com/courses/SPARK_for_the_MISRA_C_Developer/index.html)
* [SPARK for the MISRA-C Developer](https://learn.adacore.com/pdf_books/courses/SPARK_for_the_MISRA_C_Developer.pdf) - Yannick Moy (PDF)
* [The Big Online Book of Linux Ada Programming](http://www.pegasoft.ca/resources/boblap/book.html)


### Agda

* [Agda Tutorial](http://people.inf.elte.hu/divip/AgdaTutorial/Index.html)
* [Programming Language Foundations in Agda](https://plfa.github.io) - Philip Wadler and Wen Kokke


### Alef

* [Alef Language Reference Manual](http://doc.cat-v.org/plan_9/2nd_edition/papers/alef/ref)


### Android

* [Android 4 App Development Essentials](http://www.techotopia.com/index.php/Android_4_App_Development_Essentials)
* [Android Notes](https://goalkicker.com/AndroidBook) (PDF)
* [Android Programming Succinctly, Syncfusion](https://www.syncfusion.com/resources/techportal/ebooks/android) ([PDF](https://www.syncfusion.com/Account/Logon?ReturnUrl=%2fresources%2ftechportal%2febooks%2fandroid), [Kindle](https://www.syncfusion.com/Account/Logon?ReturnUrl=%2fresources%2ftechportal%2febooks%2fandroid)) (email address *requested*, not required)
* [CodePath Android Cliffnotes](https://github.com/codepath/android_guides/wiki)
* [Coreservlets Android Programming Tutorial](http://www.coreservlets.com/android-tutorial/)
* [Expert Android and Eclipse development knowledge](http://www.vogella.com/tutorials/android.html)
* [Google Android Developer Training](https://developer.android.com/guide)
* [Styling Android](https://blog.stylingandroid.com)
* [The Busy Coder's Guide to Android Development](https://commonsware.com/Android/4-2-free) (PDF - older versions)
* [Tutorial Point Android Tutorial](http://www.tutorialspoint.com/android/android_tutorial.pdf) (PDF)


### APL

* [A Practical Introduction to APL1 & APL2](http://robertson.uk.net) - Graeme Donald Robertson (PDF)
* [A Practical Introduction to APL3 & APL4](http://robertson.uk.net) - Graeme Donald Robertson (PDF)
* [Mastering Dyalog APL](http://www.dyalog.com/mastering-dyalog-apl.htm) (PDF)


### Arduino

* [Arduino Programming Notebook](http://www.lulu.com/shop/brian-evans/arduino-programming-notebook/ebook/product-18598708.html) - Brian Evans
* [Introduction to Arduino](http://playground.arduino.cc/Main/ManualsAndCurriculum)
* [Introduction to Arduino : A piece of cake!](http://www.introtoarduino.com) - Alan G. Smith


### ASP.NET

* [ASP.NET Core 2 Succinctly](https://www.syncfusion.com/ebooks/aspnet-core-2-succinctly) - Simone Chiaretta, Ugo Lattanzi
* [ASP.NET MVC Music Store](http://mvcmusicstore.codeplex.com)
* [ASP.NET WebHooks Succinctly](https://www.syncfusion.com/ebooks/aspnet_webhooks_succinctly) - Gaurav Arora


### Assembly Language

* [An introduction to reverse engineering for beginners](https://beginners.re/RE4B-EN.pdf) - Dennis Yurichev (PDF)
* [Assembly Language Succinctly](https://www.syncfusion.com/resources/techportal/details/ebooks/assemblylanguage) (PDF)
* [PC Assembly Language](http://pacman128.github.io/pcasm/) - P. A. Carter
* [Professional Assembly Language](https://web.archive.org/web/20170329045538/http://blog.hit.edu.cn:80/jsx/upload/AT%EF%BC%86TAssemblyLanguage.pdf) (PDF)
* [Programming from the Ground Up](https://download-mirror.savannah.gnu.org/releases/pgubook/ProgrammingGroundUp-1-0-booksize.pdf) - Jonathan Bartlett (PDF)
* [Ralf Brown's Interrupt List](http://www.ctyme.com/rbrown.htm)
* [Software optimization resources](http://www.agner.org/optimize/) - A. Fog
* [x86-64 Assembly Language Programming with Ubuntu](http://www.egr.unlv.edu/~ed/x86.html) - Ed Jorgensen (PDF)
* [x86 Assembly](https://en.wikibooks.org/wiki/X86_Assembly) - Wikibooks


#### Non-X86

* [Easy 6502](http://skilldrick.github.io/easy6502/) - Nick Morgan
* [Machine Code for Beginners [Z80 and 6502 CPUs]](https://usborne.com/browse-books/features/computer-and-coding-books/) - Lisa Watts and Mike Wharton (PDF) *(Scroll to bottom and click on book cover)*
* [Machine Language for Beginners](https://archive.org/details/ataribooks-machine-language-for-beginners) - Richard Mansfield [6502 CPU]
* [Programmed Introduction to MIPS Assembly Language](http://chortle.ccsu.edu/AssemblyTutorial/index.html)
* [The Second Book of Machine Language](http://www.atariarchives.org/2bml/)


### AutoHotkey

* [AHKbook - the book for AutoHotkey](http://ahkscript.github.io/ahkbook/index.html)
* [AutoHotkey Official Documentation](https://autohotkey.com/docs/AutoHotkey.htm) ([CHM](https://autohotkey.com/download/1.1/AutoHotkeyHelp.zip))


### Autotools

* [Autotools Mythbuster](https://autotools.io/index.html)
* [GNU Autoconf, Automake and Libtool](http://sourceware.org/autobook/)


### Awk

* [A User's Guide for GNU AWK](http://www.math.utah.edu/docs/info/gawk_toc.html)
* [An Awk Primer](https://en.wikibooks.org/wiki/An_Awk_Primer) - Wikibooks
* [Awk](http://www.grymoire.com/Unix/Awk.html) - Bruce Barnett


### Bash

* [Advanced Bash-Scripting Guide](http://tldp.org/LDP/abs/html/) - M. Cooper (HTML)
* [Bash Guide for Beginners (2008)](http://www.tldp.org/LDP/Bash-Beginners-Guide/html/) - M. Garrels (HTML)
* [Bash Notes](https://goalkicker.com/BashBook) (PDF)
* [Bash Notes for Professionals](http://books.goalkicker.com/BashBook/) - Compiled from StackOverflow documentation (3.x) (PDF)
* [BASH Programming (2000)](http://tldp.org/HOWTO/Bash-Prog-Intro-HOWTO.html) - Mike G. (HTML)
* [Bash Reference Manual](http://www.gnu.org/software/bash/manual/bashref.html) (HTML)
* [Bash tutorial](https://web.archive.org/web/20180328183806/http://gdrcorelec.ups-tlse.fr/files/bash.pdf) - Anthony Scemama (PDF)
* [BashGuide](http://mywiki.wooledge.org/BashGuide) - Maarten Billemont (HTML) [(PDF)](http://s.ntnu.no/bashguide.pdf)
* [Conquering the Command Line](http://conqueringthecommandline.com/book/frontmatter) - Mark Bates (HTML)
* [Getting Started with BASH](http://www.hypexr.org/bash_tutorial.php) (HTML)
* [Google Shell Style Guide](https://google.github.io/styleguide/shell.xml) - Paul Armstrong (HTML)
* [Introduction to the Command Line](https://launchschool.com/books/command_line) - Launch School (HTML)
* [Linux Fundamentals](http://linux-training.be/linuxfun.pdf) - Paul Cobbaut (PDF)
* [Linux Shell Scripting Tutorial - A Beginner's Handbook (2002)](http://www.freeos.com/guides/lsst/) - Vivek G. Gite (HTML)
* [Linux Shell Scripting Tutorial (LSST) v2.0](https://bash.cyberciti.biz/guide/Main_Page) - Vivek Gite (HTML)
* [Slackbook (2005)](http://slackbook.org) - Alan Hicks, Chris Lumens, David Cantrell and Logan Johnson (HTML, DocBook, Postscript, PDF)
* [The Bash Academy](http://guide.bash.academy) - Maarten Billemont (HTML)
* [The Linux Command Line](http://linuxcommand.org/tlcl.php) - William E. Shotts, Jr. (PDF)
* [Writing Shell Scripts](http://linuxcommand.org/lc3_writing_shell_scripts.php) - William E. Shotts, Jr. (HTML)


### Basic

* [10 PRINT CHR$(205.5+RND(1)); : GOTO 10](http://10print.org) - Nick Montfort, Patsy Baudoin, John Bell,Ian Bogost, Jeremy Douglass, Mark C. Marino, Michael Mateas, Casey Reas, Mark Sample, Noah Vawter
* [A beginner's guide to Gambas](http://distro.ibiblio.org/vectorlinux/Uelsk8s/GAMBAS/gambas-beginner-guide.pdf) - John W. Rittinghouse (PDF)
* [Pick/Basic: A Programmer's Guide](http://www.jes.com/pb/) - Jonathan E. Sisk
* [Visual Basic Essentials](http://www.techotopia.com/index.php/Visual_Basic_Essentials)


### BETA

* [Object-Oriented Programming in the BETA Programming Language](https://beta.cs.au.dk/Books/) - Ole Lehrmann Madsen, Birger Møller-Pedersen, Kristen Nygaard


### C

* [256-Color VGA Programming in C](http://www.brackeen.com/vga/) - David Brackeen
* [A Tutorial on Pointers and Arrays in C](https://web.archive.org/web/20180827131006/http://home.earthlink.net/~momotuk/pointers.pdf) - Ted Jensen (PDF)
* [An Introduction to C & GUI Programming](https://www.raspberrypi.org/magpi-issues/C_GUI_Programming.pdf) - Simon Long (PDF)
* [Bare-metal programming for ARM](https://github.com/umanovskis/baremetal-arm) - Daniels Umanovskis [(PDF)](http://umanovskis.se/files/arm-baremetal-ebook.pdf)
* [Beej's Guide to C Programming](http://beej.us/guide/bgc/) - B. Hall
* [Beej's Guide to Network Programming - Using Internet Sockets](http://beej.us/guide/bgnet/) - B. Hall
* [Build Your Own Lisp](http://www.buildyourownlisp.com) - Daniel Holden
* [C Elements of Style](http://www.oualline.com/books.free/style/) - Steve Oualline
* [C for Python Programmers - Carl Burch](http://www.toves.org/books/cpy/)
* [C Notes](https://goalkicker.com/CBook) (PDF)
* [C Programming](https://en.wikibooks.org/wiki/Programming%3AC) - Wikibooks
* [C Programming Boot Camp - Paul Gribble](http://www.gribblelab.org/CBootCamp/)
* [Deep C](http://www.slideshare.net/olvemaudal/deep-c)
* [Essential C](http://cslibrary.stanford.edu/101/EssentialC.pdf) (PDF)
* [Everything you need to know about pointers in C - Peter Hosey](http://boredzo.org/pointers/)
* [Functional C (1997)](https://research.utwente.nl/files/5128727/book.pdf) - Pieter H. Hartel, Henk Muller (PDF)
* [Learn to Code With C - The MagPi Essentials](https://www.raspberrypi.org/magpi-issues/Essentials_C_v1.pdf) (PDF)
* [Modeling with Data](https://ben.klemens.org/pdfs/gsl_stats.pdf) - Ben Klemens (PDF)
* [Modern C](https://web.archive.org/web/20190818210107/http://icube-icps.unistra.fr/img_auth.php/d/db/ModernC.pdf) - Jens Gustedt (PDF)
* [Object-Oriented Programming With ANSI-C](http://www.planetpdf.com/codecuts/pdfs/ooc.pdf) (PDF)
* [Programming in C](http://ee.hawaii.edu/~tep/EE160/Book/PDF/) - Bharat Kinariwala & Tep Dobry
* [The C book](http://publications.gbdirect.co.uk/c_book/)
* [The Craft of Text Editing or A Cookbook for an Emacs](http://www.finseth.com/craft/) - Craig A. Finseth
* [The Current C Programming Language Standard – ISO/IEC 9899:202x (C2x)](http://www.open-std.org/jtc1/sc22/wg14/www/docs/n2310.pdf) - Open Standards Org - www.open-std.org (PDF)
* [The GNU C Programming Tutorial](http://www.crasseux.com/books/ctut.pdf) (PDF)
* [The little book about OS development](http://littleosbook.github.io) - Erik Helin, Adam Renberg
* [The New C Standard - An Economic and Cultural commentary (2009)](http://www.knosof.co.uk/cbook/cbook.html) - Derek M. Jones (PDF)
* [TONC GBA Programming - Game Boy Advance Development](http://www.coranac.com/tonc/text/toc.htm)


### C Sharp

* [C# Essentials](http://www.techotopia.com/index.php/C_Sharp_Essentials)
* [C# Notes](https://goalkicker.com/CSharpBook) (PDF)
* [C# Notes for Professionals](http://books.goalkicker.com/CSharpBook/) - Compiled from StackOverflow documentation (3.x)
* [C# Programming](https://en.wikibooks.org/wiki/C_Sharp_Programming) - Wikibooks
* [C# Tips](https://leanpub.com/cstips) - Jason Roberts *(Leanpub account or valid email requested)*
* [C# Yellow Book](http://www.csharpcourse.com) (intro to programming)
* [Creating Mobile Apps with Xamarin.Forms C#](https://developer.xamarin.com/guides/xamarin-forms/creating-mobile-apps-xamarin-forms/)
* [Daily Design Patterns](https://web.archive.org/web/20170930132000/https://www.exceptionnotfound.net/downloads/dailydesignpattern.pdf) - Matthew P Jones (PDF)
* [Data Structures and Algorithms with Object-Oriented Design Patterns in C#](https://web.archive.org/web/20161220072449/http://www.brpreiss.com/books/opus6/) - Bruno Preiss
* [Dissecting a C# Application](https://damieng.com/blog/2007/11/08/dissecting-a-c-application-inside-sharpdevelop) - Christian Holm, Bernhard Spuida, Mike Kruger
* [Fundamentals of Computer Programming with C#](http://www.introprogramming.info/english-intro-csharp-book/read-online/) - Svetlin Nakov
* [High level asynchronous programming with Reactive Extensions](https://github.com/petroemil/Rx.Book) - Emil Petro
* [Introduction to Rx](http://www.introtorx.com)
* [Mastering Xamarin UI Development, Second Edition](https://www.packtpub.com/free-ebooks/mastering-xamarin-ui-development-second-edition) - Steven F. Daniel (Packt account *required*)
* [Object Oriented Programming using C#](http://bookboon.com/en/object-oriented-programming-using-c-sharp-ebook) - Simon Kendal, Bookboon. (email address *requested*, not required)
* [Threading in C#](http://www.albahari.com/threading/)
* [Xamarin.Forms for macOS Succinctly](https://www.syncfusion.com/ebooks/xamarin_forms_for_mac_os_succinctly) - Alessandro Del Sole
* [Xamarin.Forms Succinctly](https://www.syncfusion.com/ebooks/xamarin-forms-succinctly) - Alessandro Del Sole


### C++

* [C++ Annotations](https://fbb-git.gitlab.io/cppannotations/)
* [C++ Core Guidelines](https://github.com/isocpp/CppCoreGuidelines/blob/master/CppCoreGuidelines.md) - Editors: Bjarne Stroustrup, Herb Sutter
* [C++ GUI Programming With Qt 3](http://www.computer-books.us/cpp_0010.php)
* [C++ Language](http://www.cplusplus.com/doc/tutorial/)
* [C++ Notes](https://goalkicker.com/CPlusPlusBook) (PDF)
* [C++ Succinctly, Syncfusion](https://www.syncfusion.com/resources/techportal/ebooks/cplusplus) (PDF, Kindle) (email address *requested*, not required)
* [C++ Tricks](http://www.bordoon.com/cplusplus/book_wrapper.html)
* [CS106X Programming Abstractions in C++](http://web.stanford.edu/class/cs106x/)
* [Elements of Programming](http://elementsofprogramming.com) - Alexander Stepanov and Paul McJones - (PDF)
* [Financial Numerical Recipes in C++](http://finance.bi.no/~bernt/gcc_prog/recipes/) - Bernt Arne Ødegaard
* [Game Programming Patterns](http://gameprogrammingpatterns.com)
* [Google's C++ Style Guide](https://google.github.io/styleguide/cppguide.html)
* [Hands-On System Programming with C++](https://www.packtpub.com/free-ebooks/hands-system-programming-c) - Dr. Rian Quinn (Packt account *required*)
* [How to make an Operating System](https://www.gitbook.com/book/samypesse/how-to-create-an-operating-system/details) - Samy Pesse
* [How To Think Like a Computer Scientist: C++ Version](http://greenteapress.com/thinkcpp/index.html) - Allen B. Downey
* [Introduction to Design Patterns in C++ with Qt](http://ptgmedia.pearsoncmg.com/images/9780131879058/downloads/0131879057_Ezust_book.pdf) (PDF)
* [Joint Strike Fighter, C++ Coding Standards, by Bjarne Stroustrup](http://www.stroustrup.com/JSF-AV-rules.pdf) (PDF)
* [Learn C++.](http://www.learncpp.com) (Online)
* [Matters Computational: Ideas, Algorithms, Source Code, by Jorg Arndt](http://www.jjj.de/fxt/fxtbook.pdf) (PDF)
* [Open Data Structures (In C++)](http://opendatastructures.org/ods-cpp.pdf) (PDF)
* [Software Design Using C++](http://cis.stvincent.edu/html/tutorials/swd/) - Br. David Carlson and Br. Isidore Minerd
* [Software optimization resources by Agner Fog](http://www.agner.org/optimize/)
* [The Boost C++ libraries](http://theboostcpplibraries.com)
* [The Rook's Guide to C++](http://rooksguide.org/2013/11/26/version-1-0-is-out/) (PDF)
* [The Ultimate Question of Programming, Refactoring, and Everything](https://www.gitbook.com/book/alexastva/the-ultimate-question-of-programming-refactoring-/details)
* [Thinking in C++, Second Edition, Vol. 1.](https://archive.org/details/TICPP2ndEdVolOne) - Bruce Eckel [(Vol. 2)](https://archive.org/details/TICPP2ndEdVolTwo)


### Chapel

* [Chapel Tutorial](http://faculty.knox.edu/dbunde/teaching/chapel/)
* [Chapel Tutorial for Programmers](http://web.archive.org/web/20150310075109/http://cs.colby.edu/kgburke/?resource=chapelTutorial)


### Cilk

* [Cilk 5.4.6 Reference Manual](http://supertech.csail.mit.edu/cilk/manual-5.4.6.pdf) (PDF)


### Clojure

* [A Brief Beginner’s Guide To Clojure](http://www.unexpected-vortices.com/clojure/brief-beginners-guide/)
* [Clojure - Functional Programming for the JVM](http://java.ociweb.com/mark/clojure/article.html) - R. Mark Volkmann
* [Clojure by Example](https://kimh.github.io/clojure-by-example/) - Hirokuni Kim
* [Clojure Cheat Sheet](http://clojure.org/cheatsheet)
* [Clojure community-driven documentation](http://clojure-doc.org)
* [Clojure Cookbook](https://github.com/clojure-cookbook/clojure-cookbook)
* [Clojure Distilled Beginner Guide](http://yogthos.github.io/ClojureDistilled.html)
* [Clojure for the Brave and True](http://www.braveclojure.com)
* [Clojure in Small Pieces](http://daly.axiom-developer.org/clojure.pdf) - Rich Hickey (PDF)
* [Clojure Koans](http://clojurekoans.com)
* [Clojure Programming](https://en.wikibooks.org/wiki/Clojure_Programming) - Wikibooks
* [ClojureScript Koans](http://clojurescriptkoans.com)
* [ClojureScript Unraveled](https://funcool.github.io/clojurescript-unraveled/) (HTML)
* [Data Sorcery with Clojure](http://data-sorcery.org/contents/)
* [Modern cljs](https://github.com/magomimmo/modern-cljs)
* [SICP Distilled - An idiosyncratic tour of SICP in Clojure](http://www.sicpdistilled.com)
* [The Clojure Style Guide](https://github.com/bbatsov/clojure-style-guide)


### COBOL

* [COBOL Programming Fundamental](http://yusman.staff.gunadarma.ac.id/Downloads/files/33460/COBOL_Programming_Fundamental.pdf) (PDF)
* [Enterprise COBOL for z/OS documentation library](http://www-01.ibm.com/support/docview.wss?uid=swg27036733)
* [Introduction to the COBOL Language](https://supportline.microfocus.com/documentation/books/oc41books/lrintr.htm)
* [OpenCOBOL 1.1 - Programmer's Guide](http://open-cobol.sourceforge.net/guides/OpenCOBOL%20Programmers%20Guide.pdf) (PDF)


### CoffeeScript

* [CoffeeScript Cookbook](https://coffeescript-cookbook.github.io)
* [CoffeeScript Ristretto](https://leanpub.com/coffeescript-ristretto/read) - Reginald Braithwaite  *(Leanpub account or valid email requested)*
* [Smooth CoffeeScript](http://autotelicum.github.io/Smooth-CoffeeScript/SmoothCoffeeScript.html)
* [The Little Book on CoffeeScript](http://arcturo.github.io/library/coffeescript/)


### ColdFusion

* [CFML In 100 Minutes](https://github.com/mhenke/CFML-in-100-minutes/blob/master/cfml100mins.markdown) - J. Casimir
* [Learn CF in a Week](http://learncfinaweek.com)


### Component Pascal

* [Computing Fundamentals](http://www.cslab.pepperdine.edu/warford/ComputingFundamentals/) - Stan Warford (PDF)


### Cool

* [CoolAid: The Cool 2013 Reference Manual](https://www.eecis.udel.edu/~cavazos/cisc672/docs/cool-manual.pdf) (PDF)


### Coq

* [Certified Programming with Dependent Types](http://adam.chlipala.net/cpdt/html/toc.html)
* [Software Foundations](http://www.cis.upenn.edu/~bcpierce/sf/)


### Crystal

* [Crystal for Rubyists](http://www.crystalforrubyists.com)


### CUDA

* [CUDA C Best Practices Guide](https://docs.nvidia.com/pdf/CUDA_C_Best_Practices_Guide.pdf) (PDF)
* [CUDA C Programming Guide](https://docs.nvidia.com/pdf/CUDA_C_Programming_Guide.pdf) (PDF)
* [OpenCL Programming Guide for CUDA Architecture](http://www.nvidia.com/content/cudazone/download/OpenCL/NVIDIA_OpenCL_ProgrammingGuide.pdf) (PDF)


### D

* [D Templates Tutorial](https://github.com/PhilippeSigaud/D-templates-tutorial)
* [Programming in D](http://ddili.org/ders/d.en/)


### Dart

* [Learning Dart](https://riptutorial.com/Download/dart.pdf) (PDF)


### DB2

* [Getting started with DB2 Express-C](http://public.dhe.ibm.com/software/dw/db2/express-c/wiki/Getting_Started_with_DB2_Express_v9.7_p4.pdf) (PDF)
* [Getting started with IBM Data Studio for DB2](http://public.dhe.ibm.com/software/dw/db2/express-c/wiki/Getting_Started_with_IBM_Data_Studio_for_DB2_p3.pdf) (PDF)
* [Getting started with IBM DB2 development](http://public.dhe.ibm.com/software/dw/db2/express-c/wiki/Getting_Started_with_DB2_App_Dev_p2.pdf) (PDF)


### Delphi / Pascal

* [Essential Pascal Version 1 and 2](http://www.marcocantu.com/epascal/) - M. Cantù
* [Expert Delphi](https://www.packtpub.com/free-ebooks/expert-delphi) - Paweł Głowacki (Packt account *required*)


### DTrace

* [IllumOS Dynamic Tracing Guide](http://dtrace.org/guide/preface.html)


### Elasticsearch

* [Elasticsearch: The Definitive Guide](https://www.elastic.co/guide/en/elasticsearch/guide/current/index.html) ([fork it on GH](https://github.com/elastic/elasticsearch-definitive-guide))
* [Exploring Elasticsearch](http://exploringelasticsearch.com)


### Eiffel

* [A Functional Pattern System for Object-Oriented Design](http://homepages.mcs.vuw.ac.nz/~tk/fps/fps-sans-escher.pdf) - Thomas Kuhne (PDF)


### Elixir

* [30 Days of Elixir](https://github.com/seven1m/30-days-of-elixir) - Tim Morgan (HTML)
* [Elixir School](https://elixirschool.com) (HTML)
* [Elixir Succinctly, Syncfusion](https://www.syncfusion.com/ebooks/elixir-succinctly) (PDF, Kindle) (email address requested, not required)
* [Getting Started Guide](http://elixir-lang.org/getting-started/introduction.html) (HTML) [(PDF, MOBI, EPUB)](https://github.com/potatogopher/elixir-getting-started)
* [Joy of Elixir](https://joyofelixir.com) - Ryan Bigg (HTML) - [Source](https://github.com/radar/joyofelixir) (:construction: *in process*)
* [Learning Elixir](http://learningelixir.joekain.com) - Joseph Kain Blog (HTML)
* [The Ultimate Guide To Elixir For Object-Oriented Programmers](http://www.binarywebpark.com/ultimate-guide-elixir-object-oriented-programmers) - Bruce Park (HTML)


#### Ecto

* [Ecto Getting Started Guide](https://hexdocs.pm/ecto/getting-started.html#content) (HTML)


#### Phoenix

* [Phoenix v1.3.0 Guide](https://hexdocs.pm/phoenix/overview.html) (HTML)
* [Versioned APIs with Phoenix](https://elviovicosa.com/freebies/versioned-apis-with-phoenix-by-elvio-vicosa.pdf) - Elvio Vicosa (PDF)


### Emacs

* [An Introduction to Programming in Emacs Lisp, 3rd Edition](https://www.gnu.org/software/emacs/manual/html_node/eintr/index.html)
* [GNU Emacs Lisp Reference Manual](http://www.gnu.org/software/emacs/manual/elisp.html)
* [GNU Emacs Manual](https://www.gnu.org/software/emacs/manual/pdf/emacs.pdf) (PDF)


### Embedded Systems

* [Control and Embedded Systems](http://www.learn-c.com) (HTML)
* [Discovering the STM32 Microcontroller](http://www.cs.indiana.edu/~geobrown/book.pdf) (PDF)
* [Introduction to Embedded Systems, Second Edition](https://ptolemy.berkeley.edu/books/leeseshia/releases/LeeSeshia_DigitalV2_2.pdf) - Edward Ashford Lee, Sanjit Arunkumar Seshia (PDF)
* [Introduction to Microcontrollers](http://www.embeddedrelated.com/showarticle/453.php) (HTML)


### Erlang

* [Concurrent Programming in ERLANG](http://www.erlang.org/download/erlang-book-part1.pdf) (PDF)
* [Erlang Handbook](https://github.com/esl/erlang-handbook/raw/master/output/ErlangHandbook.pdf) (PDF)
* [Erlang Programming](https://en.wikibooks.org/wiki/Erlang_Programming) - Wikibooks (HTML)
* [Getting Started with Erlang User's Guide](http://www.erlang.org/doc/getting_started/users_guide.html) (HTML)
* [Learn You Some Erlang For Great Good](http://learnyousomeerlang.com) - Frederic Trottier-Hebert
* [Making reliable distributed systems in the presence of software errors](http://www.erlang.org/download/armstrong_thesis_2003.pdf) - Joe Armstrong (PDF)
* [Stuff Goes Bad: Erlang in Anger](https://www.erlang-in-anger.com) - Fred Herbert (PDF)


### ESP8266

* [Kolban's book on the ESP32 & ESP8266](https://leanpub.com/ESP8266_ESP32)  *(Leanpub account or valid email requested)*


### F Sharp

* [Analyzing and Visualizing Data with F#](https://www.oreilly.com/programming/free/files/analyzing-visualizing-data-f-sharp.pdf) (PDF)
* [F# for fun and profit](https://www.gitbook.com/book/swlaschin/fsharpforfunandprofit/details) (ePub)
* [F# Programming](https://en.wikibooks.org/wiki/F_Sharp_Programming) - Wikibooks
* [F# Succinctly, SyncFusion](https://www.syncfusion.com/resources/techportal/ebooks/fsharp) (PDF, Kindle) (email address *requested*, not required)
* [Functional Programming Textbook](https://www.overleaf.com/read/hcwwdfxvftfp) - Yusuf M Motara (PDF)
* [Programming Language Concepts for Software Developers](https://archive.org/details/B-001-003-622)


### Firefox OS

* [Quick Guide For Firefox OS App Development: Creating HTML5 based apps for Firefox OS](https://leanpub.com/quickguidefirefoxosdevelopment/read) - Andre Garzia


### Flutter

* [Cookbook](https://flutter.dev/docs/cookbook)
* [Flutter Succinctly, Syncfusion](https://www.syncfusion.com/ebooks/flutter-succinctly) (PDF, Kindle) (email address *requested*, not required)
* [Flutter Tutorials Handbook](https://kodestat.gitbook.io/flutter/)


### Force.com

* [Apex Workbook](https://web.archive.org/web/20170102233924/https://resources.docs.salesforce.com/sfdc/pdf/apex_workbook.pdf) (PDF)
* [Developer Workbooks](http://developer.force.com/workbook)
* [Force.com Fundamentals](http://developerforce.s3.amazonaws.com/books/Force.com_Fundamentals.pdf) (PDF)
* [Force.com Platform Fundamentals: An Introduction to Custom Application Development in the Cloud](http://www.lulu.com/shop/salesforcecom/forcecom-platform-fundamentals/ebook/product-17381451.html)
* [Force.com Workbook](https://web.archive.org/web/20160804055738/http://resources.docs.salesforce.com:80/sfdc/pdf/forcecom_workbook.pdf) (PDF)
* [Heroku Postgres](https://web.archive.org/web/20131209081736/http://media.developerforce.com/workbooks/HerokuPostgres_Workbooks_Web_Final.pdf) (PDF)
* [Heroku Workbook](https://res.cloudinary.com/hy4kyit2a/image/upload/workbook_text_Heroku.pdf) (PDF)
* [Integration Workbook](https://web.archive.org/web/20150919023850/https://resources.docs.salesforce.com/sfdc/pdf/integration_workbook.pdf) (PDF)
* [Salesforce1 Mobile App Workbook](https://res.cloudinary.com/hy4kyit2a/image/upload/s1_mobile_woorkbook_v3-21.pdf) (PDF)
* [Visualforce Workbook](https://web.archive.org/web/20150921195528/https://resources.docs.salesforce.com/sfdc/pdf/workbook_vf.pdf) (PDF)


### Forth

* [A Beginner's Guide to Forth](https://web.archive.org/web/20180919061255/http://galileo.phys.virginia.edu/classes/551.jvn.fall01/primer.htm) - J.V. Noble
* [And so Forth...](http://ficl.sourceforge.net/pdf/Forth_Primer.pdf) (PDF)
* [Programming Forth](http://www.mpeforth.com/arena/ProgramForth.pdf) (PDF)
* [Starting Forth](http://home.iae.nl/users/mhx/sf.html)
* [Thinking Forth](http://thinking-forth.sourceforge.net)
* [Thoughtful Programming and Forth](http://www.ultratechnology.com/forth.htm)


### Fortran

* [Introduction to fortran 95 and numerical computing: a jump-start for scientists and engineers](http://people.cs.vt.edu/~asandu/Deposit/Fortran95_notes.pdf) (PDF)
* [Self Study Guide: Programming in Fortran 95](http://www.mrao.cam.ac.uk/~rachael/compphys/SelfStudyF95.pdf) (PDF)


### FreeBSD

* [Books and Articles from FreeBSD Site](http://www.freebsd.org/docs/books.html)
* [The Complete FreeBSD](http://www.lemis.com/grog/Documentation/CFBSD/)
* [Using C on the UNIX System](http://www.bitsinthewind.com/about-dac/publications/using-c-on-the-unix-system) - David A. Curry


### Git

* [A Visual Git Reference](http://marklodato.github.io/visual-git-guide/index-en.html) - Mark Lodato
* [Conversational Git](http://blog.anvard.org/conversational-git/)
* [git - the simple guide](http://rogerdudler.github.io/git-guide/)
* [Git for Computer Scientists](http://eagain.net/articles/git-for-computer-scientists/)
* [Git From The Bottom Up](https://jwiegley.github.io/git-from-the-bottom-up/) - J. Wiegley
* [Git Immersion](http://gitimmersion.com)
* [Git In The Trenches](http://cbx33.github.io/gitt/index.html)
* [Git internals](https://github.com/pluralsight/git-internals-pdf/raw/master/drafts/peepcode-git.pdf) - Scott Chacon (PDF)
* [Git Magic](http://www-cs-students.stanford.edu/~blynn/gitmagic/)
* [Git Pocket Guide](https://www.oreilly.com/library/view/git-pocket-guide/9781449327507) - Richard E. Silverman
* [Git Reference](https://web.archive.org/web/20170602211147/http://gitref.org/)
* [Git Succinctly, Syncfusion](https://www.syncfusion.com/resources/techportal/ebooks/git) (PDF, Kindle) (email address *requested*, not required)
* [Git Workflows](http://documentup.com/skwp/git-workflows-book)
* [GitHub Cheat Sheet](https://github.com/tiimgreen/github-cheat-sheet) - Tim Green (Markdown)
* [How to Collaborate on Github](https://github.com/eonist/How-to-collaborate-on-github) - André J
* [Intoduction to Git and Github](https://launchschool.com/books/git) - Launch School
* [Intoduction to Git and Github - Tutorial](http://cse.unl.edu/~cbourke/gitTutorial.pdf) - Dr. Chris Bourke (PDF)
* [Learn Git - Learn Version Control with Git](http://www.git-tower.com/learn/git/ebook/command-line/introduction) - Tobias Günther
* [Pro Git](http://git-scm.com/book/en/v2) - Scott Chacon
* [Pro Git Reedited](https://leanpub.com/progitreedited/read) - Jon Forrest
* [Ry's Git Tutorial](https://web.archive.org/web/20161121145226/http://rypress.com:80/tutorials/git/index) - Ryan Hodson
* [Think Like (a) Git: A Guide for the Perplexed](http://think-like-a-git.net)


### Go

* [An Introduction to Programming in Go](http://www.golang-book.com)
* [Build Web Application with Golang](https://astaxie.gitbooks.io/build-web-application-with-golang/content/en/)
* [Building Web Apps with Go](https://codegangsta.gitbooks.io/building-web-apps-with-go/content/)
* [Effective Go](https://golang.org/doc/effective_go.html)
* [Go 101](https://go101.org/article/101.html) - [@TapirLiu](https://twitter.com/TapirLiu)
* [Go Bootcamp](http://www.golangbootcamp.com/book) - Matt Aimonetti
* [Go by Example](https://gobyexample.com)
* [Go for Javascript Developers](https://github.com/bulim/go-for-javascript-developers)
* [Learn Go with Tests](https://quii.gitbook.io/learn-go-with-tests/)
* [Learning Go](https://miek.nl/go/)
* [Let's learn Go!](http://go-book.readthedocs.io/en/latest/)
* [Practical Cryptography With Go](https://leanpub.com/gocrypto/read) - Kyle Isom
* [The Go Tutorial](http://tour.golang.org)
* [The Little Go Book](https://github.com/karlseguin/the-little-go-book)
* [Web apps in Go, the anti textbook](https://github.com/thewhitetulip/web-dev-golang-anti-textbook/)


### Groovy

#### Gradle

* [Building Java Projects with Gradle](http://spring.io/guides/gs/gradle/)
* [Gradle Succinctly](https://www.syncfusion.com/ebooks/gradle_succinctly) - José Roberto Olivas Mendoza
* [Gradle User Guide](https://docs.gradle.org/current/userguide/userguide.html) - Hans Dockter, Adam Murdoch ([PDF](https://docs.gradle.org/current/userguide/userguide.pdf))


#### Grails

* [Getting Started with Grails](http://www.infoq.com/minibooks/grails-getting-started)
* [Grails Tutorial for Beginners](http://grails.asia/grails-tutorial-for-beginners/)
* [The Grails Framework - Reference Documentation](http://grails.github.io/grails-doc/latest/) - Graeme Rocher, Peter Ledbrook, Marc Palmer, Jeff Brown, Luke Daley, Burt Beckwith, Lari Hotari ([PDF](http://grails.github.io/grails-doc/latest/guide/single.pdf))


#### Spock Framework

* [Spock Framework Reference Documentation](https://spockframework.github.io/spock/docs/current/index.html) - Peter Niederwieser


### Hack

* [Hack Documentation](https://docs.hhvm.com/hack/)


### Hadoop

* [Big Data Analytics with Hadoop 3](https://www.packtpub.com/free-ebooks/big-data-analytics-hadoop-3) - Sridhar Alla (Packt account *required*)
* [Cloudera Impala](https://docs.cloudera.com/documentation/enterprise/latest/PDF/cloudera-impala.pdf) - John Russel (PDF)
* [Data-Intensive Text Processing with MapReduce](http://lintool.github.io/MapReduceAlgorithms/MapReduce-book-final.pdf) (Jimmy Lin and Chris Dyer) (PDF)
* [Hadoop for Windows Succinctly](https://www.syncfusion.com/ebooks/hadoop-for-windows-succinctly) - Dave Vickers
* [Hadoop Illuminated](http://hadoopilluminated.com/index.html) - Mark Kerzner & Sujee Maniyam


### Haskell

* [A Gentle Introduction to Haskell](https://www.haskell.org/tutorial/)
* [Anatomy of Programming Languages](http://www.cs.utexas.edu/~wcook/anatomy/) - William R. Cook
* [Beautiful Code, Compelling Evidence](https://web.archive.org/web/20160411023943/http://www.renci.org/wp-content/pub/tutorials/BeautifulCode.pdf) - J.R. Heard (PDF)
* [Exploring Generic Haskell](http://www.andres-loeh.de/ExploringGH.pdf) - Andres Löh (PDF)
* [Happy Learn Haskell Tutorial](http://www.happylearnhaskelltutorial.com)
* [Haskell](https://en.wikibooks.org/wiki/Haskell) - Wikibooks
* [Haskell and Yesod](http://www.yesodweb.com/book-1.4)
* [Haskell no panic](http://lisperati.com/haskell/)
* [Haskell web Programming](http://yannesposito.com/Scratch/fr/blog/Yesod-tutorial-for-newbies/) (Yesod tutorial)
* [Learn Haskell Fast and Hard](http://yannesposito.com/Scratch/en/blog/Haskell-the-Hard-Way/)
* [Learn You a Haskell for Great Good](http://learnyouahaskell.com) - Miran Lipovaca
* [Parallel and Concurrent Programming in Haskell](https://www.oreilly.com/library/view/parallel-and-concurrent/9781449335939/) -  Simon Marlow
* [Real World Haskell](http://book.realworldhaskell.org)
* [Speeding Through Haskell](http://www.sthaskell.com)
* [Wise Man's Haskell](https://anchpop.github.io/wise_mans_haskell/) - Andre Popovitch
* [Yet Another Haskell Tutorial](http://hal3.name/docs/daume02yaht.pdf) (PDF)


### Haxe

* [Flambe Handbook](https://github.com/markknol/flambe-guide/wiki)
* [Haxe and JavaScript](https://matthijskamstra.github.io/haxejs/) - Matthijs Kamstra (wikibook)
* [Haxe Manual](http://haxe.org/documentation/introduction/) - Haxe Foundation (PDF, HTML)
* [HaxeFlixel Handbook](http://haxeflixel.com/documentation/haxeflixel-handbook/) (HTML)
* [Kha Handbook](https://github.com/KTXSoftware/Kha/wiki/Tutorials)


### HTML / CSS

* [A beginner's guide to HTML&CSS](http://learn.shayhowe.com/html-css/)
* [A free guide to learn HTML and CSS](http://marksheet.io)
* [Adaptive Web Design](http://adaptivewebdesign.info/1st-edition/) - Aaron Gustafson
* [An advanced guide to HTML&CSS](http://learn.shayhowe.com/advanced-html-css/)
* [Canvassing](https://web.archive.org/web/20160505010319/http://learnjs.io/canvassing/read/)
* [Code Guide: Standards for developing flexible, durable, and sustainable HTML and CSS](http://mdo.github.io/code-guide/) - Mark Otto
* [CSS Animation 101](https://github.com/cssanimation/css-animation-101)
* [Dive Into HTML5](http://diveinto.html5doctor.com) - Mark Pilgrim ([PDF](http://mislav.net/2011/10/dive-into-html5/))
* [GA Dash](https://dash.generalassemb.ly)
* [Google's HTML/CSS Style Guide](https://google.github.io/styleguide/htmlcssguide.html)
* [How to Code in HTML5 and CSS3](https://web.archive.org/web/20180816174417/http://howtocodeinhtml.com/HowToCodeInHTML5AndCSS3.pdf) - Damian Wielgosik (PDF)
* [HTML Canvas Deep Dive](http://joshondesign.com/p/books/canvasdeepdive/toc.html) - Josh Marinacci
* [HTML Dog Tutorials](http://www.htmldog.com)
* [HTML5 Canvas](https://www.oreilly.com/library/view/html5-canvas/9781449308032/ch01.html) - Steve Fulton & Jeff Fulton
* [HTML5 for Publishers](https://www.oreilly.com/library/view/html5-for-publishers/9781449320065/pr02.html) - Sanders Kleinfeld
* [HTML5 For Web Designers](http://html5forwebdesigners.com) - Jeremy Keith
* [HTML5 Notes for Professionals](http://books.goalkicker.com/HTML5Book/) - Compiled from StackOverflow documentation (3.x)
* [HTML5 Shoot 'em Up in an Afternoon](https://leanpub.com/html5shootemupinanafternoon/read) - Bryan Bibat
* [Learn CSS Layout](http://learnlayout.com)
* [Learn CSS Layout the pedantic way](http://book.mixu.net/css/)
* [Learn to Code HTML & CSS](https://learn.shayhowe.com) - Shay Howe
* [MaintainableCSS](http://maintainablecss.com)
* [Pro HTML5 Programming](https://web.archive.org/web/20181215200026/http://apress.jensimmons.com/v5/pro-html5-programming/ch0.html) - Jen Simmons, Chris O'Connor, Dylan Wooters, Peter Lubbers
* [Scalable and Modular Architecture for CSS](https://web.archive.org/web/20191116073929/http://smacss.com/) - Jonathan Snook
* [Understanding Flexbox: Everything you need to know](https://ohansemmanuel.github.io/uf_download.html) - Ohans Emmanuel
* [W3.CSS Succinctly](https://www.syncfusion.com/ebooks/w3_css_succinctly) - Joseph D. Booth
* [Web Audio API](http://chimera.labs.oreilly.com/books/1234000001552) - Boris Smus


#### Bootstrap

* [Twitter Bootstrap 3 Succinctly](https://www.syncfusion.com/resources/techportal/details/ebooks/twitterbootstrap3) - Peter Shaw
* [Twitter Bootstrap 4 Succinctly](https://www.syncfusion.com/ebooks/twitterbootstrap4-succinctly) - Peter Shaw
* [Twitter Bootstrap Succinctly](https://www.syncfusion.com/resources/techportal/details/ebooks/twitterbootstrap) - Peter Shaw


#### HTTP

* [Introduction to HTTP](https://launchschool.com/books/http) - Launch School


### Idris

* [Gentle Introduction to Dependent Types with Idris](https://leanpub.com/gidti) - Boro Sitnikovski  *(Leanpub account or valid email requested)*


### Icon

* [The Implementation of the Icon Programming Language](http://www.cs.arizona.edu/icon/ibsale.htm)


### iOS

* [Cocoa Dev Central](http://cocoadevcentral.com)
* [iOS 8 App Development Essentials](http://www.techotopia.com/index.php/IOS_8_App_Development_Essentials)
* [iOS Succinctly, Syncfusion](https://www.syncfusion.com/resources/techportal/ebooks/ios) (PDF, Kindle) (email address *requested*, not required)
* [NSHipster](http://nshipster.com/#archive) (Resource)
* [Start Developing iOS Apps (Swift)](https://developer.apple.com/library/prerelease/ios/referencelibrary/GettingStarted/DevelopiOSAppsSwift/index.html) (HTML)
* [Start Developing iOS Apps Today (Objective-C) - Last updated 22.10.2013](http://everythingcomputerscience.com/books/RoadMapiOS.pdf) (PDF)


### IoT

* [IoT in five days- V1.1](https://github.com/marcozennaro/IPv6-WSN-book/tree/master/Releases) (PDF, EPUB)
* [Mastering Internet of Things](https://www.packtpub.com/free-ebooks/mastering-internet-things) - Peter Waher (Packt account *required*)


### Isabelle/HOL

* [Concrete Semantics - A Proof Assistant Approach by Tobias Nipkow and Gerwin Klein](http://www21.in.tum.de/~nipkow/Concrete-Semantics/) (PDF)
* [Isabelle/HOL - A Proof Assistant for Higher-Order Logic by Tobias Nipkow and Lawrence C. Paulson and Markus Wenzel](http://isabelle.in.tum.de/doc/tutorial.pdf) (PDF)


### J

* [Arithmetic by Kenneth E Iverson](http://www.jsoftware.com/books/pdf/arithmetic.pdf) (PDF)
* [Brief Reference by Chris Burke and Clifford Reiter](http://www.jsoftware.com/books/pdf/brief.pdf) (PDF)
* [Calculus by Kenneth E Iverson](http://www.jsoftware.com/books/pdf/calculus.pdf) (PDF)
* [Computers and Mathematical Notation by Kenneth E Iverson](http://www.jsoftware.com/papers/camn.htm)
* [Concrete Math Companion by Kenneth E Iverson](http://www.jsoftware.com/books/pdf/cmc.pdf) (PDF)
* [Easy J by Linda Alvord, Norman Thomson](http://www.jsoftware.com/books/pdf/easyj.pdf) (PDF) ([Word DOC](http://www.jsoftware.com/books/doc/easyj_doc.zip))
* [Exploring Math by Kenneth E Iverson](http://www.jsoftware.com/books/pdf/expmath.pdf) (PDF)
* [J for C Programmers by Henry Rich](http://www.jsoftware.com/help/jforc/contents.htm)
* [J Primer](http://www.jsoftware.com/help/primer/contents.htm)
* [Learning J by Roger Stokes- online](http://www.jsoftware.com/help/learning/contents.htm)
* [Math for the Layman by Kenneth E Iverson](http://www.jsoftware.com/books/pdf/mftl.zip) (zipped html+images)


### Java

* [3D Programming in Java](http://www.mat.uniroma2.it/~picard/SMC/didattica/materiali_did/Java/Java_3D/Java_3D_Programming.pdf) - Daniel Selman (PDF)
* [Apache Jakarta Commons: Reusable Java Components](http://ptgmedia.pearsoncmg.com/images/0131478303/downloads/Iverson_book.pdf) - Will Iverson (PDF)
* [Artificial Intelligence - Foundations of Computational Agents, Second Edition](https://artint.info/2e/html/ArtInt2e.html) - David L. Poole and Alan K. Mackworth
* [Category wise tutorials - J2EE](https://www.mkyong.com/all-tutorials-on-mkyong-com/) - Yong Mook Kim
* [Core Servlets and JavaServer Pages, 2nd Ed. (2003)](http://pdf.coreservlets.com) - Marty Hall and Larry Brown
* [Data Structures in Java for the Principled Programmer (2007)](https://web.archive.org/web/20190302130416/http://dept.cs.williams.edu/~bailey/JavaStructures/Book_files/JavaStructures.pdf) - Duane A. Bailey (PDF)
* [Google's Java Style Guide](https://google.github.io/styleguide/javaguide.html)
* [Introduction to Computer Science "booksite"](https://introcs.cs.princeton.edu/java/cs/) - by Robert Sedgewick and Kevin Wayne (HTML)
* [Introduction to Computer science using Java](http://www.programmedlessons.org/Java9/index.html) - Bradley Kjell
* [Introduction to Programming in Java](http://introcs.cs.princeton.edu/java/home/) - Robert Sedgewick and Kevin Wayne
* [Introduction to Programming Using Java](http://math.hws.edu/javanotes/) - David J. Eck
* [Java Application Development on Linux (2005)](https://ptgmedia.pearsoncmg.com/images/013143697X/downloads/013143697X_book.pdf) - Carl Albing and Michael Schwarz (PDF)
* [Java, Java, Java Object-Oriented Problem Solving](https://archive.org/details/JavaJavaJavaObject-orientedProblemSolving/page/n0) - R. Morelli and R.Walde
* [Java Language and Virtual Machine Specifications](https://docs.oracle.com/javase/specs/) - James Gosling, et al
* [Java Notes for Professionals](http://books.goalkicker.com/JavaBook/) - Compiled from StackOverflow documentation (3.x)
* [Java Programming for Kids](https://yfain.github.io/Java4Kids/) - Yakov Fain
* [Java Projects, Second Edition](https://www.packtpub.com/free-ebooks/java-projects-second-edition) - Peter Verhas (Packt account *required*)
* [Microservices Best Practices for Java](https://www.redbooks.ibm.com/redbooks/pdfs/sg248357.pdf) (PDF)
* [Object-Oriented Programming in JavaTM Textbook](http://computing.southern.edu/halterman/OOPJ/) - Rick Halterman (PDF per Chapter)
* [Object Oriented Programming using Java](https://bookboon.com/en/object-oriented-programming-using-java-ebook) - Simon Kendal (PDF) , Bookboon. (email address *requested*, not required)
* [OOP - Learn Object Oriented Thinking & Programming](http://pub.bruckner.cz/titles/oop) - Rudolf Pecinovsky (PDF)
* [Open Data Structures (in Java)](http://opendatastructures.org/ods-java.pdf) - Pat Morin (PDF)
* [Playing with Java Microservices on Kubernetes and OpenShift](https://leanpub.com/playing-with-java-microservices-on-k8s-and-ocp) - Nebrass Lamouchi *(Leanpub account or valid email requested)*
* [Processing XML with Java (A Guide to SAX, DOM, JDOM, JAXP, and TrAX) (2002)](http://www.cafeconleche.org/books/xmljava/) - Elliotte Rusty Harold
* [The ABC of PDF with iText: PDF Syntax essentials](https://leanpub.com/itext_pdfabc) - Bruno Lowagie  *(Leanpub account or valid email requested)*
* [The Java EE6 Tutorial](https://docs.oracle.com/javaee/6/tutorial/doc/javaeetutorial6.pdf) (PDF)
* [The Java EE7 Tutorial](https://docs.oracle.com/javaee/7/JEETT.pdf) - Eric Jendrock, et al (PDF)
* [The Java Tutorials](https://docs.oracle.com/javase/tutorial/index.html)
* [The Java Web Scraping Handbook](https://www.scrapingbee.com/java-webscraping-book) - Kevin Sahin (PDF, HTML)
* [Think Java: How to Think Like a Computer Scientist](http://greenteapress.com/thinkapjava/) - Allen B. Downey and Chris Mayfield
* [Welcome to Java for Python Programmers](https://runestone.academy/runestone/books/published/java4python/index.html) - Brad Miller
* [Welcome to the Java Workshop (2006)](http://javaworkshop.sourceforge.net) - Trevor Miller


#### Codename One

* [Codename One Developer Guide](https://www.codenameone.com/files/developer-guide.pdf) (PDF)
* [Create an Uber Clone in 7 Days (first 2 chapters)](http://uber.cn1.co) - Shai Almog (PDF)


#### JasperReports

* [The JasperReports Ultimate Guide, Third Edition](http://jasperreports.sourceforge.net/JasperReports-Ultimate-Guide-3.pdf) (PDF)


#### Spring

* [Building Applications with Spring 5 and Vue.js 2](https://www.packtpub.com/free-ebooks/building-applications-spring-5-and-vuejs-2) - James J. Ye (Packt account *required*)
* [Software Architecture with Spring 5.0](https://www.packtpub.com/free-ebooks/software-architecture-spring-50) - René Enríquez, Alberto Salazar (Packt account *required*)
* [Spring Framework Reference Documentation](https://docs.spring.io/spring/docs/current/spring-framework-reference/) - Rod Johnson et al.


#### Spring Boot

* [Spring Boot Reference Guide](https://docs.spring.io/spring-boot/docs/current/reference/html/) - Phillip Webb et al. ([PDF](https://docs.spring.io/spring-boot/docs/current/reference/pdf/spring-boot-reference.pdf))


#### Spring Data

* [Spring Data Reference](https://docs.spring.io/spring-data/jpa/docs/current/reference/html) - Oliver Gierke, Thomas Darimont, Christoph Strobl, Mark Paluch, Jay Bryant


#### Spring Security

* [Spring Security Reference](http://docs.spring.io/spring-security/site/docs/current/reference/htmlsingle/) - Ben Alex, Luke Taylor, Rob Winch


#### Wicket

* [Official Free Online Guide for Apache Wicket framework](http://wicket.apache.org/learn/#guide)


### JavaScript

* [Basic JavaScript for the impatient programmer](http://www.2ality.com/2013/06/basic-javascript.html) - Dr. Axel Rauschmayer
* [Book of Modern Frontend Tooling](https://github.com/tooling/book-of-modern-frontend-tooling)
* [Crockford's JavaScript](http://www.crockford.com/javascript/) - Douglas Crockford
* [Dev Docs](http://devdocs.io)
* [Directory of free Javascript ebooks](http://jsbooks.revolunet.com)
* [Eloquent JavaScript 2nd edition](http://eloquentjavascript.net) - Marijn Haverbeke
* [Exploring ES6](http://exploringjs.com/es6/) - Dr. Axel Rauschmayer
* [Google JavaScript Style Guide](https://google.github.io/styleguide/javascriptguide.xml)
* [Human JavaScript](http://read.humanjavascript.com/ch01-introduction.html)
* [JavaScript Allongé](https://leanpub.com/javascript-allonge/read) - Reginald Braithwaite
* [JavaScript Bible](http://media.wiley.com/product_ancillary/28/07645334/DOWNLOAD/all.pdf) (PDF)
* [JavaScript Challenges Book](https://tcorral.github.io/javascript-challenges-book/)
* [JavaScript Enlightenment](http://www.javascriptenlightenment.com) - Cody Lindley
* [JavaScript ES6 and beyond](https://github.com/AlbertoMontalesi/JavaScript-es6-and-beyond-ebook) - Alberto Montalesi (PDF, epub)
* [JavaScript For Cats](http://jsforcats.com)
* [JavaScript Fundamentals, Plus a Dash Of JQuery - for dinner ladies](http://nicholasjohnson.com/javascript-book/)
* [JavaScript Garden](http://bonsaiden.github.io/JavaScript-Garden/) (Maintained by Tim Ruffles)
* [JavaScript Patterns Collection](http://shichuan.github.io/javascript-patterns/) - Shi Chuan
* [JavaScript Spessore](https://web.archive.org/web/20160325064800/https://leanpub.com/javascript-spessore/read) - Reginald Braithwaite
* [Javascript Succinctly, Syncfusion](https://www.syncfusion.com/resources/techportal/ebooks/javascript) (PDF, Kindle) (email address *requested*, not required)
* [JavaScript the Right Way](https://github.com/braziljs/js-the-right-way)
* [jQuery Fundamentals](http://jqfundamentals.com) (starts with JavaScript basics)
* [JS Robots](http://markdaggett.com/images/ExpertJavaScript-ch6.pdf) (PDF)
* [Leaflet Tips and Tricks: Interactive Maps Made Easy](https://leanpub.com/leaflet-tips-and-tricks/read) - Malcolm Maclean
* [Learn to Code JavaScript by Playing a Game](http://codecombat.com)
* [Learning JavaScript Design Patterns](http://addyosmani.com/resources/essentialjsdesignpatterns/book/) - Addy Osmani
* [Let's Learn ES6](https://bubblin.io/cover/let-s-learn-es6-by-ryan-christiani#frontmatter) - Ryan Christiani (Superbook format)
* [Managing Space and Time with JavaScript - Book 1: The Basics](http://www.noelrappin.com) - Noel Rappin
* [Marionette Exposé: Learn to write modular Javascript applications using Backbone Marionette and RequireJS/AMD](https://leanpub.com/marionetteexpose) - Jack Killilea  *(Leanpub account or valid email requested)*
* [Mozilla Developer Network's JavaScript Guide](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide)
* [Neural Networks with JavaScript Succinctly](https://www.syncfusion.com/ebooks/neural-networks-with-javascript-succinctly) - James McCaffrey
* [Oh My JS](https://web.archive.org/web/20150317231950/https://leanpub.com/ohmyjs/read) - Azat Mardanov
* [Patterns For Large-Scale JavaScript Application Architecture](http://addyosmani.com/largescalejavascript/) - Addy Osmani
* [Programming JavaScript Applications](https://www.oreilly.com/library/view/programming-javascript-applications/9781491950289/)
* [Speaking JavaScript](http://speakingjs.com/es5/) - Dr. Axel Rauschmayer
* [The JavaScript Tutorial](http://javascript.info)
* [The JavaScript Way](https://github.com/bpesquet/thejsway) - Baptiste Pesquet
* [The Problem with Native JavaScript APIs](https://www.oreilly.com/programming/free/native-javascript-apis.csp) (email address *requested*)
* [Understanding ECMAScript 6](https://leanpub.com/understandinges6/read) - Nicholas C. Zakas
* [Understanding JavaScript OOP](http://robotlolita.me/2011/10/09/understanding-javascript-oop.html) *(Sorella)*
* [You Don't Know JS](https://github.com/getify/You-Dont-Know-JS)


#### Angular.js

* [Angular for the jQuery developer](http://www.ng-newsletter.com.s3-website-us-east-1.amazonaws.com/posts/angular-for-the-jquery-developer.html)
* [Angular.js Guide](https://docs.angularjs.org/guide/)
* [Angular.js Material Designing](https://material.angularjs.org/latest/)
* [Angular.js Tutorial](https://docs.angularjs.org/tutorial)
* [AngularJS - Step by Logical Step](http://nicholasjohnson.com/angular-book/)
* [AngularJS Succinctly](https://www.syncfusion.com/resources/techportal/ebooks/angularjs) (PDF, Kindle) (email address *requested*, not required)
* [AngularJs vs EmberJs](http://angularjs-emberjs-compare.bguiz.com)
* [Practical Angular: Build your first web apps with Angular 8](https://leanpub.com/practical-angular) - Ahmed Bouchefra *(Leanpub account or valid email requested)*
* [Seven-Part Introduction to Angular](http://ngokevin.com/blog/angular-1/)
* [Unit Testing Best Practices in AngularJS](http://andyshora.com/unit-testing-best-practices-angularjs.html)


#### Aurelia

* [Beginning Aurelia](https://leanpub.com/beginning-of-aurelia) - behzad  *(Leanpub account or valid email requested)*


#### Backbone.js

* [A Complete guide for learning Backbone.js](http://codebeerstartups.com/2012/12/a-complete-guide-for-learning-backbone-js/)
* [A pragmatic guide to Backbone.js apps](http://pragmatic-backbone.com)
* [Backbone Tutorials: Beginner, Intermediate and Advanced](https://leanpub.com/backbonetutorials) - Thomas Davis   *(Leanpub account or valid email requested)*
* [Backbonejs Tutorials](https://cdnjs.com/libraries/backbone.js/tutorials/)
* [Building Single Page Web Apps with Backbone.js](https://singlepagebook.supportbee.com) (:construction: *in process*)
* [Developing Backbone.js Applications](http://addyosmani.github.io/backbone-fundamentals/)
* [Getting Started with Backbone.js](http://net.tutsplus.com/tutorials/javascript-ajax/getting-started-with-backbone-js/)
* [How to share Backbone.js models with node.js](http://amirmalik.net/2010/11/27/how-to-share-backbonejs-models-with-nodejs)


#### Booty5.js

* [The Booty5 HTML5 Game Maker Manual](http://booty5.com/booty5-free-html-game-maker-e-book-manual/)


#### D3.js

* [D3 Tips and Tricks](https://leanpub.com/D3-Tips-and-Tricks/read) - Malcolm Maclean
* [Dashing D3.js Tutorial](https://www.dashingd3js.com/table-of-contents)
* [Interactive Data Visualization with D3](http://alignedleft.com/tutorials/d3)


#### Dojo

* [Dojo: The Definitive Guide](https://www.oreilly.com/library/view/dojo-the-definitive/9780596516482/) - Matthew A. Russell


#### Elm

* [An Introduction to Elm](https://guide.elm-lang.org) (HTML)
* [Beginning Elm](https://elmprogramming.com) - Pawan Poudel  (HTML)
* [Building a Live-Validating Signup Form in Elm](http://tech.noredink.com/post/129641182738/building-a-live-validated-signup-form-in-elm)
* [Elm Accelerated](https://accelerated.amimetic.co.uk) - James Porter
* [Elm Programming Language](https://en.wikibooks.org/wiki/Elm_programming_language) (HTML)
* [Elm Tutorial](https://legacy.gitbook.com/book/sporto/elm-tutorial/details)
* [Learn You an Elm](https://learnyouanelm.github.io) (HTML)
* [The Elm Architecture](https://github.com/evancz/elm-architecture-tutorial)


#### Ember.js

* [AngularJs vs EmberJs](http://angularjs-emberjs-compare.bguiz.com)
* [DockYard Ember.js Style Guide](https://github.com/DockYard/styleguides/blob/master/engineering/ember.md)
* [Ember App with RailsApi](https://dockyard.com/blog/ember/2013/01/07/building-an-ember-app-with-rails-api-part-1)
* [Ember.js - Getting started](https://guides.emberjs.com/release/)
* [Vic Ramon's Ember Tutorial](http://ember.vicramon.com)


#### Express.js

* [Express.js Guide](https://web.archive.org/web/20140621124403/https://leanpub.com/express/read) - Azat Mardanov


#### Ionic

* [Ionic 4 Succinctly](https://www.syncfusion.com/ebooks/ionic-4-succinctly) - Ed Freitas


#### jQuery

* [JavaScript Fundamentals, Plus a Dash Of JQuery - for dinner ladies](http://nicholasjohnson.com/javascript-book/)
* [jQuery Novice to Ninja](http://mediatheque.cite-musique.fr/MediaComposite/Debug/Dossier-Orchestre/ressources/jQuery.Novice.to.Ninja.2nd.Edition.pdf) (PDF)
* [jQuery Succinctly, Syncfusion](https://www.syncfusion.com/resources/techportal/ebooks/jquery) (PDF, Kindle) (email address *requested*, not required)


#### Meteor

* [BulletProof Meteor](https://bulletproofmeteor.com)
* [Your First Meteor Application, A Complete Beginner’s Guide to the Meteor JavaScript Framework](http://meteortips.com/book/)


#### Node.js

* [An Introduction to libuv](https://nikhilm.github.io/uvbook/) - Nikhil Marathe  ([PDF](http://nikhilm.github.io/uvbook/An%20Introduction%20to%20libuv.pdf) - [ePub](http://nikhilm.github.io/uvbook/An%20Introduction%20to%20libuv.epub))
* [Mixu's Node Book](http://book.mixu.net/node/)
* [Node Documentation](https://nodejs.org/en/docs/)
* [Node: Up and Running](https://www.oreilly.com/library/view/node-up-and/9781449332235/) - Tom Hughes-Croucher
* [Node.js Succinctly, Syncfusion](https://www.syncfusion.com/resources/techportal/ebooks/nodejs) (PDF, Kindle) (email address *requested*, not required)
* [The Node Beginner Book](http://nodebeginner.org)


#### Om

* [Om Tutorial](http://awkay.github.io/om-tutorial/)


#### React

* [Free React on Rails course](https://learnetto.com/users/hrishio/courses/the-free-react-on-rails-5-course)
* [Full-Stack React Projects](https://www.packtpub.com/free-ebooks/full-stack-react-projects) - Shama Hoque (Packt account *required*)
* [Hacking with React](http://www.hackingwithreact.com)
* [Intro to the React Framework](http://code.tutsplus.com/tutorials/intro-to-the-react-framework--net-35660)
* [Learning React.js: Getting Started and Concepts](https://scotch.io/tutorials/learning-react-getting-started-and-concepts)
* [React-Bits](https://github.com/vasanthk/react-bits)
* [React Enlightenment](https://www.gitbook.com/book/frontendmasters/react-enlightenment/details)
* [React In-depth: An exploration of UI development](https://www.gitbook.com/book/developmentarc/react-indepth/details)
* [React Primer Draft](https://github.com/mikechau/react-primer-draft)
* [React Succinctly](https://www.syncfusion.com/ebooks/react-succinctly) - Samer Buna
* [React Tutorial](https://reactjs.org/tutorial/tutorial.html)
* React Tutorial by Josh Finnie
  * [Part 1](http://www.joshfinnie.com/blog/reactjs-tutorial-part-1/)
  * [Part 2](http://www.joshfinnie.com/blog/reactjs-tutorial-part-2/)
  * [Part 3](http://www.joshfinnie.com/blog/reactjs-tutorial-part-3/)
* [React with ASP.NET Core Tutorial](https://reactjs.net/getting-started/aspnetcore.html)
* [React.js Tutorial: Now is Your Time to Try It, Right in Your Browser](https://codegeekz.com/react-js-tutorial/)
* [SurviveJS - Webpack and React](http://survivejs.com)


#### React Native

* [Programming React Native](https://leanpub.com/programming-react-native)   *(Leanpub account or valid email requested)*
* [React Native Animation Book](http://browniefed.com/react-native-animation-book/)
* [React Native Express](http://www.reactnativeexpress.com)
* [React Native Training](https://www.gitbook.com/book/unbug/react-native-training/details)


#### Redux

* [Full-Stack Redux Tutorial](http://teropa.info/blog/2015/09/10/full-stack-redux-tutorial.html)
* [SoundCloud Application in React + Redux](https://www.robinwieruch.de/the-soundcloud-client-in-react-redux/)
* [The Complete Redux Book](https://leanpub.com/redux-book) - Boris Dinkevich and Ilya Gelman  *(Leanpub account or valid email requested)*


#### Vue.js

* [Learning Vue.js](https://riptutorial.com/Download/vue-js.pdf) (PDF)


### Jenkins

* [Jenkins: The Definitive Guide](http://www.bogotobogo.com/DevOps/Jenkins/images/Intro_install/jenkins-the-definitive-guide.pdf) (PDF)


### Julia

* [Introducing Julia](https://en.wikibooks.org/wiki/Introducing_Julia) - Wikibooks
* [Julia by Example](http://samuelcolvin.github.io/JuliaByExample) - Samuel Colvin (GitHub repo)
* [Julia language: a concise tutorial](https://www.gitbook.com/book/sylvaticus/julia-language-a-concise-tutorial) - Antonello Lobianco (GitBook)
* [Learn Julia in Y minutes](https://learnxinyminutes.com/docs/julia) - Leah Hanson
* [Quantitative Economics with Julia](https://julia.quantecon.org/_downloads/pdf/quantitative_economics_with_julia.pdf) - Jesse Perla, Thomas J. Sargent and John Stachurski (PDF)
* [The Julia Express](http://bogumilkaminski.pl/files/julia_express.pdf) - Bogumił Kamiński (PDF)
* [Think Julia](https://benlauwens.github.io/ThinkJulia.jl/latest/book.html) - Ben Lauwens and Allen Downey (GitBook)


### Kotlin

* [Kotlin Notes for Professionals book](https://goalkicker.com/KotlinBook/) - Compiled from StackOverflow documentation
* [Kotlin Official Documentation](https://kotlinlang.org/docs/reference/)


### LaTeX / TeX

#### LaTeX

* [Arbitrary LaTex Reference](http://latex.knobs-dials.com)
* [Begin Latex in minutes](https://github.com/VoLuong/Begin-Latex-in-minutes)
* [LaTeX](https://en.wikibooks.org/wiki/LaTeX) - Wikibooks
* [The Not So Short Introduction to LaTeX](https://tobi.oetiker.ch/lshort/lshort.pdf) (PDF)


#### TeX

* [Notes On Programming in TeX](http://pgfplots.sourceforge.net/TeX-programming-notes.pdf) - Christian Feursänger (PDF)
* [TeX by Topic, A TeXnician's Reference](http://eijkhout.net/texbytopic/texbytopic.html) - Victor Eijkhout
* [TeX for the Impatient](https://www.gnu.org/software/teximpatient/) - Paul Abrahams, Kathryn Hargreaves, and Karl Berry


### Limbo

* [Inferno Programming With Limbo](http://doc.cat-v.org/inferno/books/inferno_programming_with_limbo/)


### Linux

* [Ad Hoc Data Analysis From The Unix Command Line](https://en.wikibooks.org/wiki/Ad_Hoc_Data_Analysis_From_The_Unix_Command_Line) - Wikibooks
* [Advanced Linux Programming](https://mentorembedded.github.io/advancedlinuxprogramming/) (PDF)
* [Automated Linux From Scratch](http://www.linuxfromscratch.org/alfs/download.html)
* [Getting Started with Ubuntu](http://ubuntu-manual.org)
* [GNU Autoconf, Automake and Libtool](http://www.sourceware.org/autobook/download.html)
* [GTK+/Gnome Application Development](http://www.linuxtopia.org/online_books/gui_toolkit_guides/gtk+_gnome_application_development/)
* [Hardened Linux From Scratch](http://www.linuxfromscratch.org/hlfs/download.html)
* [Kali Linux 2018: Assuring Security by Penetration Testing, Fourth Edition](https://www.packtpub.com/free-ebooks/kali-linux-2018-assuring-security-penetration-testing-fourth-edition) - Shiva V. N Parasram, Alex Samm, Damian Boodoo, Gerard Johansen, Lee Allen, Tedi Heriyanto, Shakeel Ali (Packt account *required*)
* [Kali Linux: Professional Penetration-Testing Distribution](http://docs.kali.org)
* [Learning Debian GNU/Linux](http://www.oreilly.com/openbook/debian/book/index.html)
* [Linux 101 Hacks](http://thegeekstuff.s3.amazonaws.com/files/linux-101-hacks.zip) - Ramesh Natarajan (PDF)
* [Linux Administrator's Security Guide](http://www.linuxtopia.org/online_books/linux_administrators_security_guide/index.html)
* [Linux Advanced Routing & Traffic Control HOWTO](http://lartc.org)
* [Linux Device Drivers, Third Edition](http://lwn.net/Kernel/LDD3/) - Jonathan Corbet, Alessandro Rubini, and Greg Kroah-Hartman
* [Linux from Scratch](http://www.linuxfromscratch.org/lfs/view/stable/)
* [Linux Inside](https://www.gitbook.com/book/0xax/linux-insides/details)
* [Linux Kernel in a Nutshell](http://www.kroah.com/lkn/)
* [Linux Newbie Administrator Guide](http://lnag.sourceforge.net)
* [Linux Security for Beginners](http://www.linuxtopia.org/LinuxSecurity/index.html)
* [Linux Succinctly, Syncfusion](https://www.syncfusion.com/resources/techportal/ebooks/linux) (PDF, Kindle) (email address *requested*, not required)
* [OpenVZ Linux virtualization](https://docs.virtuozzo.com/pdf/virtuozzo_infrastructure_platform_quick_start_guide.pdf) (PDF)
* [Red Hat Enterprise Linux 6 Essentials](http://www.techotopia.com/index.php/Red_Hat_Enterprise_Linux_6_Essentials)
* [Secure Programming HOWTO - Creating Secure Software](http://www.dwheeler.com/secure-programs/) - D. A. Wheeler (HTML, PDF)
* [Ten Steps to Linux Survival: Bash for Windows People](http://dullroar.com/book/TenStepsToLinuxSurvival.html) - Jim Lehmer
* [The Debian Administrator's Handbook](https://debian-handbook.info)
* [The Linux Command Line](http://linuxcommand.org/tlcl.php) (PDF)
* [The Linux Development Platform](http://ptgmedia.pearsoncmg.com/imprint_downloads/informit/perens/0130091154.pdf) (PDF)
* [The Linux Kernel Module Programming Guide](http://tldp.org/LDP/lkmpg/2.6/html/)
* [The Linux System Administrator's Guide](http://www.tldp.org/LDP/sag/html/index.html)
* [Ubuntu Pocket Guide and Reference](http://www.ubuntupocketguide.com/index_main.html)
* [Ubuntu Server Guide](https://help.ubuntu.com/16.04/serverguide/serverguide.pdf) (PDF)
* [Understanding the Linux Virtual Memory Manager](https://www.kernel.org/doc/gorman/) - Mel Gorman (HTML, PDF)
* [UNIX Systems Programming for SVR4](http://www.bitsinthewind.com/about-dac/publications/unix-systems-programming) - David A. Curry
* [Upstart Intro, Cookbook and Best Practises](http://upstart.ubuntu.com/cookbook/)
* [What Every Programmer Should Know About Memory](http://www.akkadia.org/drepper/cpumemory.pdf) (PDF)


### Lisp

* [Basic Lisp Techniques](http://franz.com/resources/educational_resources/cooper.book.pdf) - David J. Cooper, Jr. (PDF)
* [Casting Spels in Lisp](http://www.lisperati.com/casting.html)
* [Common Lisp: A Gentle Introduction to Symbolic Computation](http://www.cs.cmu.edu/~dst/LispBook/) - David S. Touretzky (PDF, PS)
* [Common Lisp: An Interactive Approach](http://www.cse.buffalo.edu/~shapiro/Commonlisp/) - Stuart C. Shapiro
* [Common Lisp Quick Reference](http://clqr.boundp.org)
* [Common Lisp the Language, 2nd Edition](http://www.cs.cmu.edu/Groups/AI/html/cltl/mirrors.html)
* [Google's Common Lisp Style Guide](https://google.github.io/styleguide/lispguide.xml)
* [Interpreting LISP](http://www.civilized.com/files/lispbook.pdf) - Gary D. Knott (PDF)
* [Learn Lisp The Hard Way](https://github.com/LispTO/llthw) - Colin J.E. Lupton
* [Let Over Lambda - 50 Years of Lisp](http://letoverlambda.com/index.cl/) - D. Hoyte
* [Lisp Hackers: Interviews with 100x More Productive Programmers](https://leanpub.com/lisphackers/read) - Vsevolod Dyomkin
* [Lisp Koans](https://github.com/google/lisp-koans)
* [Lisp Web Tales](https://leanpub.com/lispwebtales) - Pavel Penev *(Leanpub account or valid email requested)*
* [On Lisp](http://www.paulgraham.com/onlisp.html) - P. Graham
* [Paradigms of Artificial Intelligence Programming: Case Studies in Common Lisp](https://github.com/norvig/paip-lisp) - Peter Norvig (PDF, epub, markdown)
* [Practical Common Lisp](http://www.gigamonkeys.com/book/) - P. Seibel
* [SOLID Design Principles in Common Lisp](https://common-lisp-reserve.github.io/solid-design-principles-in-common-lisp/solid-design-principles-in-common-lisp.pdf) - Momozor (PDF)
* [Successful Lisp: How to Understand and Use Common Lisp](https://github.com/clojurians-org/lisp-ebook/blob/master/Successful%20Lisp%20How%20to%20Understand%20and%20Use%20Common%20Lisp%20-%20David%20B.%20Lamkins.pdf) - David Lamkins (PDF)
* [The Common Lisp Cookbook](https://lispcookbook.github.io/cl-cookbook/)
* [The Evolution of Lisp](http://www.dreamsongs.com/Files/HOPL2-Uncut.pdf) - Guy L. Steele Jr., Richard P. Gabriel (PDF)


### Livecode

* [LiveCode userguide](http://www.scribd.com/doc/216789127/LiveCode-userguide) (PDF)


### Lua

* [Lua 5.3 Reference Manual](http://www.lua.org/manual/5.3/)
* [Lua Programming](https://en.wikibooks.org/wiki/Lua_Programming) - Wikibooks
* [Programming in Lua (first edition)](https://www.lua.org/pil/contents.html)


### Make

* [Managing Projects with GNU Make](https://www.oreilly.com/openbook/make3/book/index.html) - Robert Mecklenburg


### Markdown

* [Learn Markdown](https://www.gitbook.com/book/gitbookio/markdown/details) - Sammy P., Aaron O. (PDF) (EPUB) (MOBI)


### Mathematica

* [Mathematica® programming: an advanced introduction by Leonid Shifrin](http://www.mathprogramming-intro.org)
* [Stephen Wolfram's The Mathematica Book](http://reference.wolfram.com/legacy/v5_2/)
* [Vector Math for 3d Computer Graphics](http://chortle.ccsu.edu/VectorLessons/index.html)
* [Wolfram Mathematica Tutorial Collection](http://www.wolfram.com/learningcenter/tutorialcollection/)


### MATLAB

* [An Interactive Introduction to MATLAB](http://www.science.smith.edu/~jcardell/Courses/EGR326/Intro-to-MATLAB.pdf) (PDF)
* [An Introduction to MATLAB](http://www.maths.dundee.ac.uk/software/MatlabNotes.pdf) (PDF)
* [Applications of MATLAB in Science and Engineering](http://www.intechopen.com/books/applications-of-matlab-in-science-and-engineering)
* [Experiments with MATLAB](http://www.mathworks.com/moler/exm/index.html?requestedDomain=www.mathworks.com&nocookie=true)
* [Freshman Engineering Problem Solving with MATLAB](https://cnx.org/exports/3a643c1f-c1ba-4c2a-8065-317a1f2b1add@18.1.pdf/freshman-engineering-problem-solving-with-matlab-18.1.pdf) (PDF)
* [Interactive Tutorials for MATLAB, Simulink, Signal Processing, Controls, and Computational Mathematics](http://www.mathworks.com/tutorials)
* [MATLAB - A Fundamental Tool for Scientific Computing and Engineering Applications - Volume 1](http://www.intechopen.com/books/matlab-a-fundamental-tool-for-scientific-computing-and-engineering-applications-volume-1)
* [MATLAB - A Ubiquitous Tool for the Practical Engineer](http://www.intechopen.com/books/matlab-a-ubiquitous-tool-for-the-practical-engineer)
* [MATLAB for Engineers: Applications in Control, Electrical Engineering, IT and Robotics](http://www.intechopen.com/books/matlab-for-engineers-applications-in-control-electrical-engineering-it-and-robotics)
* [MATLAB Programming](https://en.wikibooks.org/wiki/MATLAB_Programming) - Wikibooks
* [MATLAB Succinctly, Syncfusion](https://www.syncfusion.com/resources/techportal/ebooks/matlab) (PDF, Kindle) (email address *requested*, not required)
* [Numerical Computing with MATLAB](http://www.mathworks.com/moler/index_ncm.html?requestedDomain=www.mathworks.com&nocookie=true)
* [Physical Modeling in MATLAB](http://greenteapress.com/matlab/index.html) - Alan B. Downey


### Maven

* [Developing with Eclipse and Maven](http://books.sonatype.com/m2eclipse-book/reference/)
* [Maven by Example](http://books.sonatype.com/mvnex-book/reference/public-book.html)
* [Maven: The Complete Reference](http://books.sonatype.com/mvnref-book/reference/public-book.html)
* [Repository Management with Nexus](http://books.sonatype.com/nexus-book/reference/)


### Mercurial

* [HGInit - Mercurial Tutorial](https://web.archive.org/web/20180926172759/http://hginit.com/) - Joel Spolsky
* [Mercurial: The Definitive Guide](http://hgbook.red-bean.com)
* [Mercurial: The Definitive Guide 2nd edition](https://book.mercurial-scm.org) ([source repository](https://bitbucket.org/hgbook/hgbook)) (:construction: *in process*)


### Mercury

* [The Mercury Users' Guide](http://www.mercurylang.org/information/doc-release/user_guide.pdf) (PDF)


### Modelica

* [Modelica by Example](http://book.xogeny.com)


### MySQL

* [MySQL Essentials](http://www.techotopia.com/index.php/MySQL_Essentials)
* [MySQL Tutorial Excerpt](http://downloads.mysql.com/docs/mysql-tutorial-excerpt-5.5-en.pdf) (PDF)


### Neo4J

* [Graph Databases](http://info.neotechnology.com/rs/neotechnology/images/GraphDatabases.pdf) (PDF)
* [Graph Databases 2nd edition](http://neo4j.com/books/graph-databases/) *(account required)*


### .NET Framework

* [Akka.NET Succinctly](https://www.syncfusion.com/ebooks/akka_net_succinctly) - Zoran Maksimovic
* [Application Security in .NET Succinctly](https://www.syncfusion.com/ebooks/application_security_in_net_succinctly) - Stan Drapkin
* [Clean Code .NET](https://github.com/thangchung/clean-code-dotnet)
* [Cryptography in .NET Succinctly](https://www.syncfusion.com/ebooks/cryptography_in_net_succinctly) - Dirk Strauss
* [Entity Framework](http://weblogs.asp.net/zeeshanhirani/my-christmas-present-to-the-entity-framework-community)
* [Entity Framework Core Succinctly](https://www.syncfusion.com/ebooks/entity_frame_work_core_succinctly) - Ricardo Peres
* [Game Creation with XNA](https://en.wikibooks.org/wiki/Game_Creation_with_XNA) - Wikibooks
* [Getting the Most from LINQPad Succinctly](https://www.syncfusion.com/ebooks/getting-the-most-from-linqpad-succinctly) - José Roberto Olivas Mendoza
* [MonoGame Succinctly](https://www.syncfusion.com/ebooks/monogame_succinctly) - Jim Perry
* [.NET for Visual FoxPro Developers](http://foxcentral.net/microsoft/NETforVFPDevelopers.htm)
* [.NET Performance Testing and Optimization - The Complete Guide](https://www.red-gate.com/library/net-performance-testing-and-optimization-the-complete-guide) - Paul Glavich, Chris Farrell (PDF)
* [NuGet In-House Succinctly](https://www.syncfusion.com/ebooks/nuget-in-house-succinctly) - José Roberto Olivas Mendoza
* [Rider Succinctly](https://www.syncfusion.com/ebooks/rider-succinctly) - Dmitri Nesteruk
* [Under the Hood of .NET Memory Management](https://assets.red-gate.com/community/books/under-the-hood-of-net-memory-management.pdf) - Chris Farrell, Nick Harrison (PDF)
* [Using .NET Core, Docker, and Kubernetes Succinctly](https://www.syncfusion.com/ebooks/using-netcore-docker-and-kubernetes-succinctly) - Michele Aponte
* [Visual Studio .NET Tips and Tricks](http://www.infoq.com/minibooks/vsnettt) (VS 2003-2005 only)
* [Visual Studio 2019 Succinctly](https://www.syncfusion.com/ebooks/visual-studio-2019-succinctly) - Alessandro Del Sole


### Nim

* [Nim Basics](https://narimiran.github.io/nim-basics/)


### NoSQL

* [CouchDB: The Definitive Guide](http://guide.couchdb.org)
* [Extracting Data from NoSQL Databases: A Step towards Interactive Visual Analysis of NoSQL Data](http://publications.lib.chalmers.se/records/fulltext/155048.pdf) - Petter Nasholm (PDF)
* [Graph Databases](http://graphdatabases.com)
* [MongoDB Koans](https://github.com/chicagoruby/MongoDB_Koans)
* [MongoDB Succinctly, Syncfusion](https://www.syncfusion.com/resources/techportal/ebooks/mongodb) (PDF, Kindle) (email address *requested*, not required)
* [NoSQL Databases](http://www.christof-strauch.de/nosqldbs.pdf) - Christof Strauch (PDF)
* [The Little MongoDB Book](http://openmymind.net/2011/3/28/The-Little-MongoDB-Book/)
* [The Little Redis Book](http://openmymind.net/2012/1/23/The-Little-Redis-Book/) - K. Seguin (PDF, Epub)


### Oberon

* [Algorithms and Data-Structures](https://inf.ethz.ch/personal/wirth/AD.pdf) - Niklaus Wirth (PDF)
* [Object-Oriented Programming in Oberon-2](http://ssw.jku.at/Research/Books/Oberon2.pdf) - Hanspeter Mössenböck (PDF)
* [Programming in Oberon](https://www.inf.ethz.ch/personal/wirth/ProgInOberonWR.pdf) - Niklaus Wirth (PDF)


### Objective-C

* [Google's Objective-C Style Guide](https://github.com/google/styleguide/blob/gh-pages/objcguide.md)
* [Object-Oriented Programming with Objective-C](https://developer.apple.com/library/ios/documentation/Cocoa/Conceptual/OOP_ObjC/Introduction/Introduction.html#//apple_ref/doc/uid/TP40005149)
* [Objective-C Succinctly, Syncfusion](https://www.syncfusion.com/resources/techportal/ebooks/objective-c) (PDF, Kindle) (email address *requested*, not required)
* [Programming With Objective-C](https://developer.apple.com/library/mac/documentation/Cocoa/Conceptual/ProgrammingWithObjectiveC/Introduction/Introduction.html)


### OCaml

* [Developing Applications With Objective Caml](http://caml.inria.fr/pub/docs/oreilly-book/)
* [Real World OCaml](https://realworldocaml.org/v1/en/html/)
* [Think OCaml](http://greenteapress.com/thinkocaml/index.html) - Allen B. Downey and Nicholas Monje
* [Unix System Programming in OCaml](http://ocaml.github.io/ocamlunix/) [Github Repo](https://github.com/ocaml/ocamlunix/)
* [Using, Understanding, and Unraveling The OCaml Language: From Practice to Theory and vice versa](http://pauillac.inria.fr/~remy/cours/appsem/) - Didier Rémy


### Octave

* [Octave Programming](https://en.wikibooks.org/wiki/Octave_Programming_Tutorial) - Wikibooks


### OpenMP

* [A Guide To OpenMP](http://bisqwit.iki.fi/story/howto/openmp/)
* [OpenMP Application Programming Interface Standard Version 4.0](http://www.openmp.org/mp-documents/OpenMP4.0.0.pdf) (PDF)
* [OpenMP Application Programming Interface Standard Version 5.0](https://www.openmp.org/wp-content/uploads/OpenMP-API-Specification-5.0.pdf) (PDF)


### OpenResty

* [Programming OpenResty](https://www.gitbook.com/book/openresty/programming-openresty/details)


### OpenSCAD

* [OpenSCAD User Manual](https://en.wikibooks.org/wiki/OpenSCAD_User_Manual) - Wikibooks


### TrueOS

* [TrueOS® Users Handbook](https://www.trueos.org/handbook/trueos.html)


### Perl

* [Beginning Perl](https://www.perl.org/books/beginning-perl/)
* [Data Munging with Perl](http://perlhacks.com/dmp.pdf) (PDF)
* [Embedding Perl in HTML with Mason](http://masonbook.houseabsolute.com/book/) - D. Rolsky, K. Williams
* [Essential Perl](http://cslibrary.stanford.edu/108/EssentialPerl.pdf) (PDF)
* [Exploring Programming Language Architecture in Perl](http://www.billhails.net/Book/)
* [Extreme Perl](http://www.extremeperl.org/bk/home) - R. Nagier (HTML, PDF)
* [Higher-Order Perl](http://hop.perl.plover.com/book/) - M. J. Dominus (PDF)
* [Impatient Perl](https://www.perl.org/books/impatient-perl/)
* [Learning Perl The Hard Way](http://www.greenteapress.com/perl/)
* [Modern Perl 5](http://www.onyxneon.com/books/modern_perl/)
* [Perl & LWP](http://lwp.interglacial.com/index.html)
* [Perl 5 Internals](http://www.faqs.org/docs/perl5int/)
* [Perl for the Web](http://www.globalspin.com/thebook/) - C. Radcliff
* [Perl Training Australia - Course Notes](http://perltraining.com.au/notes.html)
* [Plack Handbook](http://handbook.plackperl.org)
* [SDL::Manual Writing Games in Perl](https://github.com/PerlGameDev/SDL_Manual)
* [Template Toolkit Documentation](http://template-toolkit.org/docs/index.html)
* [The DBIx-Class Book](https://github.com/castaway/dbix-class-book)
* [The PDL Book](http://sourceforge.net/projects/pdl/files/PDL_2013/PDL-Book/PDL-Book-20130322.pdf/download) (PDF)
* [Web Client Programming with Perl](http://www.oreilly.com/openbook/webclient/)


### Perl 6 / Raku

* [Perl 6 at a Glance](https://perl6.online/perl6-at-a-glance/) - Andrew Shitov (HTML) (PDF)
* [Perl 6 Introduction](http://perl6intro.com)
* [Perl 6 Programming](https://en.wikibooks.org/wiki/Perl_6_Programming) - Wikibooks
* [Raku One-Liners](https://web.archive.org/web/20191101151545/https://deeptext.media/i/raku-oneliners/RakuOneLiners.pdf) - Andrew Shitov (PDF)
* [Think Perl 6](http://greenteapress.com/thinkperl6/thinkperl6.pdf) - Laurent Rosenfeld, with Allen B. Downey (PDF)
* [Using Perl 6](https://github.com/perl6/book/) (:construction: *project is dead*)


### PHP

* [PHP 5 Power Programming](http://www.informit.com/content/images/013147149X/downloads/013147149X_book.pdf) (PDF)
* [PHP Best Practices](https://phpbestpractices.org)
* [PHP Internals Book](http://www.phpinternalsbook.com)
* [PHP Pandas](http://daylerees.com/php-pandas/) - Dayle Rees
* [PHP Programming](https://en.wikibooks.org/wiki/PHP_Programming) - Wikibooks
* [PHP Security Guide](http://phpsec.org/projects/guide/)
* [PHP: The Right Way](http://www.phptherightway.com)
* [PHPUnit Manual](https://phpunit.de/manual/current/en/phpunit-book.pdf) - Sebastian Bergmann (PDF)
* [Practical PHP Programming](http://www.hackingwithphp.com)
* [Practical PHP Testing](http://www.giorgiosironi.com/2009/12/practical-php-testing-is-here.html)
* [Survive The Deep End: PHP Security](https://phpsecurity.readthedocs.org/en/latest/)
* [Using Libsodium in PHP Projects](https://paragonie.com/book/pecl-libsodium)


#### CakePHP

* [CakePHP Cookbook 2.x](http://book.cakephp.org/2.0/_downloads/en/CakePHPCookbook.pdf) (PDF)


#### CodeIgniter

* [CodeIgniter 3 User Guide](https://codeigniter.com/user_guide/index.html)
* [CodeIgniter 4 User Guide](https://codeigniter4.github.io/userguide/)


#### Drupal

* [The Tiny Book of Rules](https://www.drupal.org/files/tiny-book-of-rules.pdf) (PDF)


#### Laravel

* [Laravel 5.x Official Documentation. Synced Daily](https://leanpub.com/laravel-5)  *(Leanpub account or valid email requested)*
* [Laravel Best Practices](http://www.laravelbestpractices.com)
* [Laravel: Code Bright](http://daylerees.com/codebright) - Dayle Rees
* [Laravel: Code Happy](http://daylerees.com/codehappy) - Dayle Rees
* [Laravel: Code Smart](https://daylerees.com/codesmart/) - Dayle Rees
* [Laravel Collections Unraveled](https://leanpub.com/laravelcollectionsunraveled) - Jeffrey Madsen  *(Leanpub account or valid email requested)*


#### Symfony

* [The Symfony Best practices 4.1.x](https://web.archive.org/web/20181017123206/https://symfony.com/pdf/Symfony_best_practices_4.1.pdf) (PDF)
* [The Symfony Book 2.8.x](https://symfony.com/doc/2.8/index.html)
* [The Symfony Book 3.4.x](https://symfony.com/doc/3.4/index.html)
* [The Symfony Book 4.4.x](https://symfony.com/doc/4.4/index.html)


#### Zend

* [Using Zend Framework 3](https://olegkrivtsov.github.io/using-zend-framework-3-book/html/)


### PicoLisp

* [PicoLisp by Example](https://github.com/tj64/picolisp-by-example)
* [PicoLisp Works](https://github.com/tj64/picolisp-works)


### PostgreSQL

* [Postgres Official Documentation](http://www.postgresql.org/docs/)
* [Postgres Succinctly](https://www.syncfusion.com/resources/techportal/ebooks/postgres) (PDF, Kindle) (email address *requested*, not required)
* [Practical PostgreSQL](http://www.faqs.org/docs/ppbook/book1.htm)
* [The Internals of PostgreSQL for database administrators and system developers](http://www.interdb.jp/pg)


### PowerShell

* [Creating HTML Reports in PowerShell](https://www.gitbook.com/book/devopscollective/creating-html-reports-in-powershell/details) (PDF,ePub,HTML)
* [DevOps: The Ops Perspective](https://www.gitbook.com/book/devopscollective/devops-the-ops-perspective/details) (PDF, ePub, MOBI)
* [Ditch Excel: Making Historical & Trend Reports in PowerShell](https://www.gitbook.com/book/devopscollective/ditch-excel-making-historical-trend-reports-in-po/details) (PDF, ePub, MOBI)
* [Introduction to PowerShell for Unix People](https://www.gitbook.com/book/devopscollective/a-unix-person-s-guide-to-powershell/details) (PDF, ePub, HTML)
* [Layman’s Guide to PowerShell 2.0 remoting](http://www.ravichaganti.com//blog/wp-content/uploads/2010/12/A%20layman's%20guide%20to%20PowerShell%202.0%20remoting-v2.pdf) (PDF)
* [Learn PowerShell Core 6.0](https://www.packtpub.com/free-ebooks/learn-powershell-core-60) - David das Neves, Jan-Hendrik Peters (Packt account *required*)
* [Mastering PowerShell v2](http://community.idera.com/powershell/powertips/b/ebookv2#pi619PostSortOrder=Ascending)
* [PowerShell 2.0 – One CMDLET At A Time](http://www.jonathanmedd.net/wp-content/uploads/2010/09/PowerShell_2_One_Cmdlet_at_a_Time.pdf) (PDF)
* [PowerShell Notes for Professionals](http://books.goalkicker.com/PowerShellBook/) - Compiled from StackOverflow documentation (3.x)
* [PowerShell Succinctly, Syncfusion](https://www.syncfusion.com/resources/techportal/ebooks/powershell) (PDF, Kindle) (email address *requested*, not required)
* [PowerShell Tips to Write By](https://leanpub.com/powershelltips) - Adam Bertram *(Leanpub account or valid email requested)* (:construction: *in process*)
* [Secrets of PowerShell Remoting](https://www.gitbook.com/book/devopscollective/secrets-of-powershell-remoting/details) (PDF, ePub, MOBI)
* [The Big Book of PowerShell Error Handling](https://www.gitbook.com/book/devopscollective/the-big-book-of-powershell-error-handling/details) (PDF, ePub, MOBI)
* [The Big Book of PowerShell Gotchas](https://www.gitbook.com/book/devopscollective/the-big-book-of-powershell-gotchas/details) (PDF, ePub, MOBI)
* [The DSC Book](https://www.penflip.com/powershellorg/the-dsc-book) (PDF, ePub, HTML)
* [The Monad Manifesto - Annotated](https://www.gitbook.com/book/devopscollective/the-monad-manifesto-annotated/details) (PDF, ePub, MOBI)
* [Why PowerShell?](https://www.gitbook.com/book/devopscollective/why-powershell-/details) (PDF, ePub, MOBI)
* [Windows PowerShell Networking Guide](https://www.gitbook.com/book/devopscollective/windows-powershell-networking-guide/details) (PDF, ePub, MOBI)


### Processing

* [The Nature of Code: Simulating Natural Systems with Processing](http://natureofcode.com/book/)


### Prolog

* [Adventure in Prolog](http://www.amzi.com/AdventureInProlog/)
* [Applications of Prolog](http://bookboon.com/en/applications-of-prolog-ebook) - Attila Csenki, Bookboon. (email address *requested*, not required)
* [Coding Guidelines for Prolog](http://arxiv.org/abs/0911.2899) - Michael A. Covington, Roberto Bagnara, Richard A. O'Keefe, Jan Wielemaker, Simon Price
* [Concise Intro to Prolog](http://www.cis.upenn.edu/~matuszek/Concise%20Guides/Concise%20Prolog.html)
* [Expert Systems in Prolog](http://www.amzi.com/ExpertSystemsInProlog/)
* [GNU Prolog Manual](http://www.gprolog.org/manual/gprolog.pdf) (PDF)
* [Introduction to Prolog for Mathematicians](http://www.j-paine.org/prolog/mathnotes/files/pms/pms.html) - J. Ireson-Ireson-Paine
* [Learn Prolog Now!](http://www.learnprolognow.org)
* [Logic, Programming and Prolog (2ed)](http://www.ida.liu.se/~ulfni53/lpp/)
* [Natural Language Processing Techniques in Prolog](http://cs.union.edu/~striegnk/courses/nlp-with-prolog/html/) - P. Blackburn, K. Striegnitz
* [Prolog and Natural - Language Analysis](http://www.mtome.com/Publications/PNLA/pnla-digital.html) - Fernando C. N. Pereira, Stuart M. Shieber
* [Prolog for Programmers](https://sites.google.com/site/prologforprogrammers/)
* [Prolog Problems](https://sites.google.com/site/prologsite/prolog-problems) - Werner Hett
* [Prolog Techniques](http://bookboon.com/en/prolog-techniques-applications-of-prolog-ebook) - Attila Csenki, Bookboon. (email address *requested*, not required)
* [Prolog Tutorial](http://www.cpp.edu/~jrfisher/www/prolog_tutorial/contents.html)
* [The Art of Prolog, Second Edition](https://mitpress.mit.edu/books/art-prolog-second-edition) -  Leon S. Sterling, Ehud Y. Shapiro (Open Access)
* [The First 10 Prolog Programming Contests](https://dtai.cs.kuleuven.be/ppcbook/) - Bart Demoen, Phuong-Lan Nguyen, Tom Schrijvers, Remko Tronçon
* [Warren's Abstract Machine: A Tutorial Reconstruction](http://wambook.sourceforge.net) - Hassan A¨it-Kaci


#### Constraint Logic Programming (extended Prolog)

* [A Gentle Guide to Constraint Logic Programming via ECLiPSe](http://anclp.pl)


### PureScript

* [PureScript By Example](https://leanpub.com/purescript/read) - Phil Freeman


### Python

* [20 Python Libraries You Aren't Using (But Should)](https://www.oreilly.com/learning/20-python-libraries-you-arent-using-but-should) - Caleb Hattingh
* [A Beginner's Python Tutorial](https://en.wikibooks.org/wiki/A_Beginner%27s_Python_Tutorial) - Wikibooks
* [A Byte of Python](https://python.swaroopch.com) (3.x) (HTML, PDF, EPUB, Mobi)
* [A Guide to Python's Magic Methods](https://github.com/RafeKettler/magicmethods) - Rafe Kettler
* [A Whirlwind Tour of Python](http://www.oreilly.com/programming/free/files/a-whirlwind-tour-of-python.pdf) - Jake VanderPlas (PDF) [(EPUB, MOBI)](http://www.oreilly.com/programming/free/a-whirlwind-tour-of-python.csp?download=yes)
* [Automate the Boring Stuff](http://automatetheboringstuff.com/chapter0/) - Al Sweigart
* [Biopython](http://biopython.org/DIST/docs/tutorial/Tutorial.pdf) (PDF)
* [Build applications in Python the antitextbook](http://github.com/thewhitetulip/build-app-with-python-antitextbook) (3.x) (HTML, PDF, EPUB, Mobi)
* [Building Skills in Object-Oriented Design (Python)](https://web.archive.org/web/20190914230227/http://www.itmaybeahack.com/book/oodesign-python-2.1/latex/BuildingSkillsinOODesign.pdf) - Steven F. Lott (PDF) (2.1.1)
* [Building Skills in Python](https://web.archive.org/web/20190918094202/http://www.itmaybeahack.com/book/python-2.6/latex/BuildingSkillsinPython.pdf) - Steven F. Lott (PDF) (2.6)
* [Code Like a Pythonista: Idiomatic Python](https://web.archive.org/web/20180411011411/http://python.net/~goodger/projects/pycon/2007/idiomatic/handout.html) - David Goodger
* [CodeCademy Python](https://www.codecademy.com/learn/python)
* [Composing Programs](http://composingprograms.com) (3.x)
* [Cracking Codes with Python](http://inventwithpython.com/cracking/) - Al Sweigart
* [Data Structures and Algorithms in Python](https://web.archive.org/web/20161016153130/http://www.brpreiss.com/books/opus7/html/book.html) - B. R. Preiss (PDF)
* [Dive into Python 3](https://diveintopython3.problemsolving.io) - Mark Pilgrim (3.0)
  * [Dive into Python](https://linux.die.net/diveintopython/html/toc/index.html) - Mark Pilgrim (2.3)
* [From Python to NumPy](http://www.labri.fr/perso/nrougier/from-python-to-numpy/)
* [Full Stack Python](http://www.fullstackpython.com)
* [Functional Programming in Python](https://www.oreilly.com/ideas/functional-programming-in-python) - David Mertz
* [Fundamentals of  Python Programming](https://web.archive.org/web/20191005170430/http://python.cs.southern.edu/pythonbook/pythonbook.pdf) - Richard L. Halterman (PDF) (:construction: *in process*)
* [Google's Python Class](https://developers.google.com/edu/python/) (2.4 - 2.x)
* [Google's Python Style Guide](https://google.github.io/styleguide/pyguide.html)
* [Hadoop with Python](https://www.oreilly.com/learning/hadoop-with-python) -  Zachary Radtka, Donald Miner
* [Hands-On Natural Language Processing with Python](https://www.packtpub.com/free-ebooks/hands-natural-language-processing-python) - Rajesh Arumugam, Rajalingappaa Shanmugamani (Packt account *required*)
* [Hitchhiker's Guide to Python!](http://docs.python-guide.org/en/latest/) (2.6)
* [How to Make Mistakes in Python](http://www.oreilly.com/programming/free/files/how-to-make-mistakes-in-python.pdf) - Mike Pirnat (PDF) (1st edition)
* [How to Think Like a Computer Scientist: Learning with Python, Interactive Edition](http://interactivepython.org/courselib/static/thinkcspy/index.html) (3.2)
  * [How to Think Like a Computer Scientist: Learning with Python](http://www.greenteapress.com/thinkpython/thinkCSpy/) - Allen B. Downey, Jeff Elkner and Chris Meyers (2.4)
  * [Think Python](http://www.greenteapress.com/thinkpython/) - Allen B. Downey (2.x & 3.0)
* [Intermediate Python](http://book.pythontips.com/en/latest/index.html#) - Muhammad Yasoob Ullah Khalid (1st edition)
* [Introduction to Programming with Python](http://opentechschool.github.io/python-beginners/en/) (3.3)
  * [Introduction to Programming Using Python](http://python-ebook.blogspot.co.uk) - Cody Jackson (1st edition) (2.3)
* [Introduction to Python](http://kracekumar.com/post/71171551647/introduction-to-python) - Kracekumar (2.7.3)
* [Invent Your Own Computer Games With Python](http://inventwithpython.com/chapters/) - Al Sweigart (3.1)
* [Learn Python, Break Python](http://learnpythonbreakpython.com)
* [Learn Python in Y minutes](https://learnxinyminutes.com/docs/python/)
* [Learn Python Programming, Second Edition](https://www.packtpub.com/free-ebooks/learn-python-programming-second-edition) - Fabrizio Romano (Packt account *required*)
* [Learn to Program Using Python](https://www.ida.liu.se/~732A47/literature/PythonBook.pdf) - Cody Jackson (PDF)
* [Learning to Program](http://www.alan-g.me.uk)
* [Lectures on scientific computing with python](https://github.com/jrjohansson/scientific-python-lectures) - J.R. Johansson (2.7)
* [Making Games with Python & Pygame](http://inventwithpython.com/pygame/chapters/) - Al Sweigart (2.7)
* [Math for programmers (using python)](https://akuli.github.io/math-tutorial/)
* [Modeling Creativity: Case Studies in Python](http://www.clips.ua.ac.be/sites/default/files/modeling-creativity.pdf) - Tom D. De Smedt (PDF)
* [Natural Language Processing with Python](http://www.nltk.org/book/) (3.x)
* [Non-Programmer's Tutorial for Python 3](https://en.wikibooks.org/wiki/Non-Programmer%27s_Tutorial_for_Python_3) - Wikibooks (3.3)
  * [Non-Programmer's Tutorial for Python 2.6](https://en.wikibooks.org/wiki/Non-Programmer%27s_Tutorial_for_Python_2.6) - Wikibooks (2.6)
* [Picking a Python Version: A Manifesto](https://www.oreilly.com/ideas/picking-a-python-version) - David Mertz
* [Porting to Python 3: An In-Depth Guide](http://python3porting.com) (2.6 - 2.x & 3.1 - 3.x)
* [Practical Programming in Python](https://launchpadlibrarian.net/165489933/PracticalProgrammingPython2014.pdf) - Jeffrey Elkner (PDF)
* [Problem Solving with Algorithms and Data Structures using Python](http://interactivepython.org/runestone/static/pythonds/index.html) - Bradley N. Miller and David L. Ranum
* [Program Arcade Games With Python And Pygame](http://programarcadegames.com) (3.3)
* [Programming Computer Vision with Python](http://programmingcomputervision.com/downloads/ProgrammingComputerVision_CCdraft.pdf) (PDF)
* [Python 2 Official Documentation](https://docs.python.org/2/download.html) (PDF, HTML, TEXT) (2.x)
* [Python 2.7 quick reference](https://web.archive.org/web/20171013204449/http://infohost.nmt.edu/tcc/help/pubs/python27/python27.pdf) - John W. Shipman (PDF) (2.7)
* [Python 3 Official Documentation](https://docs.python.org/3/download.html) (PDF, EPUB, HTML, TEXT) (3.x)
* [Python 3 Tutorial](https://github.com/Akuli/python-tutorial)
* [Python Data Science Handbook](https://github.com/jakevdp/PythonDataScienceHandbook) - Jake VanderPlas (HTML, Jupyter Notebooks)
* [Python for Everybody Exploring Data Using Python 3](http://py4e.com/book.php) - Charles Severance (PDF, EPUB, HTML)
  * [Python for Informatics: Exploring Information](http://www.pythonlearn.com/book.php) (2.7.5)
* [Python for you and me](http://pymbook.readthedocs.org/en/latest/) (2.7.3)
* [Python for you and me](http://pymbook.readthedocs.org/en/py3/) (3.x)
* [Python Idioms](http://safehammad.com/downloads/python-idioms-2014-01-16.pdf) (PDF)
* [Python in Education](https://www.oreilly.com/ideas/python-in-education) - Nicholas Tollervey
* [Python in Hydrology](http://www.greenteapress.com/pythonhydro/pythonhydro.html) - Sat Kumar Tomer
* [Python Koans](https://github.com/gregmalcolm/python_koans) (2.7 or 3.x)
* [Python Machine Learning By Example](https://www.packtpub.com/free-ebooks/python-machine-learning-example) - Yuxi (Hayden) Liu (Packt account *required*)
* [Python Module of the Week](https://pymotw.com/3/) (3.x)
  * [Python Module of the Week](https://pymotw.com/2/) (2.x)
* [Python Notes for Professionals](http://books.goalkicker.com/PythonBook/) - Compiled from StackOverflow documentation (3.x)
* [Python Practice Book](http://anandology.com/python-practice-book/index.html) (2.7.1)
* [Python Practice Projects](http://pythonpracticeprojects.com)
* [Python Programming](https://en.wikibooks.org/wiki/Python_Programming) - Wikibooks (2.7)
* [Python Programming](https://upload.wikimedia.org/wikipedia/commons/9/91/Python_Programming.pdf) - Wikibooks (PDF) (2.6)
* [Scipy Lecture Notes](http://scipy-lectures.github.io)
* [SICP in Python](http://www-inst.eecs.berkeley.edu/~cs61a/sp12/book/) (3.2)
* [Slither into Python: An introduction to Python for beginners](https://www.slitherintopython.com) (3.7)
* [Suporting Python 3: An In-Depth Guide](http://python3porting.com) (2.6 - 2.x & 3.1 - 3.x)
* [Test-Driven Web Development with Python](http://www.obeythetestinggoat.com/pages/book.html) - Harry Percival (3.3 - 3.x)
* [Text Processing in Python](http://gnosis.cx/TPiP/) - David Mertz (2.3 - 2.x)
* [The Coder's Apprentice: Learning Programming with Python 3](http://www.spronck.net/pythonbook/) - Pieter Spronck (PDF) (3.x)
* [The Definitive Guide to Jython, Python for the Java Platform](https://jython.readthedocs.io/en/latest/) - Josh Juneau, Jim Baker, Victor Ng, Leo Soto, Frank Wierzbicki (2.5)
* [The Little Book of Python Anti-Patterns](http://docs.quantifiedcode.com/python-anti-patterns/) ([Source](https://github.com/quantifiedcode/python-anti-patterns))
* [The Programming Historian](http://niche-canada.org/research/niche-digital-infrastructure-project/the-programming-historian/) - William J. Turkel, Adam Crymble and Alan MacEachern
* [The Python GTK+ 3 Tutorial](http://python-gtk-3-tutorial.readthedocs.org/en/latest/)
* [The Standard Python Library](http://effbot.org/librarybook/) - Fredrik Lundh
* [Think Complexity](http://greenteapress.com/complexity/) - Allen B. Downey (2nd Edition) (PDF, HTML)
* [Tiny Python 3.6 Notebook](https://github.com/mattharrison/Tiny-Python-3.6-Notebook) - Matt Harrison (3.6)
* [Web2py: Complete Reference Manual, 6th Edition (pre-release)](http://web2py.com/book) (2.5 - 2.x)


#### Django

* [Django Girls Tutorial](https://tutorial.djangogirls.org/en/) (1.11)
* [Django Official Documentation](https://media.readthedocs.org/pdf/django/1.5.x/django.pdf) (PDF) (1.5)
* [Django Official Documentation](https://media.readthedocs.org/pdf/django/1.7.x/django.pdf) (PDF) (1.7)
* [Django Official Documentation](https://media.readthedocs.org/pdf/django/1.9.x/django.pdf) (PDF) (1.9)
* [Django Official Documentation](https://media.readthedocs.org/pdf/django/1.10.x/django.pdf) (PDF) (1.10)
* [Django Official Documentation](https://buildmedia.readthedocs.org/media/pdf/django/2.2.x/django.pdf) (PDF) (2.2)
* [Django RESTful Web Services](https://www.packtpub.com/free-ebooks/django-restful-web-services) - Gaston C. Hillar (Packt account *required*)
* [Djen of Django](http://agiliq.com/books/djenofdjango/)
* [Effective Django](https://web.archive.org/web/20181130092020/http://www.effectivedjango.com/) (1.5)
* [How to Tango With Django](http://www.tangowithdjango.com/book17/) (1.7)


#### Flask

* [Explore Flask](https://exploreflask.com) - Robert Picard
* [The Flask Mega-Tutorial](http://blog.miguelgrinberg.com/post/the-flask-mega-tutorial-part-i-hello-world) - Miguel Grinberg (0.9)


#### Kivy

* [Kivy Programming Guide](https://kivy.org/docs/guide-index.html)


#### Pandas

* [Learn Pandas](https://bitbucket.org/hrojas/learn-pandas) - Hernan Rojas (0.18.1)


#### Pyramid

* [Quick Tutorial for Pyramid](http://docs.pylonsproject.org/projects/pyramid/en/latest/quick_tutorial/index.html#quick-tutorial)


#### Tornado

* [Learn Web Programming](https://bitbucket.org/hrojas/learn-web-programming)


### QML

* [Qt5 Cadaques](http://qmlbook.github.io) - Juergen Bocklage-Ryannel and Johan Thelin (HTML, PDF, ePub) (:construction: *in process*)


### R

* [Advanced R Programming](http://adv-r.had.co.nz) - Hadley Wickham
* [An Introduction to Statistical Learning with Applications in R](http://www-bcf.usc.edu/~gareth/ISL/) - Gareth James, Daniela Witten, Trevor Hastie and Robert Tibshirani (PDF)
* [Cookbook for R](http://www.cookbook-r.com) - Winston Chang
* [Data Analysis for the Life Sciences](https://leanpub.com/dataanalysisforthelifesciences) - Rafael A Irizarry, Michael I Love *(Leanpub account or valid email requested)*
* [Exploratory Data Analysis with R](https://leanpub.com/exdata) - Roger D. Peng *(Leanpub account or valid email requested)*
* [Introduction to Probability and Statistics Using R](https://github.com/gjkerns/IPSUR) - G. Jay Kerns (PDF)
* [Learning Statistics with R](https://web.archive.org/web/20170625184412/http://health.adelaide.edu.au/psychology/ccs/teaching/lsr/) - Daniel Navarro
* [ModernDive](https://ismayc.github.io/moderndiver-book/) - Chester Ismay and Albert Y. Kim
* [Practical Regression and Anova using R](http://cran.r-project.org/doc/contrib/Faraway-PRA.pdf) - Julian J. Faraway (PDF)
* [R for Data Science](http://r4ds.had.co.nz) - Garrett Grolemund and Hadley Wickham
* [R for Spatial Analysis](http://www.columbia.edu/~cjd11/charles_dimaggio/DIRE/resources/spatialEpiBook.pdf) (PDF)
* [R Language for Programmers](http://www.johndcook.com/blog/r_language_for_programmers) - John D. Cook
* [R Packages](http://r-pkgs.had.co.nz) - Hadley Wickham
* [R Practicals](http://www.columbia.edu/~cjd11/charles_dimaggio/DIRE/resources/R/practicalsBookNoAns.pdf) (PDF)
* [R Programming](https://en.wikibooks.org/wiki/R_Programming) - Wikibooks
* [R Programming for Data Science](https://leanpub.com/rprogramming) - Roger D. Peng  *(Leanpub account or valid email requested)*
* [R Succinctly, Syncfusion](https://www.syncfusion.com/resources/techportal/ebooks/rsuccinctly) (PDF, Kindle) (email address *requested*, not required)
* [The caret Package](http://topepo.github.io/caret/index.html) - Max Kuhn
* [The R Inferno](http://www.burns-stat.com/pages/Tutor/R_inferno.pdf) - Patrick Burns (PDF)
* [The R Language](http://stat.ethz.ch/R-manual/R-patched/doc/html)
* [The R Manuals](http://cran.r-project.org/manuals.html)
* [Tidy Text Mining with R](http://tidytextmining.com) - Julia Silge and David Robinson


### Racket

* [How to Design Programs](https://htdp.org/2019-02-24/) - Matthias Felleisen, Robert Bruce Findler, Matthew Flatt, Shriram Krishnamurthi
* [Programming Languages: Application and Interpretation](http://cs.brown.edu/courses/cs173/2012/book/index.html)
* [The Racket Guide](http://docs.racket-lang.org/guide/index.html)


### Raspberry Pi

* [Raspberry Pi: Measure, Record, Explore](https://leanpub.com/RPiMRE/read) - Malcolm Maclean (HTML)
* [Raspberry Pi Users Guide - (2012)](http://www.cs.unca.edu/~bruce/Fall14/360/RPiUsersGuide.pdf) - Eben Upton (PDF)
* [The Official Raspberry Pi Project Book](https://www.raspberrypi.org/magpi-issues/Projects_Book_v1.pdf) (PDF)


### REBOL

* [Learn REBOL](http://www.lulu.com/shop/nick-antonaccio/learn-rebol/ebook/product-17383182.html) - Nick Antonaccio


### Ruby

* [A community-driven Ruby style guide](https://github.com/bbatsov/ruby-style-guide)
* [CodeCademy Ruby](https://www.codecademy.com/learn/ruby)
* [Developing Games With Ruby](https://leanpub.com/developing-games-with-ruby/read) - Tomas Varaneckas
* [I Love Ruby](https://i-love-ruby.gitlab.io)
* [Introduction to Programming with Ruby](https://launchschool.com/books/ruby) - Launch School
* [Just Enough Ruby to Get By](http://jasonkim.ca/projects/just_enough_ruby_to_get_by/)
* [Learn Ruby First](https://essenceofchaos.gitbooks.io/learn-ruby-first/content/) - Frederick John
* [Learn Ruby the Hard Way](http://learnrubythehardway.org/book/) - Zed Shaw
* [Learn to Program](http://pine.fm/LearnToProgram/) - Chris Pine
* [Mr. Neighborly's Humble Little Ruby Book](https://web.archive.org/web/20180321101922/http://www.humblelittlerubybook.com/book/html/index.html)
* [Object Oriented Programming with Ruby](https://launchschool.com/books/oo_ruby) - Launch School
* [Practicing Ruby](https://github.com/elm-city-craftworks/practicing-ruby-manuscripts)
* [Programming Ruby](http://ruby-doc.com/docs/ProgrammingRuby/)
* [Ruby Essentials](http://www.techotopia.com/index.php/Ruby_Essentials)
* [Ruby Hacking Guide](http://ruby-hacking-guide.github.io)
* [Ruby in Twenty Minutes](https://www.ruby-lang.org/en/documentation/quickstart/)
* [Ruby Koans](http://www.rubykoans.com)
* [Ruby Learning](http://rubylearning.com)
* [Ruby Programming](http://www.linuxtopia.org/online_books/programming_books/ruby_tutorial/)
* [Ruby User's Guide](https://ruby-doc.org/docs/ruby-doc-bundle/UsersGuide/rg/index.html)
* [Ruby Web Dev: The Other Way](https://leanpub.com/rwdtow/read) - Yevhen Kuzminov
* [Rubyfu](https://rubyfu.net)
* [The Bastards Book of Ruby](http://ruby.bastardsbook.com)
* [The Definitive Ruby Tutorial For Complete Beginners](https://www.rubyguides.com/ruby-tutorial/) - Jesus Castello
* [The Unofficial Ruby Usage Guide (at Google)](http://www.caliban.org/ruby/rubyguide.shtml) - Ian Macdonald
* [Using Blocks in Ruby](https://www.oreilly.com/programming/free/using-blocks-in-ruby.csp) - Jay McGavren (email address *requested*)
* [Why's (Poignant) Guide to Ruby](http://poignant.guide)


#### RSpec

* [Better Specs (RSpec Guidelines with Ruby)](http://betterspecs.org)


#### Ruby on Rails

* [A community-driven Rails style guide](https://github.com/bbatsov/rails-style-guide)
* [Building REST APIs with Rails](http://apionrails.icalialabs.com/book)
* [Kestrels, Quirky Birds, and Hopeless Egocentricity](https://leanpub.com/combinators/read) - Reg Braithwaite
* [Learn Ruby on Rails as You Modify a Craigslist Clone](http://www.thinkful.com/learn/ruby-on-rails-tutorial/)
* [Objects on Rails](https://web.archive.org/web/20190319201525/http://objectsonrails.com/) - Avdi Grimm
* [Rails Girls Guides](http://guides.railsgirls.com)
* [Ruby on Rails 3.2 - Step by Step](http://www.xyzpub.com/en/ruby-on-rails/3.2/)
* [Ruby on Rails 4.0 Guide](http://www.xyzpub.com/en/ruby-on-rails/4.0/)
* [Ruby on Rails Guides](http://guides.rubyonrails.org)
* [Ruby on Rails Tutorial (Rails 5): Learn Web Development with Rails](https://www.railstutorial.org/book) - [Michael Hartl](http://www.michaelhartl.com)
* [Upgrading to Rails 4](https://github.com/alindeman/upgradingtorails4)


#### Sinatra

* [Sinatra Book](https://github.com/sinatra/sinatra-book)


### Rust

* [Rust by Example](https://doc.rust-lang.org/stable/rust-by-example/)
* [Rust for Rubyists](https://web.archive.org/web/20190520171322/http://www.rustforrubyists.com/book/index.html) - Steve Klabnik
* [The Rust Programming Language](http://doc.rust-lang.org/book/)
* [The Rustonomicon](https://doc.rust-lang.org/nomicon/)
* [Why Rust?](http://www.oreilly.com/programming/free/files/why-rust.pdf) (PDF)


### Sage

* [Sage for Power Users](http://wstein.org/books/sagebook/sagebook.pdf) - William Stein (PDF)
* [The Sage Manuals](http://www.sagemath.org/doc/)


### Scala

* [A Scala Tutorial for Java programmers](https://docs.scala-lang.org/tutorials/scala-for-java-programmers.html) (PDF)
* [Advanced Scala with Cats](http://underscore.io/books/advanced-scala/) - Noel Welsh and Dave Gurnell (PDF, HTML, EPUB) (email address *requested*, not required)
* [Another tour of Scala](https://web.archive.org/web/20190629103826/http://naildrivin5.com/scalatour/) - David Copeland
* [Creative Scala](http://underscore.io/books/creative-scala/) - Noel Welsh and Dave Gurnell (PDF, HTML, EPUB) (email address *requested*, not required)
* [EAI Patterns with Actor Model](https://github.com/alexanderfefelov/eai-patterns-with-actor-model) - Vaughn Vernon
* [Effective Scala](https://twitter.github.io/effectivescala/)
* [Essential Scala](http://underscore.io/books/essential-scala/) - Noel Welsh and Dave Gurnell (PDF, HTML, EPUB) (email address *requested*, not required)
* [Functional Programming for Mortals](https://leanpub.com/fpmortals/read) - Sam Halliday
* [Functional Programming, Simplified (Scala edition)](https://alvinalexander.com/photos/functional-programming-simplied-free-pdf-preview) - Alvin Alexander (free preview (400 pages from 595), PDF)
* [Hello, Scala](https://alvinalexander.com/photos/hello-scala-free-pdf-preview) - Alvin Alexander (free preview (120 pages from 257), PDF)
* [Learning Scala in small bites](http://matt.might.net/articles/learning-scala-in-small-bites/)
* [Learning Scalaz](http://eed3si9n.com/learning-scalaz/)
* [Pro Scala: Monadic Design Patterns for the Web](https://github.com/leithaus/XTrace/tree/monadic/src/main/book/content/)
* [Programming in Scala, First Edition](http://www.artima.com/pins1ed/) - by M. Odersky, L. Spoon, B. Venners
* [Pure functional HTTP APIs in Scala](https://leanpub.com/pfhais/read) - Jens Grassel
* [PythonToScala](https://wrobstory.gitbooks.io/python-to-scala/content/) - Rob Story
* [S-99: Ninety-Nine Scala Problems](http://aperiodic.net/phil/scala/s-99/) - Phil! Gold
* [Scala & Design Patterns: Exploring Language Expressivity](http://www.scala-lang.org/old/sites/default/files/FrederikThesis.pdf) - Fredrik Skeel Løkke (PDF)
* [Scala By Example](https://www.scala-lang.org/old/sites/default/files/linuxsoft_archives/docu/files/ScalaByExample.pdf) - M. Odersky (PDF)
* [Scala Cookbook: Bonus Chapters](http://examples.oreilly.com/9781449339616-files/Scala_Cookbook_bonus_chapters.pdf) - Alvin Alexander (PDF)
* [Scala for Perl 5 Programmers](https://github.com/garu/scala-for-perl5-programmers) - Breno G. de Oliveira
* [Scala for the Impatient (A1 Scala Level chapters)](http://www.typesafe.com/resources/e-books) - Cay S. Horstmann
* [Scala School by Twitter](http://twitter.github.io/scala_school/)
* [Scala Succinctly](https://www.syncfusion.com/ebooks/scala_succinctly) - Chris Rose
* [Scala Tutorial](http://www.tutorialspoint.com/scala/scala_tutorial.pdf) (PDF)
* [tetrix in Scala](http://eed3si9n.com/tetrix-in-scala-html5-book)
* [The Neophyte's Guide to Scala](http://danielwestheide.com/scala/neophytes.html) - Daniel Westheide
* [The Type Astronaut's Guide to Shapeless](http://underscore.io/books/shapeless-guide/) - Dave Gurnell (PDF, HTML, EPUB) (email address *requested*, not required)
* [Xtrace](https://github.com/leithaus/XTrace/tree/monadic/src/main/book/content/)


#### Lift

* [Exploring Lift](http://exploring.liftweb.net) (published earlier as "The Definitive Guide to Lift", [PDF](http://groups.google.com/group/the-lift-book))
* [Lift](https://github.com/tjweir/liftbook)
* [Lift Cookbook](https://www.oreilly.com/library/view/lift-cookbook/9781449365042/) - Richard Dallaway
* [Simply Lift](http://simply.liftweb.net/Simply_Lift.pdf) - David Pollak (PDF)


#### Play Scala

* [Essential Play](http://underscore.io/books/essential-play/) - Dave Gurnell (PDF, HTML, EPUB) (email address *requested*, not required)
* [Play Framework Recipes](http://alvinalexander.com/scala/scala-cookbook-play-framework-recipes-pdf-ebook) - Alvin Alexander


### Scheme

* [A Pamphlet Against R. Computational Intelligence in Guile Scheme](https://panicz.github.io/pamphlet/)
* [An Introduction to Scheme and its Implementation](http://www.cs.rpi.edu/academics/courses/fall00/ai/scheme/reference/schintro-v14/schintro_toc.html)
* [Concrete Abstractions: An Introduction to Computer Science Using Scheme](https://gustavus.edu/+max/concrete-abstractions.html) - M. Hailperin, B. Kaiser, K. Knight
* [Scheme Tutorial](http://www.cs.hut.fi/Studies/T-93.210/schemetutorial/)
* [Simply Scheme: Introducing Computer Science](http://www.cs.berkeley.edu/~bh/ss-toc2.html) - B. Harvey, M. Wright
* [Teach Yourself Scheme in Fixnum Days](https://ds26gte.github.io/tyscheme/index-Z-H-1.html)
* [The Scheme Programming Language: Edition 3](http://www.scheme.com/tspl3/) - [The Scheme Programming Language: Edition 4](http://www.scheme.com/tspl4/)
* [Write Yourself a Scheme in 48 Hours](https://en.wikibooks.org/wiki/Write_Yourself_a_Scheme_in_48_Hours) - Wikibooks


### Scilab

* [Introduction to Scilab](http://forge.scilab.org/index.php/p/docintrotoscilab/downloads/)
* [Programming in Scilab](http://forge.scilab.org/index.php/p/docprogscilab/downloads/)
* [Writing Scilab Extensions](http://forge.scilab.org/index.php/p/docsciextensions/downloads/)


### Scratch

* [An Introductory Computing Curriculum Using Scratch](http://scratched.gse.harvard.edu/guide/download.html)
* [Computer Science Concepts in Scratch](https://stwww1.weizmann.ac.il/scratch/scratch_en/)


### Sed

* [Sed - An Introduction and Tutorial](http://www.grymoire.com/Unix/Sed.html)


### Self

* [The Self Handbook](http://handbook.selflanguage.org)


### Smalltalk

* [Deep into Pharo](http://books.pharo.org/deep-into-pharo/) - Alexandre Bergel, Damien Cassou, Stéphane Ducasse, Jannik Laval
* [Dynamic Web Development with Seaside](http://book.seaside.st/book/table-of-contents) -  S. Ducasse, L. Renggli, C. D. Shaffer, R. Zaccone
* [Enterprise Pharo: a Web Perspective](http://books.pharo.org/enterprise-pharo/)
* [Numerical Methods with Pharo](http://books.pharo.org/numerical-methods/) - Didier Besset, Stéphane Ducasse, Serge Stinckwich
* [Pharo by Example](http://books.pharo.org/pharo-by-example/) - Andrew P. Black et al. (Smalltalk Implementation and IDE)
* [Stef's Free Online Smalltalk Books](http://stephane.ducasse.free.fr/FreeBooks.html) (meta-list)


### Snap

* [Snap! Reference Manual](https://snap.berkeley.edu/snapsource/help/SnapManual.pdf) - B. Harvey, J. Mönig (PDF)


### Spark

* [Databricks Spark Knowledge Base](https://www.gitbook.com/book/databricks/databricks-spark-knowledge-base/details)
* [Databricks Spark Reference Applications](https://www.gitbook.com/book/databricks/databricks-spark-reference-applications/details)
* [Mastering Apache Spark](https://www.gitbook.com/book/jaceklaskowski/mastering-apache-spark/details)


### Splunk

* [Splunk 7.x Quick Start Guide](https://www.packtpub.com/free-ebooks/splunk-7x-quick-start-guide) - James H. Baxter (Packt account *required*)


### SQL (implementation agnostic)

* [Developing Time-Oriented Database Applications in SQL](https://www2.cs.arizona.edu/~rts/tdbbook.pdf) - Richard T. Snodgrass (PDF)
* [SQL For Web Nerds](http://philip.greenspun.com/sql/)
* [SQL Notes for Professionals](http://books.goalkicker.com/SQLBook/)
* [SQL Queries Succinctly](https://www.syncfusion.com/ebooks/sql_queries_succinctly) - Nick Harrison
* [Use The Index, Luke!: A Guide To SQL Database Performance](http://use-the-index-luke.com)


### SQL Server

* [Best of SQLServerCentral.com Vol 7](http://www.red-gate.com/community/books/ssc-7) *(RedGate, By SQLServerCentral Authors)
* [Brad's Sure Guide to SQL Server Maintenance Plans](http://www.red-gate.com/community/books/sql-server-maintenance-plans) - Brad McGehee (PDF) (email address *requested*)
* [Defensive Database Programming](https://www.red-gate.com/library/defensive-database-programming) - Alex Kuznetsov (PDF)
* [Fundamentals Of SQL Server 2012 Replication](https://www.red-gate.com/library/fundamentals-of-sql-server-2012-replication) - Sebastian Meine (PDF) (email address *requested*)
* [How to Become an Exceptional DBA, Second edition](http://www.red-gate.com/community/books/exceptional-dba-book) - Brad McGehee (PDF)
* [Inside the SQL Server Query Optimizer](http://www.red-gate.com/products/sql-development/sql-prompt/entrypage/sql-query-optimizer-ebook3) - Benjamin Nevarez (PDF) (email address *requested*)
* [Introducing Microsoft SQL Server 2008 R2](http://social.technet.microsoft.com/wiki/contents/articles/11608.e-book-gallery-for-microsoft-technologies-en.aspx#IntroducingMicrosoftSQLServer2008R2)
* [Introducing Microsoft SQL Server 2012](http://social.technet.microsoft.com/wiki/contents/articles/11608.e-book-gallery-for-microsoft-technologies-en.aspx#IntroducingMicrosoftSQLServer2012)
* [Introducing Microsoft SQL Server 2014](http://blogs.msdn.com/b/microsoft_press/archive/2014/04/02/free-ebook-introducing-microsoft-sql-server-2014.aspx)
* [Mastering SQL Server Profiler](http://www.red-gate.com/community/books/mastering-sql-server-profiler) - Brad McGehee (PDF)
* [Microsoft SQL Server Notes for Professionals](http://books.goalkicker.com/MicrosoftSQLServerBook/) (Compiled from StackOverflow documentation)
* [Performance Tuning with SQL Server Dynamic Management Views](http://www.red-gate.com/community/books/dynamic-management-views) - Tim Ford, Louis Davidson (PDF)
* [Protecting SQL Server Data](http://www.red-gate.com/community/books/protecting-data) - John Magnabosco (PDF)
* [SQL Server 2012 Tutorials: Reporting Services](http://social.technet.microsoft.com/wiki/contents/articles/11608.e-book-gallery-for-microsoft-technologies-en.aspx#SQLServer2012Tutorials%3AReportingServices)
* [SQL Server 2017 Administrator's Guide](https://www.packtpub.com/free-ebooks/sql-server-2017-administrators-guide) - Marek Chmel, Vladimír Mužný (Packt account *required*)
* [SQL Server Backup and Restore](http://www.red-gate.com/community/books/sql-server-backup-and-restore) - Shawn McGehee (PDF) (email address *requested*)
* [SQL Server Execution Plans, Third Edition](https://assets.red-gate.com/community/books/sql-server-execution-plans-3rd-edition.pdf) - Grant Fritchey (PDF)
* [SQL Server for C# Developers Succinctly](https://www.syncfusion.com/ebooks/sql_server_for_c_sharp_developers_succinctly) - Sander Rossel
* [SQL Server Hardware](http://www.red-gate.com/community/books/sql-server-hardware) - Glenn Berry (PDF)
* [SQL Server Internals: In-Memory OLTP](http://www.red-gate.com/library/sql-server-internals-in-memory-oltp) - Kalen Delaney (PDF)
* [SQL Server Metadata Succinctly](https://www.syncfusion.com/ebooks/sql-server-metadata-succinctly) - Joseph D. Booth
* [SQL Server Source Control Basics](https://www.red-gate.com/products/sql-development/sql-source-control/entrypage/sql-server-source-control-basics) - Rob Sheldon, Rob Richardson, Tony Davis (PDF)
* [SQL Server Statistics](http://www.red-gate.com/community/books/sql-server-statistics) - Holger Schmeling (PDF)
* [SQL Server Stumpers Vol.5](http://www.red-gate.com/community/books/sql-server-stumpers-v5) (PDF)
* [SQL Server Tacklebox](http://www.red-gate.com/community/books/sql-server-tacklebox) - Rodney Landrum (PDF)
* [SQL Server Transaction Log Management](http://www.red-gate.com/community/books/sql-server-transaction-log-management) - Tony Davis, Gail Shaw (PDF)
* [The Art of SQL Server FILESTREAM](http://www.red-gate.com/community/books/art-of-filestream) - Jacob Sebastian, Sven Aelterman (PDF)
* [The Art of XSD](https://www.red-gate.com/library/the-art-of-xsd) - Jacob Sebastian (PDF)
* [The Best of SQLServerCentral.com Vol 7](https://www.red-gate.com/library/the-best-of-sqlservercentral-com-vol-7) (PDF)
* [The Redgate Guide to SQL Server Team-based Development](https://www.red-gate.com/library/the-redgate-guide-to-sql-server-team-based-development) - Phil Factor, Grant Fritchey, Alex Kuznetsov, Mladen Prajdić (PDF)
* [Troubleshooting SQL Server: A Guide for the Accidental DBA](http://www.red-gate.com/community/books/accidental-dba) - Jonathan Kehayias, Ted Krueger (PDF)


### Standard ML

* [Introduction to Standard ML](http://www.pllab.riec.tohoku.ac.jp/smlsharp/smlIntroSlides.pdf) - Atsushi Ohori (PDF)
* [Programming in Standard ML '97](http://homepages.inf.ed.ac.uk/stg/NOTES/) - Stephen Gilmore, University of Edinburgh
* [Programming in Standard ML, DRAFT](http://www.cs.cmu.edu/~rwh/isml/book.pdf) - Robert Harper (PDF)
* [SML# Document](http://www.pllab.riec.tohoku.ac.jp/smlsharp/docs/3.0/en/manual.xhtml) - Atsushi Ohori, Katsuhiro Ueno
* [The Definition of Standard ML (Revised)](http://sml-family.org/sml97-defn.pdf) - SMLFamily GitHub project (PDF)


### Subversion

* [Subversion Version Control](http://ptgmedia.pearsoncmg.com/images/0131855182/downloads/Nagel_book.pdf) (PDF)
* [Version Control with Subversion](http://svnbook.red-bean.com)


### Swift

* [Hacking with Swift](https://www.hackingwithswift.com)
* [Learn Swift](http://books.aidanf.net/learn-swift)
* [The Swift Programming Language](https://developer.apple.com/library/prerelease/ios/documentation/Swift/Conceptual/Swift_Programming_Language/index.html) (HTML) [(iBook)](https://itunes.apple.com/us/book/swift-programming-language/id881256329?mt=11)
* [Using Swift with Cocoa and Objective-C](https://developer.apple.com/library/content//documentation/Swift/Conceptual/BuildingCocoaApps/index.html) (HTML) [(iBook)](https://itunes.apple.com/us/book/using-swift-cocoa-objective/id888894773?mt=11)


#### Vapor

* [Vapor 3 Tutorial For Beginners](https://theswiftdev.com/2018/04/09/vapor-3-tutorial-for-beginners) - Tibor Bödecs
* [Vapor Official Docs](https://docs.vapor.codes)


### Tcl

* [Tcl Programming](https://en.wikibooks.org/wiki/Programming%3ATcl) - Richard.Suchenwirth, et. al.
* [TclWise](http://www.invece.org/tclwise/index.html) - Salvatore Sanfilippo


### TEI

* [What is the Text Encoding Initiative?](https://books.openedition.org/oep/426) - Lou Bernard


### Teradata

* [Teradata Books](http://www.info.teradata.com)


### Tizen

* [Guide to Developing Tizen Native Application](https://developer.tizen.org/sites/default/files/documentation/guide_to_developing_tizen_native_application_en_2.pdf) - Jung, Dong-Geun (Denis.Jung) (PDF)


### TLA

* [Specifying Systems: The TLA+ Language and Tools for Hardware and Software Engineers](http://research.microsoft.com/en-us/um/people/lamport/tla/book.html) - Leslie Lamport (Postscript or PDF)


### TypeScript

* [Making games with TypeScript](https://makinggameswithtypescript.com) - Øyvind (HTML) (:construction: *in process*)
* [TypeScript Accelerated](https://accelerated.amimetic.co.uk) - James Porter
* [TypeScript Deep Dive](https://basarat.gitbooks.io/typescript/)
* [TypeScript for C# Programmers](http://www.infoq.com/minibooks/typescript-c-sharp-programmers)
* [TypeScript Succinctly, Syncfusion](https://www.syncfusion.com/resources/techportal/ebooks/typescript) (PDF, Kindle) (email address *requested*, not required)


### Unix

* [An Introduction to Unix](http://www.oliverelliott.org/article/computing/tut_unix/)
* [Commentary on the Sixth Edition UNIX Operating System](http://www.lemis.com/grog/Documentation/Lions/) - J. Lions
* [Unix as IDE](https://github.com/mrzool/unix-as-ide) - Tom Ryder (epub, mobi)
* [UNIX Commands and Concepts](http://www.cs.bu.edu/teaching/unix/reference/) - Robert I. Pitts
* [Unix for Poets](http://web.stanford.edu/class/cs124/kwc-unix-for-poets.pdf) - Kenneth Ward Church (PDF)
* [Unix Toolbox](http://cb.vu/unixtoolbox.xhtml) - Colin Barschel
* [UNIX Tutorial for Beginners](http://www.ee.surrey.ac.uk/Teaching/Unix/)


### Verilog

* [Verilog Quick Reference Guide - Sutherland HDL](http://sutherland-hdl.com/pdfs/verilog_2001_ref_guide.pdf) (PDF)
* [Verilog Tutorial](http://www.asic-world.com/verilog/veritut.html)


### VHDL

* [Free Range VHDL](https://github.com/fabriziotappero/Free-Range-VHDL-book) - Bryan Mealy, Fabrizio Tappero (TeX and PDF)
* [VHDL Tutorial](http://www.seas.upenn.edu/~ese171/vhdl/vhdl_primer.html)
* [VHDL Tutorial: Learn By Example](http://esd.cs.ucr.edu/labs/tutorial/)


### Vim

* [A Byte of Vim](http://www.swaroopch.com/notes/vim/)
* [Learn Vim Progressively](http://yannesposito.com/Scratch/en/blog/Learn-Vim-Progressively/)
* [Learn Vimscript the Hard Way](http://learnvimscriptthehardway.stevelosh.com)
* [Use Vim Like A Pro](https://leanpub.com/VimLikeAPro) - Tim Ottinger  *(Leanpub account or valid email requested)*
* [Vi Improved -- Vim](http://www.truth.sk/vim/vimbook-OPL.pdf) - Steve Oualline (PDF)
* [Vim Recipes](https://web.archive.org/web/20130302172911/http://vim.runpaint.org/vim-recipes.pdf) (PDF)
* [Vim Regular Expressions 101](http://vimregex.com)


### Visual Basic

* [Visual Basic Essentials](http://www.techotopia.com/index.php/Visual_Basic_Essentials)


### Visual Prolog

* [A Beginners' Guide to Visual Prolog](http://wiki.visual-prolog.com/index.php?title=A_Beginners_Guide_to_Visual_Prolog)
* [Visual Prolog for Tyros](http://wiki.visual-prolog.com/index.php?title=Visual_Prolog_for_Tyros)


### Web Services

* [RESTful Web Services](http://restfulwebapis.org/RESTful_Web_Services.pdf) (PDF)


### Windows 8

* [Programming Windows Store Apps with HTML, CSS, and JavaScript, Second Edition](https://web.archive.org/web/20150624142410/http://download.microsoft.com/download/6/6/5/665AF7A6-2184-45DC-B9DA-C89185B01937/Microsoft_Press_eBook_Programming_Windows_8_Apps_HTML_CSS_JavaScript_2E_PDF.pdf) - Kraig Brockschmidt (PDF)


### Windows Phone

* [Developing An Advanced Windows Phone 7.5 App That Connects To The Cloud](http://coolthingoftheday.blogspot.co.uk/2012/05/free-ebook-guidance-advanced-windows.html)
* [Windows Phone 8 Development Succinctly](https://www.syncfusion.com/resources/techportal/ebooks/windowsphone8) - Matteo Pagani (PDF)
* [Windows Phone 8.1 Development for Absolute Beginners](http://channel9.msdn.com/Series/Windows-Phone-8-1-Development-for-Absolute-Beginners)
* [Windows Phone Programming Blue Book](http://www.robmiles.com/c-yellow-book/)


### Workflow

* [Declare Peace on Virtual Machines. A guide to simplifying vm-based development on a Mac](https://leanpub.com/declarepeaceonvms/read)


### xBase (dBase / Clipper / Harbour)

* [Application Development with Harbour](https://en.wikibooks.org/wiki/Application_Development_with_Harbour) - Wikibooks
* [CA-Clipper 5.2 Norton Guide](https://web.archive.org/web/20190516192814/http://www.ousob.com/ng/clguide/)
* [Clipper Tutorial: a Guide to Open Source Clipper(s)](https://en.wikibooks.org/wiki/Clipper_Tutorial%3A_a_Guide_to_Open_Source_Clipper(s)) - Wikibooks
