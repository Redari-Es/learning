## Index

* [Big Data](#BigData)
* [Database](#Database)
* [HTML](#HTML)
* [Javascript](#Javascript)


### BigData

* [எளிய தமிழில் Big Data](http://www.kaniyam.com/learn-bigdata-in-tamil-ebooks/)


### Database

* [எளிய தமிழில் MySQL ](http://www.kaniyam.com/mysql-book-in-tamil/)


### HTML

* [எளிய தமிழில் CSS](http://www.kaniyam.com/learn-css-in-tamil-ebook/)
* [எளிய தமிழில் HTML](http://www.kaniyam.com/learn-html-in-tamil/)


### Javascript

* [எளிய தமிழில் JavaScript](http://www.kaniyam.com/learn-javascript-in-tamil/)

