### Index

* [Python](#python)
* [Scratch](#scratch)


### Python

* [De Programmeursleerling: Leren coderen met Python 3](http://www.spronck.net/pythonbook/dutchindex.xhtml) - Pieter Spronck (PDF) (3.x)


### Scratch

* [Creatief Computergebruik](http://scratched.gse.harvard.edu/resources/creatief-computergebruik)
