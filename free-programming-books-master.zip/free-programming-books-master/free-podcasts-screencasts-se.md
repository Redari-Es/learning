### Index

* [Language Agnostic](#language-agnostic)


### Language Agnostic

* [Kodsnack](http://kodsnack.se) (podcast)
* [Still in beta](http://stillinbeta.se) (podcast)
* [Under utveckling](https://underutveckling.libsyn.com) (podcast)
* [Väg 74](https://www.agical.se/pod) (podcast)
