### Index

* [C](#c)
* [C#](#c-sharp)
* [C++](#c-1)
* [Java](#java)
* [Pascal](#pascal)


### C

* [C - Programmering](http://synkro.dk/bog/c-programmering.pdf) - Henrik Kressner (PDF)
* [Programmering i C](http://people.cs.aau.dk/~normark/c-prog-06/pdf/all.pdf) - Kurt Nørmark (PDF)


### C Sharp

* [Object-oriented Programming in C#](http://people.cs.aau.dk/~normark/oop-csharp/pdf/all.pdf) - Kurt Nørmark (PDF)


### C++

* [Notes about C++](http://people.cs.aau.dk/~normark/ap/index.html) - Kurt Nørmark (HTML)


### Java

* [Objektorienteret programmering i Java](http://javabog.dk) - Jacob Nordfalk


### Pascal

* [Programmering i Pascal](http://people.cs.aau.dk/~normark/all-basis-97.pdf) - Kurt Nørmark (PDF)
