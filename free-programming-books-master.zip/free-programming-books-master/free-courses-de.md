### Index

* [Künstliche Intelligenz](#künstliche-intelligenz)
* [Python](#python)


### Künstliche Intelligenz

* [Elements of AI](https://www.elementsofai.de)


### Python

* [Programmieren lernen mit Python](https://www.youtube.com/playlist?list=PLL1BYAeNY0gzHheN7kCLEhPDegdHrAyDh)
* [Programmieren Lernen: Python Tutorial](https://www.youtube.com/playlist?list=PL_tdPUem3eE_k40i65IdRPWrAZxoHcN4o)
* [Python-Kurs (Python 2)](https://www.python-kurs.eu/kurs.php)
* [Python-Kurs (Python 3)](https://www.python-kurs.eu/python3_kurs.php)
* [Python Tutorials Deutsch](https://www.youtube.com/playlist?list=PLNmsVeXQZj7q0ao69AIogD94oBgp3E9Zs)
